#!/bin/bash

# align_window.sh 

# Assuming the stage is positioned near the center of a 
# nitride window, move -SIZEX/2, 0  and then scan the
# left side of the window. Next move by SIZEX,0 and
# scan the right side. Same for top and bottom Calculate 
# the center coordinate and then move there.

# Sides are scanned with a STEP*PIXELS square raster,
# with an accuracy no better than STEP nm. Well, that 
# presumes we are using a 1 nm resolution.

# Edges are scanned with
#
#         pg image grab offset step(nm) number filename
#
#
# This script finishes by moving to the center of the window,
# which is appropriate as a drop-in mark alignment routine.

# To use this script in an exposure job, make sure the 
# script (this file) is named align_window.sh in the 
# current directory. Then choose the mark type "window" 
# in cjob. 

# Your local ebeam guru should have already created
# a marker type "window" which points to "./align_window.sh".
# If not, you should create the new marker with

#        pg marker create joy ./align_window.sh window

# By changing the parameters ONTO_MARK and OFF_OF_MARK,
# you can use this script for alignment to a large
# bright rectangle, instead of a large dark rectangle.



mnemonics_error_handler ()
{
    exit $1
}

trap 'error=$? ; mnemonics_error_handler $error' ERR
trap 'trap - ERR' EXIT


# size of the nitride window, in microns:

SIZEX=2080
SIZEY=2080

# scan size is STEP * PIXELS (nm)
# 500nm * 256 = 128um scan

STEP=500
PIXELS=256

# set PLOT to 'plot' if you wish to display the scan with gnuplot

PLOT="plot"
#PLOT=""

# If the 'marker' is dark (like a nitride window) then set the 
# expected signal transitions this way:

ONTO_MARK="bright-dark"
OFF_OF_MARK="dark-bright"

# If the 'marker' is a big, bright rectangle then set
# the expected signal transitions this way:
#
# ONTO_MARK="dark-bright"
# OFF_OF_MARK="bright-dark"


# We assume that the user or the job has moved to the 
# center of the window. Move first to the left side.

place=`pg get tab`

dx=`dc -e "6 k $SIZEX 2 / n"`
dy=`dc -e "6 k $SIZEY 2 / n"`

pg mov pos --rel -$dx,0

echo
echo "Scanning left side..."

semoff

pg image grab 0,0 $STEP,$STEP $PIXELS,$PIXELS marker

#Use: find_edge [vertical|horizontal] [bright-dark|dark-bright] imagefile.img xpixels ypixels nm/pixel [plot]

find_edge vertical $ONTO_MARK marker.img $PIXELS $PIXELS $STEP $PLOT

lx=`pg get tab_x | awk -F_ '$0=$1'`

echo "Scanning right side..."

pg mov pos $place
pg mov pos --rel $dx,0
pg image grab 0,0 $STEP,$STEP $PIXELS,$PIXELS marker
find_edge vertical $OFF_OF_MARK marker.img $PIXELS $PIXELS $STEP $PLOT

rx=`pg get tab_x | awk -F_ '$0=$1'`

echo "Scanning top side..."

pg mov pos $place
pg mov pos --rel 0,$dy
pg image grab 0,0 $STEP,$STEP $PIXELS,$PIXELS marker
find_edge horizontal $ONTO_MARK marker.img $PIXELS $PIXELS $STEP $PLOT

ty=`pg get tab_y | awk -F_ '$0=$1'`

echo "Scanning bottom side..."

pg mov pos $place
pg mov pos --rel 0,-$dy
pg image grab 0,0 $STEP,$STEP $PIXELS,$PIXELS marker
find_edge horizontal $OFF_OF_MARK marker.img $PIXELS $PIXELS $STEP $PLOT

by=`pg get tab_y | awk -F_ '$0=$1'`

# calculate the center point, in microns

cx=`dc -e "6 k $lx $rx + 2.0 / 1000.0 * n"`
cy=`dc -e "6 k $ty $by + 2.0 / 1000.0 * n"`

echo
echo "pg move pos $cx,$cy"
echo

pg move pos $cx,$cy

echo "alignment complete"
echo






