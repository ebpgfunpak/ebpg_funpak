#!/usr/bin/python3

# Pull the essential numbers out of a perfcheck log file,
# boiling it down to just a few lines indicating "bad" or "good".

# version 1.1

# v1.1  Look at results of XMBC, which measures spot size across a field.
#       Calculate the standard deviation of the spot sizes in X and Y.

import sys
import os
import math

# These maximum numbers are based on typical ebpg performance.
# They are not official Raith specs. Use your own numbers
# if you don't like these.

MAXPULLINERR   = 20.0  # nm
MAXOPTDRIFT    = 5.0   # nm/min    
MAXDEFLDRIFT   = 15.0  # nm/min
MAXDISTOR      = 20.0  # nm       mean + 3 sigma
MAXCURDEV      = 0.5   # percent variance over field
MAXSPOTDEV     = 7.0   # nm  standard dev of spot sizes over field

SHOWALLDISTORS = False # look at just the big one, 289 points

percent = "%"


#-------------------

def use() :
    print( "\nperf_score: summarize a log file from perfcheck" )
    print( "\nUse: perf_score.py file.log someone@somewhere.edu\n" )
    sys.exit()
    
#-------------------

def find( string, lines, start ) :   # find string in lines[] 
    j = start
    while (j < len(lines)) and (not string in lines[j]) : j = j + 1
    if j == len(lines) :
        print( "\nERROR: cannot find \"%s\" starting at line %d" % (string, start) )
        print( "Abort.\n" )
        sys.exit()
    return( j )

#-------------------

if len(sys.argv) < 3 or "help" in sys.argv : use()

sysadmin = sys.argv[2]

lines = open( sys.argv[1], "r" ).readlines()

for i in range(len(lines)) : lines[i] = lines[i].lower()

# print("\n<font style=\"font-family:'Courier New';font-weight: bold\">" )

table = []

i = 0
i = find( "machine id", lines, i )
print( lines[i] )

id = lines[i].split( '\t' )[2].upper()
id = id[:-1]
table.append( ["Machine: %s" % id, '', '', '', '', ''] )
table.append( ['', '', '', '', '', ''] )

# Pull-in performance data

dxmax = 0.0
dymax = 0.0
i = i + 1

i = find( "pull-in performance", lines, i )

i = i + 6
line = lines[i]
word = line.split()
dxmax = float( word[2] ) * 1000.0
dx    = float( word[4] ) * 1000.0
if dx > dxmax : dxmax = dx
dymax = float( word[3] )
dy    = float( word[5] )
if dy > dymax : dymax = dy

for j in range(4) :
    i = i + 1
    line = lines[i]
    word = line.split()
    dx   = float( word[2] ) * 1000.0
    dy   = float( word[3] ) * 1000.0
    if dx > dxmax : dxmax = dx
    if dy > dymax : dymax = dy
    dx   = float( word[4] ) * 1000.0
    dy   = float( word[5] ) * 1000.0
    if dx > dxmax : dxmax = dx
    if dy > dymax : dymax = dy
    
if dxmax > MAXPULLINERR or dymax > MAXPULLINERR :
    print( "Pull-in error             out of range:  %6.3f  %6.3f   max:  %6.3f nm       ***** see line %d" % (dxmax, dymax, MAXPULLINERR, i) )
    table.append( ["Pull-in error", "out of range:", "%6.3f" % dxmax, "%6.3f" % dymax, "max:  %6.3f nm" % MAXPULLINERR, "*** see line %d" % i] )
else:
    print( "Pull-in error                  nominal:  %6.3f  %6.3f   max:  %6.3f nm" % (dxmax, dymax, MAXPULLINERR) )
    table.append( ["Pull-in error", "nominal:", "%6.3f" % dxmax, "%6.3f" % dymax, "max:  %6.3f nm" % MAXPULLINERR, ""] )

    
# Electron optics drift
    
i = find( "electron optics drift", lines, i+1 )

i = i + 13
line = lines[i]
word = line.split()
xd = abs(float( word[1] ))
xdmax = xd
yd = abs(float( word[2] ))
ydmax = yd
i = i + 1
line = lines[i]
word = line.split()
xd = float( word[1] )
if xd > xdmax : xdmax = xd
yd = abs(float( word[2] ))
if yd > ydmax : ydmax = yd
i = i + 1
line = lines[i]
word = line.split()
xd = abs(float( word[1] ))
if xd > xdmax : xdmax = xd
yd = abs(float( word[2] ))
if yd > ydmax : ydmax = yd

if xdmax > MAXOPTDRIFT or ydmax > MAXOPTDRIFT :
    print( "Optics drift              out of range:  %6.3f  %6.3f   max:  %6.3f nm/min   ***** see line %d" % (xdmax, ydmax, MAXOPTDRIFT, i) )
    table.append( ["Optics drift", "out of range:", "%6.3f" % xdmax, "%6.3f" % ydmax, "max:  %6.3f nm" % MAXOPTDRIFT, "*** see line %d" % i] )
else:
    print( "Optics drift                   nominal:  %6.3f  %6.3f   max:  %6.3f nm/min" % (xdmax, ydmax, MAXOPTDRIFT) )
    table.append( ["Optics drift", "nominal:", "%6.3f" % xdmax, "%6.3f" % ydmax, "max:  %6.3f nm" % MAXOPTDRIFT, "" ] )


# Deflection drift, beam off

i = find( "deflection drift", lines, i+1 )            

i = i + 3
line = lines[i]

if not ("beam" in line and "off" in line) :
    print( "\nERROR: expected to find \"beam off\" results at line %d." % i )
    print( "Abort.\n" )
    sys.exit()
            
i = i + 8
line = lines[i]
word = line.split()
xd = abs(float(word[2]))
yd = abs(float(word[3]))
xdmax = xd
ydmax = yd

for j in range(8) :
    i = i + 1
    line = lines[i]
    word = line.split()
    xd = abs(float(word[2]))
    yd = abs(float(word[3]))
    if xd > xdmax : xdmax = xd
    if yd > ydmax : ydmax = yd

if xdmax > MAXDEFLDRIFT or ydmax > MAXDEFLDRIFT :
    print( "Beam-off deflection drift out of range:  %6.3f  %6.3f   max:  %6.3f nm/min   ***** see line %d" % (xdmax, ydmax, MAXDEFLDRIFT, i) )
    table.append( ["Beam-off deflection drift", "out of range:", "%6.3f" % xdmax, "%6.3f" % ydmax, "max:  %6.3f nm" % MAXDEFLDRIFT, "*** see line %d" % i] )
else:
    print( "Beam-off deflection drift      nominal:  %6.3f  %6.3f   max:  %6.3f nm/min" % (xdmax, ydmax, MAXDEFLDRIFT) )
    table.append( ["Beam-off deflection drift", "nominal:", "%6.3f" % xdmax, "%6.3f" % ydmax, "max:  %6.3f nm" % MAXDEFLDRIFT, ""] )


# Deflection drift, beam on

i = find( "deflection drift", lines, i+1 )

i = i + 3
line = lines[i].lower()
if not ("beam" in line and "on" in line) :
    print( "\nERROR: expected to find \"beam on\" results at line %d." % i )
    print( "Abort.\n" )
    sys.exit()

i = i + 8
line = lines[i]
word = line.split()
xd = abs(float(word[2]))
yd = abs(float(word[3]))
xdmax = xd
ydmax = yd

for j in range(8) :
    i = i + 1
    line = lines[i]
    word = line.split()
    xd = abs(float(word[2]))
    yd = abs(float(word[3]))
    if xd > xdmax : xdmax = xd
    if yd > ydmax : ydmax = yd

if xdmax > MAXDEFLDRIFT or ydmax > MAXDEFLDRIFT :
    print( "Beam-on deflection drift  out of range:  %6.3f  %6.3f   max:  %6.3f nm/min   ***** see line %d" % (xdmax, ydmax, MAXDEFLDRIFT, i) )
    table.append( ["Beam-on deflection drift", "out of range:", "%6.3f" % xdmax, "%6.3f" % ydmax, "max:  %6.3f nm" % MAXDEFLDRIFT, "*** see line %d" % i] )
else:
    print( "Beam-on deflection drift       nominal:  %6.3f  %6.3f   max:  %6.3f nm/min" % (xdmax, ydmax, MAXDEFLDRIFT) )
    table.append( ["Beam-on deflection drift", "nominal:", "%6.3f" % xdmax, "%6.3f" % ydmax, "max:  %6.3f nm" % MAXDEFLDRIFT, ""] )


# distortions - first 289 points, then 81 points, then 25 points

i = find( "distortion measurements", lines, i+1 )
i = find( "no of measurements", lines, i+1 )

if not "289" in lines[i] :
    print( "\nERROR: unable to find the set of 289 distortion points.\nAbort.\n" )
    sys.exit()

i = find( "x error -> abs(mean) + 3*sigma", lines, i+1 )

#         X Error -> ABS(mean) + 3*sigma ..    9.265_nm
#         Y Error -> ABS(mean) + 3*sigma ..   18.161_nm

line = lines[i]
word = line.split('..')
mot  = word[1].split( '_' )
xerror = float( mot[0] )
i = i + 1
line = lines[i]
word = line.split('..')
mot  = word[1].split( '_' )
yerror = float( mot[0] )

# print( "289 point distortion:" )

if xerror > MAXDISTOR or yerror > MAXDISTOR :
    print( "Distortion mean+3sigma    out of range:  %6.3f  %6.3f   max:  %6.3f nm       ***** see line %d" % (xerror, yerror, MAXDISTOR, i) )
    table.append( ["Distortion mean+3sigma", "out of range:", "%6.3f" % xerror, "%6.3f" % yerror, "max:  %6.3f nm" % MAXDISTOR, "*** see line %d" % i] )
else:
    print( "Distortion mean+3sigma         nominal:  %6.3f  %6.3f   max:  %6.3f nm" % (xerror, yerror, MAXDISTOR) )
    table.append( ["Distortion mean+3sigma", "nominal:", "%6.3f" % xerror, "%6.3f" % yerror, "max:  %6.3f nm" % MAXDISTOR, ""] )
    
if SHOWALLDISTORS :
    i = find( "no of measurements", lines, i+1 )

    if not "81" in lines[i] :
        print( "\nERROR: unable to find the set of 81 distortion points.\nAbort.\n" )
        sys.exit()

    i = find( "x error -> abs(mean) + 3*sigma", lines, i+1 )

    line = lines[i]
    word = line.split('..')
    mot  = word[1].split( '_' )
    xerror = float( mot[0] )
    i = i + 1
    line = lines[i]
    word = line.split('..')
    mot  = word[1].split( '_' )
    yerror = float( mot[0] )

    print( "81 point distortion:" )

    if xerror > MAXDISTOR or yerror > MAXDISTOR :
        print( "Distortion mean+3sigma     out of range: %6.3f  %6.3f   max:  %6.3f nm       ***** see line %d" % (xerror, yerror, MAXDISTOR, i) )
    else:
        print( "Distortion mean+3sigma          nominal: %6.3f  %6.3f   max:  %6.3f nm" % (xerror, yerror, MAXDISTOR) )


    i = find( "no of measurements", lines, i+1 )

    if not "25" in lines[i] :
        print( "\nERROR: unable to find the set of 25 distortion points.\nAbort.\n" )
        sys.exit()

    i = find( "x error -> abs(mean) + 3*sigma", lines, i+1 )

    line = lines[i]
    word = line.split('..')
    mot  = word[1].split( '_' )
    xerror = float( mot[0] )
    i = i + 1
    line = lines[i]
    word = line.split('..')
    mot  = word[1].split( '_' )
    yerror = float( mot[0] )

    print( "25 point distortion:" )

    if xerror > MAXDISTOR or yerror > MAXDISTOR :
        print( "Distortion mean+3sigma    out of range:  %6.3f  %6.3f   max:  %6.3f nm       ***** see line %d" % (xerror, yerror, MAXDISTOR, i) )
    else:
        print( "Distortion mean+3sigma         nominal:  %6.3f  %6.3f   max:  %6.3f nm" % (xerror, yerror, MAXDISTOR) )


# spot and current uniformity

i = find( "spot and current uniformity", lines, i+1 )
i = find( "max deviation over field", lines, i+1 )

line = lines[i]
word = line.split("=")
mot  = word[1].split("_")
dev  = float( mot[0] )

if dev > MAXCURDEV :
    print( "Current uniformity        out of range:  %6.3f           max:  %6.3f %s        ***** see line %d" % (dev, MAXCURDEV, percent, i) )
    table.append( ["Current uniformity", "out of range:", "%6.3f" % dev, "", "max:  %6.3f%s" % (MAXCURDEV, percent), "*** see line %d" % i] )
else:
    print( "Current uniformity             nominal:  %6.3f           max:  %6.3f %s" % (dev, MAXCURDEV, percent) )
    table.append( ["Current uniformity", "nominal:", "%6.3f" % dev, "", "max:  %6.3f%s" % (MAXCURDEV, percent), ""] )


# xmbc : spot size uniformity over the field

i = find( "spot_x   spot_y", lines, i+1 )

ax = 0.0
ay = 0.0
sx = []
sy = []

for j in range(1,10) :
    line = lines[i+j]
    word = line.split()
    sx.append( float( word[0] ) )
    sy.append( float( word[1] ) )
    ax = ax + sx[-1]
    ay = ay + sy[-1]

ax = ax / 9.0
ay = ay / 9.0
ssx = 0.0
ssy = 0.0

for j in range(len(sx)) :
    ssx = ssx + (sx[j] - ax) * (sx[j] - ax)
    ssy = ssy + (sy[j] - ay) * (sy[j] - ay)

sdevx = math.sqrt( ssx / 9.0 )
sdevy = math.sqrt( ssy / 9.0 )

if sdevx > MAXSPOTDEV or sdevy > MAXSPOTDEV :
    print( "Spot size uniformity      out of range:  %6.3f  %6.3f   max:  %6.3f nm        ***** see line %d" % (sdevx, sdevy, MAXSPOTDEV, i) )
    table.append( ["Spot size uniformity", "out of range:", "%6.3f %6.3f" % (sdevx, sdevy), "", "max:  %6.3f nm" % (MAXSPOTDEV), "*** see line %d" % i] )
else:
    print( "Spot size uniformity           nominal:  %6.3f  %6.3f   max:  %6.3f nm" % (sdevx, sdevy, MAXSPOTDEV) )
    table.append( ["Spot size uniformity", "nominal:", "%6.3f %6.3f" % (sdevx, sdevy), "", "max:  %6.3f nm" % (MAXSPOTDEV), ""] )


# spot size vs. fine focus

# what can we say about those plots of spot size vs. focus?


pf = open( "perfscore.html", "w" )

pf.write( "<!DOCTYPE html>\n" )
pf.write( "<body>\n" )
pf.write( "<div>\n<p>\n" )
pf.write( "<table style=\"border: none; width: 800px; font-family: 'Courier new'; font-weight: bold;\">\n" )
pf.write( "<tbody>\n" )
pf.write( "<tr style=\"border: none;\">\n" ) 

for line in table :
    for item in line :
        if item == '' :
            pf.write( "<td style=\"border: none;\">&nbsp;</td>\n" )
        else:
            pf.write( "<td style=\"border: none;\">%s</td>\n" % item )
    pf.write( "<tr/>\n" )                                                   # stupid bloody gmail doesn't like </tr>
pf.write( "</tbody>\n" )
pf.write( "</table>\n" )
pf.write( "</div>\n" )
pf.write( "</body>\n" )

pf.close()

# print( "\nTable of results written to perfscore.html\n" )

os.system( "mail -s \"$(echo -e 'perfcheck summary\nContent-Type: text/html')\" %s < perfscore.html" % sysadmin )
os.system( "rm -f perfscore.html" )










    
    
            
