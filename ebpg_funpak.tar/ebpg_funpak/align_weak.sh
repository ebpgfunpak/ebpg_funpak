#!/usr/bin/python3

# align_weak

# Requires: zap, find_edge, find_square, gnuplot

# Assuming the stage is positioned near the center of a rectangular
# mark, this script will move -SIZEX/2, 0  and then scan the
# left side of the mark. Next it will move by +SIZEX/2,0 and
# scan the right side. Same for top and bottom We calculate 
# the center coordinate and then move there.

# To use this script in an exposure job, make sure the 
# script (this file) is named align_weak.sh in the 
# current directory. Then choose the mark type "weak" 
# in cjob.

# Your local ebeam guru should have already created
# a marker type "weak" which points to "./align_weak.sh".
# If not, you should create the new marker with

#        pg marker create joy ./align_weak.sh weak

# Then you should copy this script to some other folder
# before editing it. The "weak" marker type will look
# for this scrip in the folder "." 
# meaning "in the current directory".


# Why python instead of bash? Because bash sucks at arithmetic.

import sys
import os

#-------------------------------------------------------
# SET THESE PARAMETERS
#

SIZEX      = 20       # mark size, um
SIZEY      = 20       # mark size, um

FINESIZE   = 18       # fine scan size, um
FINEPIX    = 512      # number of pixels for fine scan
COARSIZE   = 150      # coarse scan size, um
COARSEPIX  = 256      # number of pixelse for coarse scan
CTHRESHOLD = 5        # Contrast threshold for coarse scan
FTHRESHOLD = 5        # Contrast threshold for fine scan
N          = 2        # 2^N samples per pixel, for fine scans
NC         = 3        # 2^NC frames for the coarse scan, 
                      # and also average each pixel NC times 

PLOT       = "plot"   # or use "noplot" 
POLARITY   = "bright" # or use "dark" for the mark type

#-------------------------------------------------------


os.system( "pg info adj resol > /tmp/rando.txt" )
f = open( "/tmp/rando.txt", "r" )
for line in f.readlines() :
    if "main resolution" in line :
        ff = line.split()
        if len(ff) < 5 :
            print( "ERROR: unknown content of pg info adj resol" )
            sys.exit()
        lsb  = float( ff[3] )
        unit = ff[4]
        if not "nm" in unit :
            print( "ERROR: unknown unit in lsb: %s" % unit )
            sys.exit()
        print( "lsb = %f" % (lsb) )

f.close()

# scan size for fine alignment =  step * pixels nm

STEP   = round( 1000 * lsb * FINESIZE / FINEPIX )

PIXELS = FINEPIX  # change name for no particular reason

# Use this pmhv setting, or set it by hand
# PMHV = 3004
# os.system( "pg set pmhv %d" % PMHV )
# mbsb=`pg get mbsbase`
# pg set mbsbase 1000

#----------------------------------------------------------------------
# COARSE ALIGNMENT

# For automated coarse alignment of a bright 20 um mark,
# If NC = 3 then this will
# average 2^3=8 frames and sample each pixel 2^3=8 times.
# Field of view is 700nm * 128 = 89.6 um.

os.system( "semoff" )

print( "\nCoarse alignment...\n" )

CSTEP = round( 1000 * lsb * COARSIZE / COARSEPIX )

os.system( "pg image grab 0,0 %d,%d %d,%d coarse --sample=%d --frame=%d" % \
           (CSTEP,CSTEP,COARSEPIX,COARSEPIX,NC,NC) )

os.system( "find_square %d coarse.img %d %d %d %s %d  | tee results.txt" % \
           (SIZEX,COARSEPIX,COARSEPIX,CSTEP,PLOT,CTHRESHOLD) )

f = open( "results.txt", "r" )
mess = f.read()
f.close()

if "WARNING" in mess :
    print( "\nCOARSE ALIGN FAILED. PLEASE FIND THE MARK MANUALLY.\n" )
    os.system( "semon" )
    print( "Center the mark, then press Enter (or 'q'). " )
    ans = sys.stdin.readline()
    if "q" in ans or "Q" in ans : sys.exit()
    os.system( "semoff" )

place = os.popen("pg get tab").read()[:-1]

#----------------------------------------------------------------------

# We assume that the user or the job has moved to the 
# center of the mark. Move first to the left side.


dx = SIZEX / 2.0
dy = SIZEY / 2.0

os.system( "pg mov pos --rel -%d,0" % dx )

print( "\nScanning left side...")

os.system( "semoff" )

# Scan size is STEP * PIXELS nm 

os.system( "pg image grab 0,0 %d,%d %d,%d marker_l --sample=%d --frame=1" % (STEP,STEP,PIXELS,PIXELS,N))

os.system( "zap gnuplot 2>&1 /dev/null &" )

# Use: find_edge [vertical|horizontal] [bright-dark|dark-bright] \
#      imagefile.img xpixels ypixels nm/pixel [plot] [title]

if POLARITY == "bright" :
    onto   = "dark-bright"
    offof  = "bright-dark"
else:
    onto   = "bright-dark"
    offof  = "dark-bright"

os.system( "find_edge vertical %s marker_l.img %d %d %d %s LEFT %d" % \
           (onto,PIXELS,PIXELS,STEP,PLOT,FTHRESHOLD))

lx = float( os.popen("pg get tab_x").read().split('_')[0] )

print( "Scanning right side...")

os.system( "pg mov pos %s" % place )
os.system( "pg mov pos --rel %d,0" % dx )
os.system( "pg image grab 0,0 %d,%d %d,%d marker_r --sample=%d --frame=1" % (STEP,STEP,PIXELS,PIXELS,N))

os.system( "zap gnuplot 2>&1 /dev/null &" )

os.system( "find_edge vertical %s marker_r.img %d %d %d %s RIGHT %d" % \
           (offof,PIXELS,PIXELS,STEP,PLOT,FTHRESHOLD))

rx = float( os.popen("pg get tab_x").read().split('_')[0] )

print( "Scanning top side...")

os.system( "pg mov pos %s" % place )
os.system( "pg mov pos --rel 0,%d" % dy )
os.system( "pg image grab 0,0 %d,%d %d,%d marker_t --sample=%d --frame=1" % (STEP,STEP,PIXELS,PIXELS,N))
os.system( "zap gnuplot 2>&1 /dev/null &" )
os.system( "find_edge horizontal %s marker_t.img %d %d %d %s TOP %d" % \
           (onto,PIXELS,PIXELS,STEP,PLOT,FTHRESHOLD))

ty = float( os.popen("pg get tab_y").read().split('_')[0] )

print( "Scanning bottom side...")

os.system( "pg mov pos %s" % place )
os.system( "pg mov pos --rel 0,-%d" % dy )
os.system( "pg image grab 0,0 %d,%d %d,%d marker_b --sample=%d --frame=1" % (STEP,STEP,PIXELS,PIXELS,N))
os.system( "zap gnuplot 2>&1 /dev/null &" )
os.system( "find_edge horizontal %s marker_b.img %d %d %d %s BOTTOM %d" % \
           (offof,PIXELS,PIXELS,STEP,PLOT,FTHRESHOLD))

by = float( os.popen("pg get tab_y").read().split('_')[0] )

# calculate the center point, in microns

cx = 1000 * (lx + rx) / 2.0
cy = 1000 * (ty + by) / 2.0

print( "pg move pos %d,%d\n" % (cx, cy))

os.system( "pg move pos %d,%d" % (cx, cy) )

# pg set mbsbase $mbsb

print( "alignment complete\n")


