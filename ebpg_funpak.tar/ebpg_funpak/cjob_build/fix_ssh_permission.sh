#!/usr/bin/bash 
echo "fixing ssh key file permissions"
pushd .
cd
find .ssh/ -type f -exec chmod 600 {} \;; 
find .ssh/ -type d -exec chmod 700 {} \;; 
find .ssh/ -type f -name "*.pub" -exec chmod 644 {} \;
popd
echo "done."
