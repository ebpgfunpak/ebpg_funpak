#!/bin/bash
DATE=`date +%m.%d.%g`

# /home/pg/bin/weekly_check.py

cp /home/pg/archive/*_globaldata  /home/pg/bin/

echo
echo "Starting performance check"
echo "Log file: /home/pg/perfcheck-$DATE.log"

pg arc rest beam 10na_300.beam_100

# performance_test is a Raith utility, typically found in 
# /home/beams/v09_14h/usr/performance_test
# where "v09_14h" is the currently installed Beams version.
# Or you might create a shortcut with "ln" so it would be found in
# /home/beams/current/usr/performance_test

performance_test 0 2>&1 | tee /home/pg/log/perfcheck-$DATE.log

perf_score.py /home/pg/log/perfcheck-$DATE.log $SYSADMIN

mail -s "perfcheck done" $SYSADMIN < /dev/null

echo 
echo "Done."
echo















# demag table measurement 
# does not seem to be a useful anymore

mail -s "monthly check done" $SYSADMIN < /dev/null

# subu 1



