/*

find_square.c    version 2

Michael Rooks, Yale University  michael.rooks@yale.edu

Requires gnuplot, if you want to display the results.

Given the image of a square, find the center by calculating a
simple-minded fit. The rows (and later, columns) of the image 
are first averaged, forming a one-dimensional signal. The signal
is normalized and then fit to a 1D model - either a bump up or 
a bump down. The image might be collected with a command such as

        pg image grab 0,0 312,312 128,128 coarse --sample=4 --frame=1

which dumps a raw image into the file coarse.img. In this example the
pixel pitch is 312 nm, and there are 128x128 pixels, making 
the image size 40um.

Be sure to include the line

        export PG_IMAGES=.

in /home/pg/local_commands (or in /etc/bashrc) so that "pg image grab"
will dump image files in the current directory.

use: find_square size_um   \
     imagefile.img xpixels ypixels nm/pixel [plot|noplot] [threshold] [bright|dark]

You do not need to know if the mark is bright or dark, 
but if you do know, then this could prevent the program
from making the wrong choice.

This works better than "pg image correlate" or our own "correlate"
since we are taking advantage of the symmetry of the square mark.

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define BYTE    unsigned char
#define BOOL    short
#define TRUE    1
#define FALSE   0
#define BRIGHT  1
#define DARK    0
#define EITHER -1

#define THRESHOLD 10       // minimum contrast, percent


int **int_matrix( int nrl, int nrh, int ncl, int nch)

    {

    // Allocate a matrix of pointers to int

    int    i;
    int  **m;
      
    m=(int **) malloc((nrh-nrl+1)*sizeof( int* ));

    if ( ! m ) 
        {
        printf("\n\nERROR: allocation failure 1 in int_matrix()\n\n");
        exit(-1);
        }

    m -= nrl;

    for(i=nrl;i<=nrh;i++) 
        {
        m[i]=(int *) malloc((unsigned) (nch-ncl+1)*sizeof(int));
        if (! m[i] ) 
            {
            printf("\n\nERROR: allocation failure 2 in int_matrix()\n\n");
            exit(-1);
            }
        m[i] -= ncl;
        }

    return m; 

    }

//-- end int_matrix ----------------------------------------------------------------


void
normalize( int **image, int nr, int nc )
    {
    int
        shift,
        max,
        min,
        aver,
        r,
        c;

    max = image[0][0];
    min = max;

    for( r=0; r < nr; r++ )    
        {
        for( c=0; c < nc; c++ )
            {
            if ( image[r][c] < min ) min = image[r][c];
            if ( image[r][c] > max ) max = image[r][c];
            }
        }

    if ( min == max )
        {
        printf( "\n\nERROR: no contrast in image.\n\n" );
        exit(0);
        }

    aver = (max + min) / 2;

    shift = 16384 - aver;
    max   = max + shift;
    min   = min + shift;
 
    for( r=0; r < nr; r++ )    
        {
        for( c=0; c < nc; c++ )
            {
            image[r][c] += shift;
            image[r][c] = 32768 * (image[r][c] - min)  / (max  - min); 
            }
        }

    }

//-- end normalize --------------------------------------------------------------------

long *
squish( int **image, int nr, int nc, BOOL vertical )
    {

    // Average the rows or columns of the image, reuturning a 1D signal.

    int r, c;
    long *signal;

    if ( vertical )
        signal = (long *) malloc( nc * sizeof( long ) );
    else
        signal = (long *) malloc( nr * sizeof( long ) );

    if ( vertical )
        {
        for ( c=0; c < nc; c++ )
            {
            for ( r=0; r < nr; r++ )
                {
                signal[c] = (signal[c] * r + image[r][c]) / (r + 1);
                }
            }
        }    
    else
        {
        for ( r=0; r < nr; r++ )        
            {
            for ( c=0; c < nc; c++ )
                {
                signal[r] = (signal[r] * c + image[r][c]) / (c + 1);
                }
            }
        }    


    return( signal );
    }

//-- end squish -----------------------------------------------------------------------

int
find_square( long *signal, float size, int nsig, BOOL plotit, 
             float resol,  double threshold, char *model_name, int polarity )
    {
    // Use a simple 1D fit to find a bump in the signal.
    // No fancy FFTs here. If the contrast is below threshold then
    // return -1. If correlation to a bump is worse than 
    // correlation to a straight line, then return -1 also.

    long 
        top_rail,
        bottom_rail,
        model,
        temp;

    int
        n, nn,
        e,
        minc,
        i,
        isize,
        isize2,
        c,
        margin;

    double
        ft,
        fb,
        contrast,
        min,
        corr,
        left,
        right,
        slope,
        bump,
        dy,
        nobump;
    
    BOOL
        bad,
        first;

    FILE
        *out;

    // The model is a bump of width "size" deviating from a straight line.
    // We do not have to know a priori if the mark is bright or dark,
    // but if we do, then we will try to use that information.
    // This function looks for contrast in the signal, and uses that
    // for the height of the bump.


    isize  = floor( size / resol );  // the bump is this wide
    isize2 = isize / 2;

    bad = FALSE;  

    if ( nsig <= isize )
       {
       printf( "\nERROR: scan size %d is too small for mark size %d.\n", nsig, isize );
       bad = TRUE;
       }

    top_rail = signal[0];
    bottom_rail = signal[0];
    margin = nsig / 12;         
    left   = 0.0;
    right  = 0.0;
    n = 0;
    nn = 0;

    for ( i=1; i < nsig; i++ )
        {
        if ( signal[i] > top_rail    ) top_rail = signal[i];
        if ( signal[i] < bottom_rail ) bottom_rail = signal[i];
        if ( i < margin ) 
            {
            left = (left * n + signal[i]) / (n + 1);
            n++;
            }
        if ( i >= nsig-margin ) 
            {
            right = (right * nn + signal[i]) / (nn + 1);
            nn++;
            }
        }

    if ( top_rail <= bottom_rail )
        {
        printf( "\nWARNING: signal levels look wrong. Setting shift to zero.\n" );
        bad = TRUE;
        minc = -1;
        }

    slope = (right - left) / nsig;

    ft = top_rail;
    fb = bottom_rail;
    
    // Set the bump size to the maximum deviation from a straight line.

    bump = 0.0;
    for ( i=0; i < nsig; i++ )
        {
        model = slope * i + left;
        dy = signal[i] - model;
            
        if ( polarity == BRIGHT )
            {
            if ( dy > bump ) bump = dy;        
            }
        else if ( polarity == DARK )
            {
            if ( dy < bump ) bump = dy;
            }
        else 
            {
            if ( fabs( dy ) > fabs( bump ) ) bump = dy;  // sign is preserved!
            }
        }

    contrast = 100.0 * fabs( bump ) / ( (ft + fb)/2.0 );

    if ( contrast < threshold ) 
        {
        printf( "\nWARNING: contrast is too low (%1.1f). Setting shift to zero.\n", contrast );
        bad = TRUE;
        }

    if ( bad )  // dump a straight line into model.dat and return -1
        {
        if ( plotit )
            {
            out = fopen( model_name, "w" );
            for ( i=0; i < nsig; i++ )
                {
                model = bottom_rail;
                fprintf( out, "%f %d\n", i*resol,  model ); 
                }
            fclose( out );
            }
        return( -1 );
        }

    first = TRUE;

    for ( c=isize2; c < (nsig-isize2); c++ )               // c is the center of the bump. 
        {                                                  // calculate the fit to a model bump.
        corr = 0.0;
        for ( i=0; i < nsig; i++ )
            {
            if ( (i <= (c-isize2)) || (i >= (c+isize2))  )              
                {                            
                model = slope * i + left;
                }
            else
                {
                model = slope * i + left + bump;
                }

            corr = corr + fabs( model - signal[i] );
            }

        if ( first )
            {
            first = FALSE;
            min  = corr;
            minc = c;
            }
        else if ( corr < min )
            {
            min  = corr;
            minc = c;
            }
        }

    // The best correlation per pixel is "min".
    // But now what is the best correlation we should expect?
    // Let's calculate the correlation to a straight line,
    // without a bump. Then the best value, min, should
    // be smaller. Right?

    nobump = 0.0;
    for ( i=0; i < nsig; i++ )
        {
        model = slope * i + left;
        nobump = nobump + fabs( model - signal[i] );
        }

    if ( nobump < min )
        {
        printf( "\nWARNING: poor correlation. Setting shift to zero.\n" );
        minc = -1;
        bad = TRUE;
        bump = 0.0;
        }

    if ( plotit )
        {
        out = fopen( model_name, "w" );
        for ( i=0; i < nsig; i++ )
            {
            if ( (i <= (minc-isize2)) || (i > (minc+isize2)) )      
                {
                model = slope * i + left;
                }
            else
                {
                model = slope * i + left + bump;
                }
            
            fprintf( out, "%f %d\n", i*resol,  model ); 
            }
        fclose( out );
        }

    return( minc );

    }

//-- end find_square --------------------------------------------------------------------

void
show_plot( char *title1, char *title2 )
    {            
    // Use gnuplot to show the signal and model
    
    FILE *gnu;   // Generate signal.gnu file
    
    gnu = fopen( "hsignal.gnu", "w" );
    if ( strlen( title1 ) > 0 ) fprintf( gnu, "set title \"%s\"\n", title1 ); 
    fprintf( gnu, "set xlabel \"um\"\n" );
    fprintf( gnu, "set ylabel \"signal\"\n" );
    fprintf( gnu, "plot \"hsignal.dat\" title \"signal\" with lines lt rgb \"blue\", \\\n" );
    fprintf( gnu, "\"hmodel.dat\"  title \"model\"  with lines lt rgb \"red\"\n" ); 
    fclose(  gnu );
    system( "gnuplot -persist hsignal.gnu" );

    gnu = fopen( "vsignal.gnu", "w" );
    if ( strlen( title2 ) > 0 ) fprintf( gnu, "set title \"%s\"\n", title2 ); 
    fprintf( gnu, "set xlabel \"um\"\n" );
    fprintf( gnu, "set ylabel \"signal\"\n" );
    fprintf( gnu, "plot \"vsignal.dat\" title \"signal\" with lines lt rgb \"blue\", \\\n" );
    fprintf( gnu, "\"vmodel.dat\"  title \"model\"  with lines lt rgb \"red\"\n" ); 
    fclose(  gnu );
    system( "gnuplot -persist vsignal.gnu" );
    }



//-- end show_plot --------------------------------------------------------------------
    
//-------------------------------------------------------------------------------------

int main( int argc, char *argv[] )
    {

    int
        xcenter,
        ycenter,
        i,
        fd,
        r,
        c,
        nr,
        nc;

    float
        x,
        dx, dy,
        resol,
        size;

    double
        threshold;

    char
        *title,
        *command,
        *imagename,
        *argstr;

    BOOL
        plotit;

    short int
        si;

    int
        polarity,
        **image;

    long
        *hsignal,
        *vsignal;

    FILE
        *plot;

    argstr    = (char *) malloc( 256 );
    imagename = (char *) malloc( 256 );
    command   = (char *) malloc( 256 );


    if( argc < 7 )
        {
        printf( "\nfind_square version 2\n" );
        printf( "\nUse: find_square size_um imagefile.img xpixels ypixels nm/pixel plot|noplot [threshold %] [bright|dark]\n\n" );
        printf(   "     Given an image of a square, find the center and then move the EBPG\n" );
        printf(   "     stage to that location. The threshold defaults to 10%s. If you do not\n", "\045\0" ); 
        printf(   "     stipulate 'bright' or 'dark' then we assume the mark might be either. \n" );
        printf(   "     Image files are 16-bit raw format. The suffix ('.img' or '.raw') should be\n" );
        printf(   "     included. Use the 'plot' option to display the signal with gnuplot.\n" );
        printf(   "     After finding the center, this program will move the EBPG stage there.\n" );
        printf(   "     Your script can then grab the stage coordinate with 'pg get table'. \n\n" );
        exit(0);
        }

    sscanf( argv[1], "%f", &size );
    imagename = argv[2];
    sscanf( argv[3], "%d", &nc );
    sscanf( argv[4], "%d", &nr );
    sscanf( argv[5], "%f", &resol );
    plotit = (strcmp( argv[6], "plot"  ) == 0);

    if ( argc > 7 )
        sscanf( argv[7], "%lf", &threshold );
    else
        threshold = THRESHOLD;

    polarity = EITHER;

    if ( argc > 8 )
        {
        if ( strcmp( argv[8], "bright" ) == 0 ) 
            polarity = BRIGHT;
        else
            polarity = DARK;
        }
    

    printf( "\n        Image:     %s\n", imagename );
    printf(   "        Size:      %1.2f um\n", size );
    printf(   "        Pixels:    %d x %d \n", nr, nc ); 
    printf(   "        Resol:     %1.1f nm\n", resol );
    printf(   "        Threshold: %1.2lf \045 \n", threshold );

    if ( polarity == BRIGHT ) printf( "        Polarity:  Bright\n\n" );
    if ( polarity == DARK   ) printf( "        Polarity:  Dark\n\n" );
    if ( polarity == EITHER ) printf( "        Polarity:  Unknown\n\n" );

    resol = resol / 1000.0;   // um

    image = (int **) int_matrix( 0, nc-1, 0, nr-1 );

    fd  = open( imagename, 0 );
    if ( fd <= 0 )
        {
        printf( "\nERROR: unable to open %s\n\n", imagename );
        exit(0);
        }

    for ( r=0; r < nr; r++ )
        for ( c=0; c < nc; c++ )
            {
            if( ! read( fd, &si, 2 ) )
                {
                printf( "\nERROR: unexpected end of file %s\n", imagename );
                exit(0);
                }
            image[r][c] = si;
            }

    close( fd );

    normalize( image, nr, nc );

    hsignal = squish( image, nr, nc, TRUE  );
    vsignal = squish( image, nr, nc, FALSE );

    xcenter = find_square( hsignal, size, nc, plotit, resol, threshold, "hmodel.dat", polarity );
    ycenter = find_square( vsignal, size, nr, plotit, resol, threshold, "vmodel.dat", polarity );

    if ( plotit )
        {
        plot = fopen( "hsignal.dat", "w" );
        for ( i=0; i < nc; i++ ) 
            { 
            x = i * resol;
            fprintf( plot, "%1.3f %d\n", x, hsignal[i] );
            }
        fclose( plot );

        plot = fopen( "vsignal.dat", "w" );
        for ( i=0; i < nr; i++ ) 
            { 
            x = i * resol;
            fprintf( plot, "%1.3f %d\n", x, vsignal[i] );
            }
        fclose( plot );

        show_plot( "horizontal", "vertical" );
        }

    // Move the stage to the center of the mark.

    if ( xcenter < 0 )
        dx = 0.0;
    else
        dx = resol * (xcenter - (nc - 1.0) / 2.0);

    if ( ycenter < 0 )
        dy = 0.0;
    else
        dy = -resol * (ycenter - (nr - 1.0) / 2.0);
   
    sprintf( command, "pg move pos --rel %1.3f,%1.3f", dx, dy );
        
    printf( "\n        %s\n\n", command );

    system( command );

    // The calling script must now query the stage coordinate
    // with "pg get tab"

    }

