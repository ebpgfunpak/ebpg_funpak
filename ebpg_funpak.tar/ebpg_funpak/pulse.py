#!/usr/bin/env python3

import sys
import os
import math

if len( sys.argv ) < 2 : sys.exit()
bigfile = sys.argv[1]
ls = os.popen( "ls -l %s" % bigfile ).read()
word = ls.split()

if len(word) < 5 : sys.exit()

try:
    size = int( word[4] )
except:
    size = 0

estime  = 1.7e-7 * size
minutes = math.floor( estime / 60.0 )
seconds = estime - minutes * 60


if seconds < 10 : 
    ssecs = "0%d" % seconds
else:
    ssecs = "%d" % seconds

if estime > 60 :
    print("Estimated time to completion: %d:%s minutes" % (minutes, ssecs))
else:
    print("Estimated time to completion: %d seconds" % (estime))

sys.stdout.flush()

time_left = estime

while time_left > 10.0 :
    minutes = math.floor( time_left / 60.0 )
    seconds = time_left - minutes * 60
    if seconds < 10 : 
        ssecs = "0%d" % seconds
    else:
        ssecs = "%d" % seconds
    if time_left > 60 :
        print(" \010%d:%s minutes \015" % (minutes, ssecs)) 
    else:
        print(" \010%d seconds \015" % time_left)
    sys.stdout.flush()
    os.system( "sleep 3" )
    time_left = time_left - 3.0

print(" \010 soon...\015 ")
sys.stdout.flush()






