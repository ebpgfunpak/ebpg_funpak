#!/usr/bin/env python3


"""
ybrsort.py 

Requires gpfgtx and gtxgpf programs.

This program reads a gpf file and sorts the shapes into yellow-brick-road
order. This might be described as a "proximity sort", since we will try 
to stick together shapes that appear near each other.  

The blocks are not sorted. You can use the utility gpfsort for that.

v2    Sorts multiple fields, as does the original radial_sort.py 

v3    Finds neighboring shapes with a rolling list instead of recursion.
      Otherwise each shape is limited to 900 trapezoids.

v4    Instead of searching n times through the entire list of shapes,
      we create a list of shapes which are contained in each subfield.
      Then we search through just the local subfields. Big improvement.

v5    If we start gathering shapes in the middle of a long thing, then
      the writing order splits, and the beam flips back and forth along
      the shape. We needed a better way to pick the starting point.
      The last item on the list is likely to be one of the end points
      of a structure, so now we use the last point as the starting point
      for a second pass. This works quite well.

v6    Now handles multiple fields, unlike version 2 which was stupid.

v6.2  Chunk set to half the subfield size. Grouping and sorting will 
      not work otherwise.

v7.0  path option - sort by a given path

v7.1  Tries to ignore FIELDOFFSET line, hoping it's zero, whatever that means.

v7.2  Deals with the stupid syntax change in gpfgtx

v7.3  Just in case you are using an old version of gpfgtx, we now replace 
      "RANDOM" with "FLOATING" in the header.

v7.4  Single-field patterns now work. What a bloody mess this code is.
      Don't look; it's hideous. The double loop in main() needs to be
      completely rewritten.

v7.5  some versions of gpfgtx screw with the output file name. we fix that.

v7.6  converted to python3

"""
import os
import sys
import math
import string
import operator
from math import *

version = 7.6

recursion = 0
shape = 0

# This is where you can specify a different command for gpfgtx and gtxgpf,
# in case you have kept the old, fast versions in a different place.

GPFGTX="gpfgtx"
GTXGPF="gtxgpf"

#-----------------------------------------------------------------------------------------------

def gpfgtx( infile, outfile ):
    #
    # The old gpfgtx worked just fine, but the new version 
    # screws with the file names. This function will 
    # try first with the old syntax. If that fails, it 
    # will try again with the new syntax. Finally, we 
    # will unscrew the file names if necessary.
    # 
    global GPFGTX

    if not ".gpf" in infile :
        print("\nERROR: gpf file name must end in .gpf\n") 
        sys.exit()
    if not ".gtx" in outfile :
        print("\nERROR: gtx file name must end in .gtx\n") 
        sys.exit()

    os.system( "%s %s %s &> gpfgtx.log" % (GPFGTX, infile, outfile) )
    log = open( "gpfgtx.log", "r" )
    no_file = False
    for stuff in log.readlines() :
        stuff = stuff.lower()
        if "could not open" in stuff or \
           "can't open"     in stuff or \
           "no such file"   in stuff or \
           "usage"          in stuff :
            no_file = True
            break
    log.close()
    
    # maybe we have the new, stupid version

    if no_file :
        name = infile.split('.')[0]
        os.system( "%s ./%s.gpf &> gpfgtx.log" % (GPFGTX, name) )
        log = open( "gpfgtx.log", "r" )
        no_file = False
        for stuff in log.readlines() :
            stuff = stuff.lower()
            if "could not open" in stuff or \
               "can't open"     in stuff or \
               "no such file"   in stuff or \
               "usage"          in stuff :
                no_file = True
                break
        log.close()
        if no_file :
            print("\nERROR: no such file: %s\n" % infile)
            sys.exit()
        os.system( "mv %s_gpf.gtx %s" % (name, outfile) )    
          

    # maybe we gpfgtx screwed with the output file name
    # Raith says, because f*#k you that's why

    try:
        fooked_name = outfile.split('.')[0] + "_gpf.gtx"
        fooked = open( fooked_name, "r" )
        fooked.close()
        print((     "mv %s %s" % (fooked_name, outfile) ))
        os.system( "mv %s %s" % (fooked_name, outfile) )
    except:
        print(":)")

             
#-------------------------------------------------------------------------

def zap( something ):
    os.system( "rm -f .hitlist" )
    os.system( "echo $USER > .hitlist" )
    os.system( "ps axu | grep -e '%s' >> .hitlist" % something )
    hitlist = open( ".hitlist" )
    first = True

    for line in hitlist.readlines():
        if first : 
            user = line[:-1]
            first = False
        else:
            if user in line and "ybrsort" not in line and "grep" not in line:
                word = line.split()[1]
                print("killing ", word)
                os.system( "kill -9 %s" % word )

    os.system( "rm -f .hitlist" )


#-----------------------------------------------------------------------------------------------

def sort_table(table, cols):
    """ 
    sort a table by multiple columns
    table: a list of lists (or tuple of tuples) where each inner list represents a row
    cols:  a list (or tuple) specifying the column numbers to sort by
    """

    is_a_list = True
    try:
        len( cols )
        print("...") 
    except:
        is_a_list = False

    if is_a_list:
        rcols = reversed( cols )
        for col in rcols :
            table = sorted(table, key=operator.itemgetter(col))
    else:
        table = sorted(table, key=operator.itemgetter(cols))


    return table

#--------------------------------------------------------------------------------------------------------------

def Plot( city, R ):

    lowx = R[city[0]][14]
    lowy = R[city[0]][15]
    highx = lowx
    highy = lowy
    for c in R:
        if c[14] < lowx  : lowx  = c[14]
        if c[15] < lowy  : lowy  = c[15]
        if c[14] > highx : highx = c[14]
        if c[15] > highy : highy = c[15]
    extrax = abs( highx - lowx ) / 10.0
    extray = abs( highy - lowy ) / 10.0
    lowx = lowx - extrax
    highx = highx + extrax
    lowy = lowy - extray
    highy = highy + extray
    dx = highx - lowx
    dy = highy - lowy
    if dx > dy :
        morey = (dx - dy) / 2.0
        lowy = lowy - morey
        highy = highy + morey
    elif dy > dx :
        morex = (dy - dx) / 2.0
        lowx = lowx - morex
        highx = highx + morex
    gnufile = open( "path.gnu", "w" )
    gnufile.write( "set xlabel \"X\"\n" )
    gnufile.write( "set ylabel \"Y\"\n" )
    gnufile.write( "set size square\n" )
    gnufile.write( "set xrange [%1.2f:%1.2f]\n" % (lowx, highx) )
    gnufile.write( "set yrange [%1.2f:%1.2f]\n" % (lowy, highy) )
    gnufile.write( "plot \"path.dat\" title '' with lines lt rgb \"blue\"\n" )
    gnufile.close()
    Pt = [R[city[i]] for i in range(len(city))]
    out = open( "path.dat", "w" )
    for p in Pt:
        out.write( "%f, %f\n" % (p[14], p[15]) )
    out.close()
    os.system( "gnuplot -persist path.gnu" )
    

#====================================================================================================
# Yellow Brick Road sorting functions

def twiddle( t ):    # display an amusing progress report, or not
    t += 1
    wait = " "
    if t == 0 : wait = "."
    if t == 1 : wait = ".."
    if t == 3 : wait = "..."
    if t == 4 : wait = "...."
    if t > 4  : t = 0
    #print " \010 %s \015" % wait,
    sys.stdout.flush()
    return t

def YBRdistance( t, p ):
    """
    t is an entry in the big table of shapes. p is a coordinate
    in mainfield units (field center is 524288,524288).
    This function returns the disance in main field units (usually nm).
    """

    dx = abs( t[14] - p[0] )
    dy = abs( t[15] - p[1] )
  
    d = math.sqrt( dx*dx + dy*dy ) 

    return( d )
 

def overlap( llx, lly, urx, ury, pllx, plly, purx, pury ) :
    if pllx > urx : return False
    if purx < llx : return False
    if plly > ury : return False
    if pury < lly : return False
    return True

def local_group( g, R, subfield ):
    """
    Gather a list of shapes that are near shape "g".
    Look in the nearby subfields.
    """
    sx = R[g][18]
    sy = R[g][19]
    n = len( subfield )
    lg = []
    if not R[g][16] : return lg   # if not active

    for dx in range(-2,3) :     
        x = sx + dx
        if x >= 0 and x < n:
            for dy in range(-2,3) : 
                y = sy + dy
                if y >=0 and y < n :
                    for j in subfield[x][y] : 
                        if R[j][16] : lg.append( j )
                #
            #
        #
    #
    return lg
    

def look_for_neighbors( p, R, chunk, city, subfield ):
    """
    p is an index to one entry in the big table. R is the whole big table of shapes.
    w2 and h2 are in main field units. city is the list of
    indices into the big table. We use a rolling list here, not recursion.
    """
    global shape
    global recursion


    if not R[p][16] or R[p][17] :   # if not active or already hit
        return city  

    t = 0
    n = len( R )
    g = p            # starting point
    group = [g]      # list of connected shapes
    R[g][17] = True  # hit!
    gi = 0           # index into the group list

    while gi < len( group ) :
        g = group[gi]
        pllx = R[g][14] - chunk
        purx = R[g][14] + chunk
        plly = R[g][15] - chunk
        pury = R[g][15] + chunk
        lg = local_group( g, R, subfield )
        
        for i in lg : # range(n) : 
            if i != g and R[i][16] and not R[i][17] : # if the item is active and has not been hit...
                llx = R[i][14] - chunk
                urx = R[i][14] + chunk
                lly = R[i][15] - chunk
                ury = R[i][15] + chunk
                if overlap( llx, lly, urx, ury, pllx, plly, purx, pury ) and not R[i][17] and R[i][16] :
                    group.append( i )
                    R[i][17] = True   # hit!
                #end if
            #end if
        #end for
        if gi < len( group ) : 
            gi += 1
            recursion = len(group) - gi
            shape += 1
            #if shape % 100 == 0 : t = twiddle( t )
    
    city = city + group

    return (city)
        

def look_for_starting_point( p, R, chunk, subfield ):
    """
    p is an index to one entry in the big table. R is the whole big table of shapes.
    city is the list of indices into the big table. 
    """

    if not R[p][16] or R[p][17] : 
        return -1   # if this shape is inactive or has already been hit

    t = 0
    n = len( R )
    g = p            # starting point
    group = [g]      # list of connected shapes
    gi = 0           # index into the group list
    unhit_list = []

    while gi < len( group ) :
        g = group[gi]
        pllx = R[g][14] - chunk
        purx = R[g][14] + chunk
        plly = R[g][15] - chunk
        pury = R[g][15] + chunk
        lg = local_group( g, R, subfield )

        for i in lg : # range(n) : 
            if i != g and R[i][16] and not R[i][17] : # if the item is active and has not been hit...
                llx = R[i][14] - chunk
                urx = R[i][14] + chunk
                lly = R[i][15] - chunk
                ury = R[i][15] + chunk
                if overlap( llx, lly, urx, ury, pllx, plly, purx, pury ) and not R[i][17] :
                    group.append( i )
                    R[i][17] = True   # hit! but not permanently!
                    unhit_list.append( i )
                #end if
            #end if
        #end for
        gi += 1

    for c in unhit_list : R[c][17] = False

    if len( group ) > 1 :
        start = group[-1]
    else:
        start = group[0]

    if not R[start][16] :
        print("\nERROR: starting point is not active.\n")
        sys.exit()
    
    return start
        

def presort( R, x, chunk, fullfield ):
    """
    Generate a list of shapes in each subfield. 
    """
    nx = int( fullfield / chunk ) + 1
    ny = nx

    subfield = [[ [] for i in range(ny)] for j in range(nx) ]

    for i in range( len(R) ):
        t = R[i]
        if t[16] :
            sx = R[i][18]
            sy = R[i][19]
            subfield[sx][sy].append( i )
  
    return subfield


def yellow_brick_road_sort( R, chunk, x0, y0, fullfield ):
    """
    Follow the yellow brick road! In other words, gather together
    shapes that are near one another. We look_for_neighbors twice:
    first to find a good starting point, and then again to create
    a list that goes from the "beginning" to the "end" of each shape.

    R is the big table of shapes. (xblock,yblock) in this program is
    the region of "nearness", in main field units, usually a subfield 
    of 1 um. (x0,y0) is the starting point, which shouldn't matter. 
    """
    print("Sorting... ", end=' ')
    sys.stdout.flush()

    subfield = presort( R, x, chunk, fullfield )

    ncity = len( R )
    print("Number of shapes: %d" % ncity) 
    mind = YBRdistance( R[0], [x0, y0] )
    munchkindex = -1

    for i in range( ncity ):
        if R[i][16] :  # if active
            d = YBRdistance( R[i], [x0, y0] )
            if d < mind :
                mind = d
                munchkindex = i

    #print "\nMunchkinland is nearest to shape %d" % munchkindex 

    #print " \010 first pass \015"
    sys.stdout.flush()

    firstpass = []
    fulltrip  = []
    start = look_for_starting_point( munchkindex, R, chunk, subfield  )
    
    #print " \010 second pass \015" 
    sys.stdout.flush()

    if start >= 0 :
        fulltrip = look_for_neighbors( start, R, chunk, fulltrip, subfield )
    else:
        print("ERROR: CANNOT FIND A STARTING POINT, EVEN AT FIRST. I'M SO CONFUSED.")
        sys.exit()
    
    for i in range( munchkindex, ncity ):
        #print "%d" % i 
        sys.stdout.flush()

        if R[i][16] and not R[i][17] : # if active and not hit    
            firstpass = []
            start = look_for_starting_point( i, R, chunk, subfield )
            if start >= 0 :
                fulltrip = look_for_neighbors( start, R, chunk, fulltrip, subfield )
        if len( fulltrip ) == ncity : break

    for i in range( 0, munchkindex ):
        #print "%d" % i 
        sys.stdout.flush()
        if R[i][16] and not R[i][17] : # if active and not hit
            firstpass = []
            start = look_for_starting_point( i, R, chunk, subfield )
            if start >= 0 :
                fulltrip = look_for_neighbors( start, R, chunk, fulltrip, subfield )
        if len( fulltrip ) == ncity : break
    
    zap( "gnuplot" )
    Plot( fulltrip, R )
        
    return( fulltrip )

#====================================================================================================


# Parse one line of "repetition". This is woefully and gloriously complex, 
# and should not be necessary.


def parse( line, mx1c, mx2c, my1c, my2c, sx1c, sx2c, sy1c, sy2c, m1dx, m1dy, m2dx, m2dy, s1dx, \
    s1dy, s2dx, s2dy, base, height, msf, main_resol, sub_resol ) :
    if not hasattr( parse, "init" ): 
        parse.init = True
        parse.m1c  = 0
        parse.m2c  = 0  # static variables
        parse.s1c  = 0
        parse.s2c  = 0

    lines = line.split( '\n' )

    for bit in lines:    
        bits = bit.split()

        if "Repetition Main 1 X Count" in bit: 
            mx1c = int( bits[5] )
            parse.m1c = mx1c
        elif "Repetition Main 1 X LSW" in bit:
            m1dx = int( bits[5] )
        elif "Repetition Main 1 Y Count" in bit: 
            my1c = int( bits[5] )
        elif "Repetition Main 1 Y LSW" in bit:
            m1dy = int( bits[5] )
        elif "Repetition Main 1 Count" in bit and not ("Y" in bits) and not ("X" in bits) :
            parse.m1c  = int( bits[4] )  
        elif "Repetition Main 2 Count" in bit and not ("Y" in bits) and not ("X" in bits) :
            parse.m2c  = int( bits[4] )
        elif "Repetition Main 2 X LSW" in bit:
            m2dx = int( bits[5] )
        elif "Repetition Main 2 X Count" in bit:
            mx2c = int( bits[5] )
        elif "Repetition Main 2 Y Count" in bit:
            my2c = int( bits[5] )
            parse.m2c = my2c
        elif "Repetition Main 2 Y LSW" in bit:
            m2dy = int( bits[5] )
        elif "Repetition Sub 1 X" in bit and not ("Count" in bits):
            s1dx = int( bits[4] )
        elif "Repetition Sub 1 X Count" in bit: 
            sx1c = int( bits[5] )
            parse.s1c = sx1c
        elif "Repetition Sub 1 Y Count" in bit:
            sy1c = int( bits[5] )
        elif "Repetition Sub 1 Y" in bit and not ("Count" in bits):
            s1dy = int( bits[4] )
        elif "Repetition Sub 1 Count" in bit and not ("Y" in bits) and not ("X" in bits) :
            parse.s1c  = int( bits[4] )   
        elif "Repetition Sub 2 X" in bit and not ("Count" in bits):
            s2dx = int( bits[4] )
        elif "Repetition Sub 2 X Count" in bit:
            sx2c = int( bits[5] )
        elif "Repetition Sub 2 Y" in bit and not ("Count" in bits):
            s2dy = int( bits[4] )
        elif "Repetition Sub 2 Y Count" in bit:
            sy2c = int( bits[5] )
            parse.s2c = sy2c
        elif "Repetition Sub 2 Count" in bit and not ("Y" in bits) and not ("X" in bits) :
            parse.s2c  = int( bits[4] )
        elif "Repetition" in bits:
            print("\nUnknown repetition line: [%d]\n" % bit) 

        # Are the following correct? It might be that some parameters need to be
        # retained and used by implication in successive Activate lines.

        if "Activate" in bits and "SRV1" in bits and not ("SRV2" in bits):
            m1dx = 0
            m1dy = 0
            m2dx = 0
            m2dy = 0
            mx1c = 0
            my1c = 0
            mx2c = 0
            my2c = 0
            sx2c = 0
            sy2c = 0
            s2dx = 0
            s2dy = 0

        if "Activate" in bits and "SRV2" in bits and not ("SRV1" in bits):
            m1dx = 0
            m1dy = 0
            m2dx = 0
            m2dy = 0
            mx1c = 0
            my1c = 0
            mx2c = 0
            my2c = 0
            sx1c = 0
            sy1c = 0
            s1dx = 0
            s1dy = 0

        if "Activate" in bits and "MRV1" in bits and not ("MRV2" in bits):
            s1dx = 0
            s1dy = 0
            s2dx = 0
            s2dy = 0
            sx1c = 0
            sy1c = 0
            sx2c = 0
            sy2c = 0
            mx2c = 0
            my2c = 0
            m2dx = 0
            m2dy = 0

        if "Activate" in bits and "MRV2" in bits and not ("MRV1" in bits):
            s1dx = 0
            s1dy = 0
            s2dx = 0
            s2dy = 0
            sx1c = 0
            sy1c = 0
            sx2c = 0
            sy2c = 0
            mx1c = 0
            my1c = 0
            m1dx = 0
            m1dy = 0

        if "Activate" in bits and "SRV1" in bits and "SRV2" in bits:
            m1dx = 0
            m1dy = 0
            m2dx = 0
            m2dy = 0
            mx1c = 0
            my1c = 0
            mx2c = 0
            my2c = 0

        if "Activate" in bits and "MRV1" in bits and "MRV2" in bits:
            s1dx = 0
            s1dy = 0
            s2dx = 0
            s2dy = 0
            sx1c = 0
            sy1c = 0
            sx2c = 0
            sy2c = 0

        if "Activate" in bits and "MRV1" in bits:
            mx1c = parse.m1c

        if "Activate" in bits and "MRV2" in bits:
            my2c = parse.m2c

        if "Activate" in bits and "SRV1" in bits:
            sx1c = parse.s1c

        if "Activate" in bits and "SRV2" in bits:
            sy2c = parse.s2c

        # RYH and RXB are used to chop shapes into subfield traps.
        # The savings in space is negligible, but it might prevent
        # blanking between shapes. Let's hope so; otherwise,
        # it's just stupid.

        # V1 is X only, V2 is Y only 

        if "RXB" in bits or "RYH" in bits:  
            s1dx = 0
            s1dy = 0
            s2dx = 0
            s2dy = 0
            m1dx = 0
            m1dy = 0
            m2dx = 0
            m2dy = 0

        if sub_resol <= 0 :
            print("\nERROR: subfield resolution not defined.\m")
            sys.exit()

        h = int( height )
        b = int( base )
        m = int( msf )

        if "RYH" in bits:                           
            if "SRV1" in bits or "SRV2" in bits: 
                s2dy = (h + 1) * m
            elif "MRV1" in bits or "MRV2" in bits:
                m2dy = (h + 1) * m * main_resol/sub_resol

        if "RXB" in bits:
            if "SRV1" in bits or "SRV2" in bits: 
                s1dx = (b + 1) * m
            elif "MRV1" in bits or "MRV2" in bits:
                m1dx = (b + 1) * m * main_resol/sub_resol

    # end for bit


    return( (mx1c, mx2c, my1c, my2c, sx1c, sx2c, sy1c, sy2c, m1dx, m1dy, m2dx, m2dy, s1dx, s1dy, s2dx, s2dy ) )


#-----------------------------------------------------------------------------------------------

def expand_array( entry, n, table, mx1c, mx2c, my1c, my2c, sx1c, sx2c, sy1c, sy2c, \
                  m1dx, m1dy, m2dx, m2dy, s1dx, s1dy, s2dx, s2dy, mainpersub, chunk, \
                  center, mfr, patcenterx, patcentery, path ):
           
    # Loop over x and y repeats, generating new table entries 
    # Could there be both main and subfield repeats on the same line?
    # That would be perverse, so let's just check for perversity first.
    # Be sure to turn off "compaction" of any sort in Beamer.

    main_repeat = mx1c > 0 or mx2c > 0 or my1c > 0 or my2c > 0
    sub_repeat  = sx1c > 0 or sx2c > 0 or sy1c > 0 or sy2c > 0

    if not main_repeat and not sub_repeat:
        print("\nERROR: an array contains no repetition values\n")
        print(entry)
        print() 
        sys.exit()

    if main_repeat and sub_repeat:
        print("\nERROR: mainfield and subfield arrays appear sumultaneously. This freaks me out, man.")
        print("Try disabling all compaction modes in Beamer (or whatever you used to generate gpf).")
        print("Be sure to disable Beamer's 'compaction diagonal array' option, which is evil.")
        print("Program aborted.")
        sys.exit()

    activate_line = entry[0]
    main_x_lsw    = entry[1]
    main_y_lsw    = entry[2]
    freq_lsw      = entry[3]
    freq_msw      = entry[4]
    base_lsw      = entry[5]
    height_lsw    = entry[6]
    msf           = entry[7]
    shift_lt_lsw  = entry[8]
    shift_rb_lsw  = entry[9]
    offset_x_lsw  = entry[10]
    offset_y_lsw  = entry[11]
    shift_rb_used = entry[12]
    shift_lt_used = entry[13]
    fieldx        = entry[20]
    fieldy        = entry[21]

    ioffset_x = int( offset_x_lsw )
    ioffset_y = int( offset_y_lsw )
    ibase = int( base_lsw )
    iheight = int( height_lsw )
    imsf = int( msf )

    table[n][16] = False   # not active
    table[n][14] = -1000
    table[n][15] = -1000
    table[n][18] = -1000
    table[n][19] = -1000

    if main_repeat:
        # strip out MRV1, MRV2, RXB, and RYH from acitivate line
        # loop over mx1c and my2c. Watch for nonzero my1c and mx2c.

        newline = ""
        words = activate_line.split()

        begin = False
        for word in words:
            if (word == "Activate"): begin = True
            if begin and word != "MRV1" and word != "MRV2" and word != "RXB" and word != "RYH" :
                newline = newline + " " + word

        #print "[%s]" % newline
 
        if my1c != 0 or mx2c != 0 :
            print("\nERROR: strange array with my1c or mx2c not zero: [%s]." % activate_line)
            print("What does it mean?")
            print("Try disabling all compaction modes in Beamer (or whatever you used to generate gpf).")
            print("Be sure to disable Beamer's 'compaction diagonal array' option, which is evil.\n")
            sys.exit() 
        
        mainx = int( main_x_lsw )
        mainy = int( main_y_lsw )

        for row in range( my2c+1 ):
            y = mainy + m2dy * row
            mainy_s = "%d" % y
            for col in range( mx1c+1 ):
                x = mainx + m1dx * col
                mainx_s = "%d" % x
                if path:
                    fx = x + (ioffset_x/mainpersub) + (ibase + 1)   * imsf / (2.0 * mainpersub)
                    fy = y + (ioffset_y/mainpersub) + (iheight + 1) * imsf / (2.0 * mainpersub)
                    fx = fieldx + (fx - center) * mfr
                    fy = fieldy + (fy - center) * mfr
                    fx = fx + patcenterx
                    fy = fy + patcentery
                    """
                    if fx > 1000 :
                        print "NOPE!"
                        print "main_x_lsw = ", main_x_lsw
                        print "ioffset_x =  ", ioffset_x
                        print "mainpersub = ", mainpersub
                        print "ibase =      ", ibase
                        print "imsf =       ", imsf
                        print "fieldx =     ", fieldx
                        print "center =     ", center
                        print "mfr =        ", mfr
                        print "patcenterx = ", patcenterx
                        print "fx =         ", fx
                        sys.exit()
                    """
                else:
                    fx = x + float(offset_x_lsw) / mainpersub     
                    fy = y + float(offset_y_lsw) / mainpersub
                    
                sx = int( fx / chunk )  
                sy = int( fy / chunk )

                table.append( [ newline, \
                                mainx_s,       \
                                mainy_s,       \
                                freq_lsw,      \
                                freq_msw,      \
                                base_lsw,      \
                                height_lsw,    \
                                msf,           \
                                shift_lt_lsw,  \
                                shift_rb_lsw,  \
                                offset_x_lsw,  \
                                offset_y_lsw,  \
                                shift_rb_used, \
                                shift_lt_used, \
                                fx,  \
                                fy,  \
                                True,  \
                                False, \
                                sx, sy, fieldx, fieldy  ]  )  # [16] = "active", [17] = "hit"
    else:  # subfield repeat
        # strip out SRV1, SRV2, RXB, and RYH from acitivate line
        # loop over sx1c and sy2c. Watch for nonzero sy1c and sx2c.

        newline = ""
        words = activate_line.split()

        begin = False
        for word in words:
            if (word == "Activate"): begin = True
            if begin and word != "SRV1" and word != "SRV2" and word != "RXB" and word != "RYH" :
                newline = newline + " " + word

        #print "[%s]" % newline
 
        if sy1c != 0 or sx2c != 0 :
            print("\nERROR: strange array with sy1c or sx2c not zero: [%s]." % activate_line) 
            print("What does it mean?")
            print("Try disabling all compaction modes in Beamer (or whatever you used to generate gpf).")
            print("Be sure to disable Beamer's 'compaction diagonal array' option, which is evil.\n")
            sys.exit() 
        
        subx = int( offset_x_lsw )
        suby = int( offset_y_lsw )

        for row in range( sy2c+1 ):
            y = suby + s2dy * row
            suby_s = "%d" % y
            for col in range( sx1c+1 ):
                x = subx + s1dx * col
                subx_s = "%d" % x

                if path:
                    fx = x + (ioffset_x/mainpersub) + (ibase + 1)   * imsf / (2.0 * mainpersub)
                    fy = y + (ioffset_y/mainpersub) + (iheight + 1) * imsf / (2.0 * mainpersub)
                    fx = fieldx + (fx - center) * mfr
                    fy = fieldy + (fy - center) * mfr
                    fx = fx + patcenterx
                    fy = fy + patcentery
                else:
                    fx = float(main_x_lsw) + x / mainpersub
                    fy = float(main_y_lsw) + y / mainpersub

                sx = int( fx / chunk )
                sy = int( fy / chunk )
                table.append( [ newline, \
                                main_x_lsw,    \
                                main_y_lsw,    \
                                freq_lsw,      \
                                freq_msw,      \
                                base_lsw,      \
                                height_lsw,    \
                                msf,           \
                                shift_lt_lsw,  \
                                shift_rb_lsw,  \
                                subx_s,        \
                                suby_s,        \
                                shift_rb_used, \
                                shift_lt_used, \
                                fx, \
                                fy, \
                                True,  \
                                False, \
                                sx, sy, fieldx, fieldy    ]  ) # [16] = "active", [17] = "hit"


    return( table )

#-----------------------------------------------------------------------------------------------


def flatten( table, main_resol, sub_resol, mainpersub, chunk, center, mfr, patcenterx, patcentery, path ):

    # look for repetition lines, creating explicit shapes instead

    mx1c = 0  # main x1 count
    mx2c = 0  # main x2 count
    my1c = 0
    my2c = 0
    sx1c = 0  # subfield x1 count
    sx2c = 0  # subfield x2 count
    sy1c = 0
    sy2c = 0
    m1dx = 0  # main 1 delta x, in mainfield resolution units
    m1dy = 0
    s1dx = 0  # subfield 1 delta x, in subfield resolution units
    s1dy = 0
    m2dx = 0  
    m2dy = 0
    s2dx = 0  
    s2dy = 0

    #print "mx1c mx2c my1c my2c sx1c sx2c sy1c sy2c m1dx m1dy m2dx m2dy s1dx s1dy s2dx s2dy"

    n = 0
    numshapes = len( table )
    for n in range( numshapes ): # entry in table:
        entry  = table[n]
        base   = entry[5]
        height = entry[6]
        line   = entry[0]
        msf    = entry[7]

        if "Control" in line:
            print("\nERROR: NEGATIVE ARRAY COUNT. YOU SHOULD DISABLE DIAGONAL COMPACTION.\n")
            print(line)
            print()
            sys.exit()

        if "SRV1" in line or "SRV2" in line or "MRV1" in line or "MRV2" in line :
            mx1c, mx2c, my1c, my2c, sx1c, sx2c, sy1c, sy2c, m1dx, m1dy, m2dx, m2dy, s1dx, s1dy, s2dx, s2dy  = \
            parse( line, mx1c, mx2c, my1c, my2c, sx1c, sx2c, sy1c, sy2c, m1dx, m1dy, m2dx, m2dy, s1dx, s1dy, \
                   s2dx, s2dy, base, height, msf, main_resol, sub_resol ) 
            table = expand_array( entry, n, table, mx1c, mx2c, my1c, my2c, sx1c, sx2c, sy1c, sy2c, \
                   m1dx, m1dy, m2dx, m2dy, s1dx, s1dy, s2dx, s2dy, mainpersub, chunk, \
                   center, mfr, patcenterx, patcentery, path )

    # get rid of those pesky array entries because they sneek back in!

    i = 0
    while i < len( table ) :
        if not table[i][16] : 
            del table[i]
        else:
            i = i + 1
        

    return( table )

#-----------------------------------------------------------------------------------------------

def print_use():
    print("\nybrsort version %1.1f : sort gpf shapes by proximity or by a given path." % version)
    print("\nUse: ybrsort.py [-path [pathfile]] [file.gpf|file.gtx]")
    print("     The output file will be file_sorted.gpf")
    print("     If a path is used then the coordinates in your path file")
    print("     should be the same as those of the original CAD file,")
    print("     and the path file should specify the lower-left and ")
    print("     upper-right coordinates. The path file defaults to path.txt\n")
    print("     Note that YBR sorting (the default) works well on snake-like pattens ")
    print("     but does not work with loops. If you have loops, you should use")
    print("     a path.\n\n")
    sys.exit()

#-----------------------------------------------------------------------------------------------

def read_path( filename ):
    try:
        pathfile = open( filename, "r" )
    except:
        print("\nERROR: unable to open path file ", filename)
        sys.exit()

    ll_specified = False
    ur_specified = False
    road = []
    jump = False

    for line in pathfile.readlines() :
        line = line[:-1]

        if (not "#" in line) and ("lower-left" in line or "LL" in line or "ll" in line) :
            ll_specified = True
            part = line.split()
            if len( part ) < 2 :
                print("\nERROR: path file lower-left line syntax error: ", line)
                sys.exit()
            if ',' in part[1] :
                lls = part[1].split(',')
                llx = float( lls[0] )
                lly = float( lls[1] )
            elif len( part ) > 2 :
                llx = float( part[1] )
                lly = float( part[2] )
            else:
                print("\nERROR: path file lower-left syntax error: ", line)

        elif (not "#" in line) and ("upper-right" in line or "UR" in line or "ur" in line) :
            ur_specified = True
            part = line.split()
            if len( part ) < 2 :
                print("\nERROR: path file upper-right line syntax error: ", line)
                sys.exit()
            if ',' in part[1] :
                urs = part[1].split(',')
                urx = float( urs[0] )
                ury = float( urs[1] )
            elif len( part ) > 2 :
                urx = float( part[1] )
                ury = float( part[2] )
            else:
                print("\nERROR: path file upper-right syntax error: ", line)

        elif (not "#" in line) and ("jump" in line) and (len(road) > 0) : 
            jump = True
        else:
            if len(line) > 2 and not '#' in line :
                if ',' in line:
                    xy = line.split(',' )
                else:
                    xy = line.split()
                if len( xy ) > 1 :
                    try:
                        road.append( [float(xy[0]), float(xy[1]), jump] )
                        if jump : jump = False
                    except:
                        print("\nERROR: syntax error in %s [%s]\n " % (filename, line))
                        sys.exit()
                else:
                    print("\nERROR: syntax problem in %s [%s]\n " % (filename, line))
                    sys.exit()
                #
            #
        #

    pathfile.close()

    if ll_specified and not ur_specified :
        print("\nERROR: path lower left was specified, but not the upper right\n") 
        sys.exit()
    if ur_specified and not ll_specified:
        print("\nERROR: path upper right was specified, but not the lower-left\n")
        sys.exit()
    if ll_specified and ur_specified:
        print("\nPattern extents: (%1.2f,%1.2f) to (%1.2f,%1.2f) um\n" % (llx, lly, urx, ury))
        print("This should match the values you used for conversion to gpf.\n") 
        centerx = (urx + llx) / 2.0
        centery = (ury + lly) / 2.0
    else:
        centerx = 0.0
        centery = 0.0

    return (road, centerx, centery)

#-----------------------------------------------------------------------------------------------

def follow_path( R, vertex_road, chunk ):

    # For each subfield in R, find the nearest part of the road.
    # The path 'vertex_road' might have missing vertices, so we
    # start by filling in the 'road', placing a vertex every half chunk.

    giantstep = chunk * 50.0
    chunk = chunk / 2.0     # because snapping, that's why

    road = []
    n = len( vertex_road )
    if n < 2 : 
        print("\nERROR: The path defined in the path file is stupid. Fix the file path file. \n")
        sys.exit()

    for i in range( n-1 ) :
        road.append( [vertex_road[i][0], vertex_road[i][1]] )
        x0 = vertex_road[i][0]
        y0 = vertex_road[i][1]
        jump = vertex_road[i+1][2] # should we teleport to this vertex?
        dx = vertex_road[i+1][0] - vertex_road[i][0]
        dy = vertex_road[i+1][1] - vertex_road[i][1]
        sx = 1
        if dx < 0 : sx = -1
        sy = 1
        if dy < 0 : sy = -1
        if not jump and (abs(dx) > chunk or abs(dy) > chunk) :
            nx = abs( int( dx / chunk ) )
            ny = abs( int( dy / chunk ) )
            if nx > ny :
                for ix in range( 1, nx ) :
                    iy = int( ix * abs(dy) / abs(dx) )
                    x = x0 + sx * ix * chunk
                    y = y0 + sy * iy * chunk
                    road.append( [x,y] )
            else:
                for iy in range( 1, ny ) :
                    ix = int( iy * abs(dx) / abs(dy) )
                    x = x0 + sx * ix * chunk
                    y = y0 + sy * iy * chunk
                    road.append( [x,y] )

    road.append( [vertex_road[n-1][0], vertex_road[n-1][1]] )

    # For each shape in the pattern, find the closest point in the road

    for fn in range( len(R) ) :
        dx = R[fn][14] - road[0][0]
        dy = R[fn][15] - road[0][1]
        mind = dx * dx + dy * dy
        closest = 0
        for i in range( len(road) ) :
            dx = R[fn][14] - road[i][0]
            dy = R[fn][15] - road[i][1]
            d = dx * dx + dy * dy
            if d < mind :
                mind = d
                closest = i

        road[ closest ].append( fn )

        #dx = R[fn][14] - road[closest][0]
        #dy = R[fn][15] - road[closest][1]
        #d = math.sqrt(dx * dx + dy * dy)
        #if d > chunk :
        #    print "The shape at %1.2f %1.2f is %1.2f from the path." % (R[fn][14], R[fn][15], d)

        
    # the road now looks like [ x, y, n1, n2, n3 ... ]
    # let's now make a list of cities (aka the writing order)
    # by walking along the road and collecting the field numbers

    city = []
    for step in road :
        for i in range( 2, len(step) ) :
            city.append( step[i] )
            #print step[i],
        #print

    zap( "gnuplot" )
    Plot( city, R )

    return( city )


#-----------------------------------------------------------------------------------------------
# MAIN

print()
print("GPF yellow brick road sorting utility, version %1.1f" % version)
print()

if len( sys.argv ) == 1 : 
    print_use()

path = False
    
if len( sys.argv ) > 1 :
    if sys.argv[1] == "-h" or sys.argv[1] == "-help" or sys.argv[1] == "--help" :
        print_use()
    if "-path" in sys.argv[1] :
        path = True
        if len( sys.argv ) > 2 :
            if not ".gtx" in sys.argv[2] and not ".gpf" in sys.argv[2] :
                pathfile = sys.argv[2]
                if len( sys.argv ) > 3 :
                    filein = sys.argv[3]
                else:
                    print_use()
            else:
                pathfile = "path.txt"
                filein = sys.argv[2]
                if not ".gpf" in filein and not ".gtx" in filein : print_use()
    else:
        filein = sys.argv[1]
        if not ".gpf" in filein and not ".gtx" in filein : print_use()
else:
    print()
    print("Enter input gpf file name> ", end=' ')
    sys.stdout.flush()
    filein = sys.stdin.readline()
    filein = filename[0:-1]

if not (".gpf" in filein) and not (".gtx" in filein):
    print("\nERROR: input file must be either .gtx or .gpf")
    sys.exit()


name = filein.split( "." )
fileout = name[0] + "_sorted.gpf"

print()
print("Input file:      ", filein)
print("Output gpf file: ", fileout)

patcenterx = 0.0
patcentery = 0.0

if path : 
    print("Path file:       ", pathfile)
    road, patcenterx, patcentery = read_path( pathfile )


if ".gpf" in filein :
    print("\nConverting to gtx...\n")
    gpfgtx( filein, "temp_in.gtx" ) # os.system( "gpfgtx %s temp_in.gtx" % filein )
    gtxin  = open( "temp_in.gtx",  "rb" )
else:
    gtxin  = open( filein, "rb" )

gtxout = open( "temp_out.gtx", "w" )

print("\nCopying header... \n")

word  = []

# copy header

line = gtxin.readline().decode('utf8')
line = line.replace( "RANDOM", "FLOATING" )

if not line:
    print("\nERROR: unexpected end of file.\n\n")
    sys.exit()

word = line.split()
if len( word ) == 0 :
    word.append( "\n" )

bss = 0.0
mfr = 0.0
sfr = 0.0

while word[0] != "END" :
    gtxout.write( line )
    line = gtxin.readline().decode('utf8')
    line = line.replace( "RANDOM", "FLOATING" )

    if not line:
        print("\nERROR: unexpected end of file.\n\n")
        sys.exit()
        
    word = line.split()

    if len( word ) == 0 :
        word.append( "\n" )

    if word[0] == "BeamStepSize" :
        stuff = word[1].split( "," )
        sub_resol = int( stuff[0] ) 
        msf = sub_resol  
        bss = sub_resol
        print("        Subfield step size (bits) :  ", bss)
    elif word[0] == "Resolution":
        stuff = word[1].split( "," )
        main_resol = int( stuff[0] )         
    elif word[0] == "MainFieldResolution" :
        stuff = word[1].split( "," )
        mfr = float( stuff[0] )
        print("        Main field resolution (um) : ", mfr) 
    elif word[0] == "SubFieldResolution" :
        stuff = word[1].split( "," )
        sfr = float( stuff[0] )
        print("        Subfield resolution (um) :   ", sfr) 
    elif word[0] == "MainFieldSize" :
        stuff = word[1].split( "," )
        mfsx = float( stuff[0] )
        mfsy = float( stuff[1] )
        print("        Main field block size (um) : ", mfsx * sfr * bss, mfsy * sfr * bss)
        xblocksize = mfsx * bss * sfr / mfr
        yblocksize = mfsy * bss * sfr / mfr
        print("        Block size, mainfield bits:  ", xblocksize, yblocksize)
    elif word[0] == "NrMainFieldBits" :
        nmfb = int( word[1] )
        print("        Number of main field bits:   ", nmfb)
        fullfield = math.pow( 2, nmfb ) 
    elif word[0] == "MainFieldPlacement" :
        if word[1] == "MEANDER" :
            meander = True
        elif word[1] == "RANDOM" or word[1] == "FLOATING" :
            meander = False
        else:
            print("\nERROR: unknown block placement: %s\n" % word[1])
            sys.exit()
    elif word[0] == "SubFieldSize" :
        part = word[1].split(',')
        sfsx = float( part[0] )
        sfsy = float( part[1] )
        sfsx = sfsx * bss * sfr
        sfsy = sfsy * bss * sfr
        print("        Subfield size, um:           ", sfsx, sfsy)

try:
    if meander: n=0
except:
    print("\nERROR: MainFieldPlacement not found in header.\n")
    sys.exit()

if sfsx > sfsy :
    chunk = sfsx / 2.0      # turns out this is quite important
else:
    chunk = sfsy / 2.0


mainpersub = mfr / sfr

if bss == 0.0 or mfr == 0.0 or sfr == 0.0 :
    print("\nERROR: units not found in header.\n")
    sys.exit()

gtxout.write( line )    # write "END" after header

bss_sub = msf
#print "        Number of subfield bits in a beam step: %d\n" % bss_sub

center = 2**(nmfb-1)   # field center in main field bits = 2^19 usually

if not path:
    chunk = chunk / mfr   # usually, 1 um / 0.001 = 1000 bits

fieldnum = 0

print()
print("Reading...")
print()

end_of_file = False

while not end_of_file:             # while not EOF, sort each field

    new_field = True

    main_x_lsw   = 0
    main_y_lsw   = 0
    base_lsw     = "0"
    height_lsw   = "0"
    shift_lt_lsw = "0"
    shift_rb_lsw = "0"
    offset_x_lsw = "0"
    offset_y_lsw = "0"
    msf          = 0
    freq_msw     = "0"
    freq_lsw     = "0"

    append_next_line = False     
    n = 0
    end_of_field = False
    nbad = 0

    table = []

    while True:                       # for each_line in gtxin.readlines() :
        each_line = gtxin.readline().decode('utf8')

        if "FIELDOFFSET" in each_line:
            print("Field Offset line ignored.")
            each_line = gtxin.readline().decode('utf8')
        elif "FIELD" in each_line :
            gtxout.write( "%s" % each_line )
            word = each_line.split()
            fieldnum += 1
            print("----------------------------------------------------- field ", fieldnum)
            if not meander:
                part = word[1].split( ',' )
                fieldx = float( part[0] )
                fieldy = float( part[1] )
            else:
                fieldx = float( word[4][1:] )
                fieldy = float( word[6] )
            each_line = gtxin.readline().decode('utf8')
            if "MoveStage" in each_line :
                gtxout.write( "%s" % each_line )
                each_line = gtxin.readline().decode('utf8')
        
        if len( each_line ) == 0 :
            print("end of file -------------------------------")
            end_of_file = True
            break

        if end_of_field : 
            end_of_field = False
            print("end of field ------------------------------")
            break

        if append_next_line:                     # True for repetition lines
            line = line + "\n" + each_line[:-1]
            append_next_line = False 
        else:
            line = each_line[:-1]

        word = each_line.split()

        if len( word ) > 0:
            if word[0] ==                         "END":
                end_of_field = True
                break
            elif word[0] ==                       "Main":
                if word[1] == "X":
                    main_x_lsw = int( word[3] )
                else:
                    main_y_lsw = int( word[3] )
            elif word[0] ==                       "Frequency":
                if word[1] == "LSW":
                    freq_lsw = word[2]
                else:
                    freq_msw = word[2]
            elif word[0] ==                       "Base":
                base_lsw = word[2]
                ibase = int( base_lsw )
            elif word[0] ==                       "Height":
                height_lsw = word[2]
                iheight = int( height_lsw )
            elif word[0] ==                       "MSF":
                msf = word[1]                                     # subfield (e.g. 20 => 10nm)
                imsf = int( msf )
            elif word[0] ==                       "Shift":
                if word[1] == "LT":
                    shift_lt_lsw = word[3]
                else:
                    shift_rb_lsw = word[3]
            elif word[0] ==                       "Offset":
                if word[1] == "X":
                    offset_x_lsw = word[3]
                    ioffset_x = int( offset_x_lsw )
                else:
                    offset_y_lsw = word[3]
                    ioffset_y = int( offset_y_lsw )
            elif word[0] == "Repetition" or word[0] == "Control":
                append_next_line = True                            # tricky!
            elif word[0] ==                       "Activate":
                n = n + 1
                attributes = line.split()

                if "hb" in attributes :            # careful! hb applies only to this item
                    this_height_lsw = base_lsw 
                    iheight = int( this_height_lsw )
                else:
                    this_height_lsw = height_lsw
                    iheight = int( this_height_lsw )

                shift_rb_used = not ("rb45" in attributes or "rb90" in attributes)
                shift_lt_used = not ("lt45" in attributes or "lt90" in attributes)

                x = float( main_x_lsw ) 
                y = float( main_y_lsw ) 

                if False :
                    # if bad_shape( shift_rb_used, shift_lt_used, bss_sub, \
                    #               base_lsw, this_height_lsw, shift_lt_lsw, shift_rb_lsw, line ) : 
                    nbad = nbad + 1
                    #print "base:     ", base_lsw
                    #print "height:   ", this_height_lsw
                    #print "shift lt: ", shift_lt_lsw
                    #print "shift rb: ", shift_rb_lsw
                    #print line
                else:
                    # note that "base" and "height" switch for OY shapes
                    # so we do not need extra logic here
                    if path:
                        x = main_x_lsw + (ioffset_x/mainpersub) + (ibase + 1)   * imsf / (2.0 * mainpersub)
                        y = main_y_lsw + (ioffset_y/mainpersub) + (iheight + 1) * imsf / (2.0 * mainpersub)
                        x = fieldx + (x - center) * mfr
                        y = fieldy + (y - center) * mfr
                        x = x + patcenterx
                        y = y + patcentery
                        # x,y in the pattern table are now the same coordinates seen in CAD,
                        # if the path specified the lower-left and upper-right.
                    else:
                        x = main_x_lsw + ioffset_x / mainpersub
                        y = main_y_lsw + ioffset_y / mainpersub

                    sx = int( x / chunk )  # subfield x ... the subfield number now extends over
                    sy = int( y / chunk )  # subfield y ... the whole pattern, not just one field

                    table.append( [ line,          \
                                    main_x_lsw,    \
                                    main_y_lsw,    \
                                    freq_lsw,      \
                                    freq_msw,      \
                                    base_lsw,      \
                                    this_height_lsw,    \
                                    msf,           \
                                    shift_lt_lsw,  \
                                    shift_rb_lsw,  \
                                    offset_x_lsw,  \
                                    offset_y_lsw,  \
                                    shift_rb_used, \
                                    shift_lt_used, \
                                    x, \
                                    y, \
                                    True,  \
                                    False, \
                                    sx, sy, fieldx, fieldy  ] ) # [16] = "active", [17] = "hit"

            else:
                print("what is this do we want this in the output? \n[%s]\n" % line)   

            # end if len word[0]

        if (n > 0) and (n % 1000 == 0) : 
            #print "                               \010 shape %d \015" % n, 
            sys.stdout.flush()

        # end while true

    # end while not end_of_file

    if end_of_file:
        break

    #print "                             \010 shape %d \015 " % n 

    table = flatten( table, main_resol, sub_resol, mainpersub, chunk, center, \
                     mfr, patcenterx, patcentery, path )


    #-----------------------------------------------------------------
    # SORT THE TABLE

    if path :
        order = follow_path( table, road, chunk )
    else:
        order = yellow_brick_road_sort( table, chunk, 0, 0, fullfield )

    #---------------------------------------------------------------
    # Write the rest of the gtx file (the header was copied already)

    num_shapes = len( table )    # well, that also includes deleted array lines

    if num_shapes < 1 :
        print("\nERROR: there are no shapes in this gtx file.\n")
        sys.exit()

    #print "Writing temp_out.gtx...\n" 

    activate_line     = table[order[0]][0]
    prev_main_x_lsw   = table[order[0]][1]
    prev_main_y_lsw   = table[order[0]][2]
    prev_freq_lsw     = table[order[0]][3]
    prev_freq_msw     = table[order[0]][4]
    prev_base_lsw     = table[order[0]][5]
    prev_height_lsw   = table[order[0]][6]
    prev_msf          = table[order[0]][7]
    prev_shift_lt_lsw = table[order[0]][8]
    prev_shift_rb_lsw = table[order[0]][9]
    prev_offset_x_lsw = table[order[0]][10]
    prev_offset_y_lsw = table[order[0]][11]
    shift_rb_used     = table[order[0]][12]
    shift_lt_used     = table[order[0]][13]

    if not ("deleted" in activate_line):
        gtxout.write( "  Frequency  LSW %s\n"    % prev_freq_lsw     )
        gtxout.write( "  Frequency  MSW %s\n"    % prev_freq_msw     )
        gtxout.write( "  MSF        %s\n"        % prev_msf          )
        gtxout.write( "  Main       X LSW %s\n"  % prev_main_x_lsw   )
        gtxout.write( "  Main       Y LSW %s\n"  % prev_main_y_lsw   )
        gtxout.write( "  Offset     X LSW %s\n"  % prev_offset_x_lsw )
        gtxout.write( "  Offset     Y LSW %s\n"  % prev_offset_y_lsw )
        gtxout.write( "  Base       LSW %s\n"    % prev_base_lsw     )
        if not ("hb" in activate_line ) :
            gtxout.write( "  Height     LSW %s\n"    % prev_height_lsw   )
        if shift_lt_used:
            gtxout.write( "  Shift      LT LSW %s\n" % prev_shift_lt_lsw )
        if shift_rb_used:
            gtxout.write( "  Shift      RB LSW %s\n" % prev_shift_rb_lsw )
        gtxout.write( "%s\n" % activate_line )
        new_field = False
    elif new_field:
        new_field = False
        gtxout.write( "  Frequency  LSW %s\n"    % prev_freq_lsw     )
        gtxout.write( "  Frequency  MSW %s\n"    % prev_freq_msw     )
        gtxout.write( "  MSF        %s\n"        % prev_msf          )
        gtxout.write( "  Main       X LSW %s\n"  % prev_main_x_lsw   )
        gtxout.write( "  Main       Y LSW %s\n"  % prev_main_y_lsw   )
        gtxout.write( "  Offset     X LSW %s\n"  % prev_offset_x_lsw )
        gtxout.write( "  Offset     Y LSW %s\n"  % prev_offset_y_lsw )
        gtxout.write( "  Base       LSW %s\n"    % prev_base_lsw     )
        

    if num_shapes > 1 :
        for n in range( 1, len( order ) ):
            item = table[ order[n] ]

            if n % 1000 == 0 : 
                #print "                              \010 shape %d \015" % n, 
                sys.stdout.flush()

            activate_line = item[0]
            main_x_lsw    = item[1]
            main_y_lsw    = item[2]
            freq_lsw      = item[3]
            freq_msw      = item[4]
            base_lsw      = item[5]
            height_lsw    = item[6]
            msf           = item[7]
            shift_lt_lsw  = item[8]
            shift_rb_lsw  = item[9]
            offset_x_lsw  = item[10]
            offset_y_lsw  = item[11]
            shift_rb_used = item[12]
            shift_lt_used = item[13]

            # Setting values by implication does not work reliably,
            # so the output will be rather verbose. Oh well.

            if not ("deleted" in activate_line) :
                if True: # freq_lsw <> prev_freq_lsw :
                    gtxout.write( "  Frequency  LSW %s\n"    % freq_lsw     )
                if True: # freq_msw <> prev_freq_msw :
                    gtxout.write( "  Frequency  MSW %s\n"    % freq_msw     )
                if True: # msf <> prev_msf :
                    gtxout.write( "  MSF        %s\n"        % msf          )
                if True: # main_x_lsw <> prev_main_x_lsw :
                    gtxout.write( "  Main       X LSW %s\n"  % main_x_lsw   )
                if True: # main_y_lsw <> prev_main_y_lsw :
                    gtxout.write( "  Main       Y LSW %s\n"  % main_y_lsw   )
                if True: # PROBLEM: offset_x_lsw <> prev_offset_x_lsw :
                    gtxout.write( "  Offset     X LSW %s\n"  % offset_x_lsw )
                if True: # offset_y_lsw <> prev_offset_y_lsw :
                    gtxout.write( "  Offset     Y LSW %s\n"  % offset_y_lsw )
                if True: # base_lsw <> prev_base_lsw :
                    gtxout.write( "  Base       LSW %s\n"    % base_lsw     )
                if (not ("hb" in activate_line )): # PROBLEM: and (height_lsw <> prev_height_lsw) :
                    gtxout.write( "  Height     LSW %s\n"    % height_lsw   )
                if shift_lt_used: 
                    gtxout.write( "  Shift      LT LSW %s\n" % shift_lt_lsw )
                if shift_rb_used:
                    gtxout.write( "  Shift      RB LSW %s\n" % shift_rb_lsw )

                gtxout.write( "%s\n" % activate_line )
                new_field = False

            prev_main_x_lsw    = item[1]
            prev_main_y_lsw    = item[2]
            prev_freq_lsw      = item[3]
            prev_freq_msw      = item[4]
            prev_base_lsw      = item[5]
            prev_height_lsw    = item[6]
            prev_msf           = item[7]
            prev_shift_lt_lsw  = item[8]
            prev_shift_rb_lsw  = item[9]
            prev_offset_x_lsw  = item[10]
            prev_offset_y_lsw  = item[11]

            # end for
         
        # end while true 
        
    shape = 0
    gtxout.write( "END\n" )
    
    # end while not EOF


gtxin.close()
gtxout.close()

print("\n\nConverting back to gpf...\n")
sys.stdout.flush()
os.system( "pulse.py temp_out.gtx &" )
os.system( "%s temp_out.gtx %s" % (GTXGPF,fileout) )
zap( "pulse.py" )
print()
print("Output file: %s" % fileout)
print("\n\nDone.\n")
print()

