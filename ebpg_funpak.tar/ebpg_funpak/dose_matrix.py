#! /usr/bin/python3

version = 1.8

# Install the gdsii module with the command
# pip install python-gdsii

# requires the utility "flatten"
# found at nano.yale.edu/software-downloads
# Compile flatten.c with 'make' and copy the binary to a folder in
# your command path, such as /usr/local/bin

# Generating labels requires the Layout CAD python module.
# First, get your linux update repository working -- according to local instructions.
# Download Layout from layouteditor.com
# The free version is sufficient. You do not need to pay for a license.
# Paying for a license is nice though, since Layout is a pretty good CAD program.
# Install Layout with
#         dnf install layout...rpm
# where ... is the actual file name
# or, if you do not have dnf,
#         yum install layout...rpm
# Insert a line at the end of /etc/bashrc :
#         export PYTHONPATH=/opt/layout/python
# Test it with
#         python3
#         import LayoutScript

#---
# M. Rooks, Yale University
#---

# The gdsii python module has a bug that creates records of an inappropriate size.
# This is ignored by most programs, but not Beamer. We work around
# this bug by running the pattern through "flatten" after we are done.


from gdsii import tags, types
from gdsii.record import Record
import sys
import re
import os
import math

polygons = "yes"               # use 'no' for GPG, 'yes' for UPG

layout_installed = True       # layout is used to convert text to polygons
                              # it's nice to have dose labels, but not essential
try:
    import LayoutScript
    from   LayoutScript import *
except:
    layout_installed = False


freebeam_installed = True

textsize    = 4.0  # percent of the largest pitch
maxtextsize = 40.0 # microns, so the text size does not get crazy big


def use():
    print( "\ndose_matrix v%1.1f\n" % version )
    print( "Use: dose_matrix input.gds top-cell layer1 number1 dx low-dose1 high-dose1 layer2 number2 dy low-dose2 high-dose2 text-dose\n" )
    print( "or just type 'dose_matrix' and answer all the questions.\n" )
    print( "For example:\n" )
    print( "        dose_matrix foo.gds topcell 0 10 1000 500 5000 1 12 2000 700 900 1000\n" )
    print( "varies the dose for layer 0 between 500 and 5000 uC/cm2 in 10 steps, with a spacing of 1000 um in X. And it" )
    print( "varies the dose for layer 1 between 700 and  900 uC/cm2 in 12 steps, with a spacing of 2000 um in Y." )
    print( "The output file dose_matrix.gds will contain number1 * number2 copies of input.gds. The file dose_matrix.gds" )
    print( "will not contain dose values, since that is not part of GDS format. Instead, dose_matrix.gds will have" )
    print( "number1 new layers and number2 new datatypes. The map between layers/datatypes and relative doses is written" )
    print( "to dose_fda.txt, for use in the Figure Dose Assignment (FDA) module in Beamer. Beamer will create a " )
    print( "gpf file with number1*number2 relative doses." )
    if freebeam_installed:
        print( "\nThis program also writes a script for Freebeam, dose_matrix.sh, which you can edit and run," )
        print( "instead of using beamer." )
    print( "\nIn cjob, you should set the base dose to low-dose1 or low-dose2, whichever is lower." )
    print( "Dose_matrix generates mutiplicative dose steps; that is, the doses increase by a factor." )
    print( "For example, the factor 1.15 would produce a 15% step. The doses do not increase in fixed additive steps" )
    print( "because this way is better because I said so that's why.\n" )
    print( "Dose_matrix can also be used to create a one-dimensional dose bracket where one layer is varied" )
    print( "while another layer has a fixed dose.\n" )
    sys.exit()

    
def data_overrun_check( dbu, xmin, xmax, ymin, ymax, idx, idy, ncols, nrows ) :
    if data_overrun_check.done : return()
    if  xmax + idx * nrows >  2147483647 or \
        xmin - idx * nrows < -2147483648 or \
        ymax + idy * ncols >  2147483647 or \
        ymin - idy * ncols < -2147483648 :
        print( "\nERROR: The coordinates are too large for 32-bit integers." )
        print(   "       You need to use a smaller pattern or a larger data unit." )
        if dbu < 0.001 :
            print( "       The database unit is %1.2f nm, which is too small." % (dbu * 1000) )
            print( "       You can use the utility dataunit_fix to convert the pattern to nm units," )
            print( "       or you can read the pattern into a CAD program (like layout) " )
            print( "       to change the units.\n" )
            if not layout_installed :
                print( "       Unfortunately layout is not installed on this system " )
                print( "       and so you cannot use datatunit_fix. \n" )
            print( "       Note that the use of 1 Angstrom as the database unit is a poor choice," )
            print( "       because you ran out of range. Also - why are you using a gigantic" )
            print( "       pattern for a dose test?  \n" )
        print( "Abort.\n" )
        sys.exit()

    data_overrun_check.done = True
    
data_overrun_check.done = False



def gds_record( ofile, line ):
    #print( line )
    rexp = re.compile(r'^(?P<tag>[^:]+)(:\s*(?P<rest>.*))?$')
    stripped = line.strip()
    m = rexp.match(stripped)
    if not m:
        print('Parse error: [%s]' % line )
        sys.exit(1)
    tag_name = m.group('tag')
    rest = m.group('rest')
    tag = tags.DICT[tag_name]
    tag_type = tags.type_of_tag(tag)

    if tag_type == types.NODATA:
        data = None
    elif tag_type == types.ASCII:
        data = rest[1:-1].encode() # FIXME
    elif tag_type == types.BITARRAY:
        data = int(rest)
    elif tag_type == types.REAL8:
        data = [float(s) for s in rest.split(',')]
    elif tag_type == types.INT2 or tag_type == types.INT4:
        data = [int(s) for s in rest.split(',')]
    else:
        raise Exception('Unsupported type')
    rec = Record(tag, data)
    rec.save(ofile)



#===================================================================================================================


if "help" in sys.argv or "-h" in sys.argv : use()

script_name = ""

if len( sys.argv ) != 14 :
    print( "\nLet's create a dose matrix.\n" )
    if not layout_installed :
        print( "* Layout is not installed on this system. You can generate a " )
        print( "* dose matrix, but you cannot print the dose labels.\n" )
    print( "You can choose a gds layer for the dose bracket in the X direction," )
    print( "and a different layer for the dose bracket in the Y direction." )
    if layout_installed:
        print( "After 13 questions, we will generate the file dose_matrix.gds.\n" )
    else:
        print( "After 12 questions, we will generate the file dose_matrix.gds.\n" )

    print( "1. input gds file name:                  ", end='' )
    sys.stdout.flush()
    infile = sys.stdin.readline()[:-1]
    try:
        f = open( infile, "r" )
        f.close()
    except:
        print( "\nERROR: File not found: %s" % infile )
        print( "Abort.\n" )
        sys.exit()

    print()
    print( "2. top level cell name, or press" )
    print( "   [enter] to choose the first one:      ", end="" )

    sys.stdout.flush()
    topcell = sys.stdin.readline()[:-1]
    if topcell == "" :
        topcell = "?"
        print( "\nOk, I will use the first cell in the file." )
        print( "(You can use layout or gdsdump to see the cell names.)\n" )
    if topcell == "?" : topcell = "\"?\""

    print()
    print( "3. layer to use for dose variation in X, " )
    print( "   or enter -1 for no variation in X:    ", end="" )
    sys.stdout.flush()
    layer1 = int( sys.stdin.readline() )

    print()
    print( "4. number of exposures in X:             ", end='' )
    sys.stdout.flush()
    ncols = int( sys.stdin.readline() )
    if ncols < 1 :
        print( "\nERROR: the number of columns must be at least 1. Try again.\n" )
        print( "4. number of exposures in X:             ", end='' )
        sys.stdout.flush()
        ncols = int( sys.stdin.readline() )
        if ncols < 1 :
            print( "\nERROR: you are not paying attention.\n" )
            sys.exit()

    if ncols > 1 :
        print()
        print( "5. center to center spacing in X, um:    ", end='' )
        sys.stdout.flush()
        dx = float( sys.stdin.readline() )
    else:
        dx = 0.0

    if layer1 >= 0 :
        print()
        print( "6. starting dose for X, uC/cm2 :         ", end='' )
        sys.stdout.flush()
        low1 = float( sys.stdin.readline() )
    else:
        low1 = 0.0;
        
    if ncols > 1 :
        print()
        print( "7. ending dose for X, uC/cm2 :           ", end='' )
        sys.stdout.flush()
        high1 = float( sys.stdin.readline() )
    else:
        high1 = low1

    print()
    print( "8. layer to use for dose variation in Y  " )
    print( "   or enter -1 for no variation:         ", end='' )
    sys.stdout.flush()
    layer2 = int( sys.stdin.readline() )
    if (layer2 >= 0) and (layer1 == layer2) :
        print( "\nError: you must choose two different layers. Try again." )
        print(   "       For a 1D dose bracket, enter -1.\n" )
        print( "8. layer to use for dose variation in Y: ", end='' )
        sys.stdout.flush()
        layer2 = int( sys.stdin.readline() )
        if layer1 == layer2 :
            print( "\nERROR: you must choose two different layers. Really.\n" )
            sys.exit()

    print()
    print( "9. number of exposures in Y:             ", end='' )
    sys.stdout.flush()
    nrows = int( sys.stdin.readline() )
    if nrows < 1 :
        print( "\nERROR: the number of rows must be at least 1. Try again.\n" )
        print( "9. number of exposures in Y:             ", end='' )
        sys.stdout.flush()
        nrows = int( sys.stdin.readline() )
        if nrows < 1 :
            print( "\nReally? No.\n" )
            sys.exit()

    if nrows > 1 :
        print()
        print( "10. center to center spacing in Y, um:   ", end='' )
        sys.stdout.flush()
        dy = float( sys.stdin.readline() )
    else:
        dy = 0.0

    if layer2 >= 0 :
        print()
        print( "11. starting dose for Y, uC/cm2 :        ", end='' )
        sys.stdout.flush()
        low2 = float( sys.stdin.readline() )
    else:
        low2 = 0.0

    if nrows > 1 :
        print()
        print( "12. ending dose for Y, uC/cm2 :          ", end='' )
        sys.stdout.flush()
        high2 = float( sys.stdin.readline() )
    else:
        high2 = low2

    labeldose = 0
    if layout_installed :
        print()
        print( "13. Last question! " )
        print( "    What dose should we use for labels?  ", end='' )
        sys.stdout.flush()
        labeldose = float( sys.stdin.readline() )
        if labeldose < 10.0 :
            print( "\nLooks like you don't want labels at all." )
            print( "Ok, no labels." )
            labeldose = 0

    print( "\nThat was a lot of questions. Would you like me to save" )
    print( "the answers in a bash script file? That way, you can" )
    print( "run the program again without answering questions." )
    print( "yes or no > ", end='' )
    sys.stdout.flush()
    ans = sys.stdin.readline()
    if "y" in ans :
        print( "\nOk, enter the name of the bash script > ", end='' )
        sys.stdout.flush()
        ans = sys.stdin.readline()
        ans = ans[:-1]
        if ans == "dose_matrix.sh" and freebeam_installed :
            print( "\nSorry, I need to use that name for the Freebeam script." )
            print( "Please choose a different name for the script >           ", end='' )
            sys.stdout.flush()
            ans = sys.stdin.readline()
            ans = ans[:-1]
            if ans == "dose_matrix.sh" :
                print( "\nDon't be an asshole.\n" )
                sys.exit()
        script_name = ans
        scr = open( script_name, "w" )
        scr.write( "#!/usr/bin/bash\n\n" )
        scr.write( "# dose_matrix input.gds top-cell layer1 number1 dx low-dose1 high-dose1 layer2 number2 dy low-dose2 high-dose2 label-dose \n\n" )
        scr.write( "dose_matrix %s %s %d %d %1.3f %1.3f %1.3f %d %d %1.3f %1.3f %1.3f %1.3f\n\n" % \
                   (infile, topcell, layer1, ncols, dx, low1, high1, layer2, nrows, dy, low2, high2, labeldose) )
        scr.close()
        os.system( "chmod a+x %s" % ans )
else:
    infile    =        sys.argv[1]
    topcell   =        sys.argv[2]
    layer1    = int(   sys.argv[3]  )
    ncols     = int(   sys.argv[4]  )
    dx        = float( sys.argv[5]  )
    low1      = float( sys.argv[6]  )
    high1     = float( sys.argv[7]  )
    layer2    = int(   sys.argv[8]  )
    nrows     = int(   sys.argv[9]  )
    dy        = float( sys.argv[10] )
    low2      = float( sys.argv[11] )
    high2     = float( sys.argv[12] )
    labeldose = float( sys.argv[13] )

if topcell == "?" : topcell = "\"?\""

if (layer1 >= 0) and (layer1 == layer2) :
    print( "\nError: you must choose two different layers\n" )
    sys.exit()

found_top = False

print()
print( "Input gds:                 %s" % infile )
print( "Output gds:                dose_matrix.gds" )
print( "Output FDA for Beamer:     dose_fda.txt" )
if freebeam_installed : print( "Output doses for freebeam: dose_free.txt\n" )
print( "Cell:         %s" % topcell )
print( "Layer X:      %d" % layer1 )
print( "Layer Y:      %d" % layer2 )
print( "Columns:      %d" % ncols )
print( "Rows:         %d" % nrows )
print( "Pitch X:      %1.2f um" % dx )
print( "Pitch Y:      %1.2f um" % dy )
print( "Low X dose:   %1.2f uC/cm2" % low1 )
print( "High X dose:  %1.2f uC/cm2" % high1 )
print( "Low Y dose:   %1.2f uC/cm2" % low2 )
print( "High Y dose:  %1.2f uC/cm2" % high2 )
if layout_installed :
    print( "Text dose:    %1.2f uC/cm2" % labeldose )
print()

if nrows < 1 or ncols < 1 :
    print( "\nERROR: number of rows and columns must both be greater than 0.\n" )
    sys.exit()

if layer1 > 256 :
    print( "\nERROR: invalid layer: %d\n" % layer1 )
    sys.exit()

if layer2 > 256 :
    print( "\nERROR: invalid layer: %d\n" % layer2 )
    sys.exit()

if low1 < 0.0 or high1 < 0.0 or low2 < 0.0 or high2 < 0.0 :
    print( "\nERROR: negative doses are not allowed.\n" )
    sys.exit()

if ncols == 1 :
    if low1 == 0.0  : low1 = low2       # dummy doses for a dummy layer
    if high1 == 0.0 : high1 = high2

if nrows == 1 :
    if low2 == 0.0  : low2 = low1
    if high2 == 0.0 : high2 = high1
    
dosex = low1
dosey = low2

if labeldose > 0.0 :
    basedose = min( low1, low2, high1, high2, labeldose )
else:
    basedose = min( low1, low2, high1, high2 )
    
if basedose <= 0.0 :
    print( "\nERROR: the lowest dose is <= zero.\n" )
    sys.exit()
    
relx = dosex / basedose
rely = dosey / basedose

print( "\n************************* Remember: you should use %1.2f uC/cm2 as the base dose in cjob.\n" % basedose )

print( "flattening %s ... \n" % infile )
sys.stdout.flush()

stuff = os.popen( "flatten %s %s" % (infile, topcell) ).read()

if "ERROR" in stuff :
    print( stuff )
    print( "Abort.\n" )
    sys.exit()

infile  = "flat.gds"
topcell = "flat"

pattern = []
line    = ""
header  = ""
bgnlib  = ""
libname = ""
units   = ""
bgnstr  = ""

# most of these tags are never used, since
# flatten removes all paths, cell reference, arrays,
# magnifications, and angles. flatten makes everything easy.
# text disappears, unfortunately.

print( "reading %s ... \n" % infile )
nrec = 0
print( "record %d    " % nrec, end='' )   

with open( infile, 'rb' ) as a_file:
    for rec in Record.iterate(a_file):
        if rec.tag_name == "DATATYPE":
            dt = rec.data
            line = "DATATYPE: %d" % dt 
        elif rec.tag_name == "LAYER":
            layer = rec.data
            line = "LAYER: %d" % layer 
        elif rec.tag_name == "UNITS":
            dbu = rec.data[1]
            dbuuu = rec.data[0]
            line = ""
            units = "UNITS: %g, %g" % (dbuuu, dbu) 
        elif rec.tag_name == "XY":
            p = rec.data
            line = "XY: "
            for num in p : line = line + "%d, " % num
            line = line[:-2]
        elif rec.tag_name == "LIBNAME" :
            p = rec.data
            libname = p.decode('utf-8')
            libname = "LIBNAME: \"%s\"" % libname
            line = ""
        elif rec.tag_name == "STRNAME" :
            cell = rec.data.decode('utf-8')
            #line = "STRNAME: \"%s\"" % cell
            if not found_top :
                found_top = (cell == topcell)
            line = ""
        elif rec.tag_name == "BGNLIB" :
            bgnlib = "BGNLIB: "
            for n in rec.data :
                bgnlib = bgnlib + "%d, " % n
            bgnlib = bgnlib[:-2]
            line = ""
        elif rec.tag_name == "HEADER" :
            header = "HEADER: 7"
        elif rec.tag_name == "BGNSTR" :
            line = "BGNSTR: "
            for n in rec.data :
                line = line + "%d, " % n
            line = line[:-2]
            bgnstr = line
            line = ""
        elif rec.tag_name == "BOUNDARY" :
            line = "BOUNDARY"
        elif rec.tag_name == "ENDEL" :
            line = "ENDEL"
        elif rec.tag_name == "ENDSTR" :
            line = "ENDSTR"
        elif rec.tag_name == "ENDLIB" :
            line = ""
        elif rec.tag_name == "BOX" :
            line = "BOX"
        elif rec.tag_name == "BOXTYPE" :
            line = "BOXTYPE: %d" % rec.data[0]
        elif rec.tag_name == "SREF" :
            line = "SREF"
        elif rec.tag_name == "SNAME" :
            p = rec.data
            name = p.decode('utf-8')
            line = "SNAME: \"%s\"" % name 
        elif rec.tag_name == "STRANS" :
            line = "STRANS: %d" % rec.data
        elif rec.tag_name == "MAG" :
            line = "MAG: %1.3f" % rec.data[0]
        elif rec.tag_name == "ANGLE" :
            line = "ANGLE: %1.3f" % rec.data[0]
        elif rec.tag_name == "AREF" :
            line = "AREF"
        elif rec.tag_name == "COLROW" :
            line = "COLROW: %d, %d" % (rec.data[0],rec.data[1])
        elif rec.tag_name == "TEXT" :
            line = "TEXT"
        elif rec.tag_name == "TEXTTYPE" :
            line = "TEXTTYPE: %d" % rec.data[0]
        elif rec.tag_name == "PRESENTATION" :
            line = "PRESENTATION: %d" % rec.data
        elif rec.tag_name == "WIDTH" :
            line = "WIDTH: %d" % rec.data[0]
        elif rec.tag_name == "STRING" :
            line = "STRING: \"%s\"" % rec.data.decode('utf-8')
        else:
            print( "********* unknown: %s" % rec.tag_name )
            if not rec.data == None :
                print( "*********        ", rec.data )

        if line != "" :
            pattern.append( line )
            nrec = nrec + 1
            if nrec % 500 == 0 :
                print( "\015record %d    " % nrec, end='' )
                sys.stdout.flush()
            
        
outfile = open( "dose_matrix_temp.gds", "wb" )

err = False

if header == "" :
    print( "\nERROR: missing header" )
    err = True
if bgnlib == "" :
    print( "\nERROR: missing bgnlib" )
    err = True
if libname == "" :
    print( "\nERROR: missing libname" )
    err = True
if units == "" :
    print( "\nERROR: missing units" )
    err = True
if bgnstr == "" :
    print( "\nERROR: bgnstr not found" )
    err = True
if not found_top :
    print( "\nERROR: top cell [%s] not found" % topcell )
    err = True
if err:
    print( "\nAborted. No output file.\n" )
    sys.exit()


gds_record( outfile, header  )
gds_record( outfile, bgnlib  )
gds_record( outfile, libname )
gds_record( outfile, units   )
gds_record( outfile, bgnstr  )
gds_record( outfile, "STRNAME: \"dosematrix\"" )

# dose table contains [dosex, dosey, centerx, centery]
# centerx, centery is the center of the pattern extent

dosetable = [ [[0,0,0,0] for i in range(nrows)] for j in range(ncols) ]

dbu = dbu * 1000000.0  #  database unit in microns. typically 0.001 or 0.0001

idx = int( dx / dbu )
idy = int( dy / dbu )

print( "\n\nwriting dose matrix...\n" )

for row in range(nrows) :
    shifty = row * idy
    for col in range(ncols) :
        shiftx = col * idx
        first = True
        npoints = 0

        print( "\015[%d,%d]     " % (col,row), end='' )
        sys.stdout.flush()
        
        for line in pattern :
            if line[0:5] == "LAYER" :
                layer = int( line.split(':')[1] )
                if layer == layer1 :
                    newline = "LAYER: %d" % (col+1)      # layer1 layer numbers increase in X, starting at 1
                    gds_record( outfile, newline )
                    newline = "DATATYPE: 0"              # layer1 DT numbers are fixed at 0
                    gds_record( outfile, newline )
                elif layer == layer2 :
                    newline = "LAYER: 0"                 # layer2 layer numbers are fixed at 0
                    gds_record( outfile, newline )
                    newline = "DATATYPE: %d" % (row+1)   # layer2 DT numbers increase in Y, starting at 1
                    gds_record( outfile, newline )
            elif line[0:8] == "DATATYPE" :
                pass     
            elif line[0:2] == "XY" and (layer == layer1 or layer == layer2) :
                point = line[3:].split(',')
                newline = "XY: "
                n = int( len(point) / 2 )
                for i in range(n) :
                    x = int( point[2*i]   )
                    y = int( point[2*i+1] )
                    x = x + shiftx
                    y = y + shifty
                    
                    if first :
                        first = False
                        xmin = x
                        xmax = x
                        ymin = y
                        ymax = y
                    else:
                        if x < xmin : xmin = x
                        if x > xmax : xmax = x
                        if y < ymin : ymin = y
                        if y > ymax : ymax = y
                        
                    newline = newline + "%d, %d, " % (x, y)
                newline = newline[:-2]
                gds_record( outfile, newline )
            elif line[0:2] == "XY" :                     # discard unused layers
                newline = "XY: 0, 0, 0, 0, 0, 0"
                gds_record( outfile, newline )
            else :
                gds_record( outfile, line )

        # for line

        data_overrun_check( dbu, xmin, xmax, ymin, ymax, idx, idy, ncols, nrows )
        
        dosetable[col][row][2] = (xmax + xmin) / 2
        dosetable[col][row][3] = (ymax + ymin) / 2
        
    # for col
#for row

print( "\n" )

# now write the FDA dose map file

fda      = open( "dose_fda.txt", "w" )
freedose = open( "dose_free.txt", "w" )

stepx = 1.0
stepy = 1.0

if ncols > 1 :
    stepx = math.exp( math.log(high1 / low1) / (ncols-1) )
if nrows > 1 :    
    stepy = math.exp( math.log(high2 / low2) / (nrows-1) )

freedose.write( "# layer  datatype  relative-dose  beam-step-nm\n" )
    
# we use layer(dt) = 0(0) for labels.
# layers 1 and higher are used for the X sequence.
# datatypes 1 and higher are used for the Y sequence.

if labeldose > 0.0 :
    freedose.write( "0 0 %1.3f\n" % (labeldose/basedose) )
    fda.write( "0(0) , %1.3f\n" % (labeldose/basedose) )

dose = low1

for col in range(ncols) :
    rdose = dose / basedose
    if rdose <= 0.5 :
        print( "\nERROR: Relative dose %1.3f <= 0.5 for column %d" % (rdose, col) )
        print(   "       Relative doses must be > 0.5\n" )
        sys.exit()
    freedose.write( "%d 0 %1.3f\n" % (col+1, rdose) )
    fda.write( "%d(0) , %1.3f\n" % (col+1, rdose) )
    for i in range(nrows) :
        dosetable[col][i][0] = dose
    dose = dose * stepx


dose = low2

for row in range(nrows) :
    rdose = dose / basedose
    if rdose <= 0.5 :
        print( "\nERROR: Relative dose %1.3f <= 0.5 for row %d" % (rdose, row) )
        print(   "       Relative doses must be > 0.5\n" )
        sys.exit()
    freedose.write( "0 %d %1.3f\n" % (row+1, rdose) )
    fda.write( "0(%d) , %1.3f\n" % (row+1, rdose) )
    for i in range(ncols) :
        dosetable[i][row][1] = dose
    dose = dose * stepy

freedose.close()
fda.close()

print( "\nDOSES, uC/cm2, assuming a base dose of %1.2f uC/cm2\n" % basedose )
print( "Label dose: %1.0f\n" % labeldose )
if ncols > 1 : print( "Layer %d doses increase in the X direction.\n" % layer1 )
if nrows > 1 : print( "Layer %d doses increase in the Y direction.\n" % layer2 )

maxpitch = max( idx, idy )
itextsize = int( textsize * maxpitch * 0.01 )
imaxtextsize = int( maxtextsize / dbu )
if itextsize > imaxtextsize : itextsize = imaxtextsize

rowlist = list( range( nrows ) )
rowlist.reverse()

for row in rowlist :
    for col in range( ncols ) :
        print( "%6.0f|%-6.0f" % (dosetable[col][row][0], dosetable[col][row][1]), end='' )

        # where to put the dose label:

        if idy == 0.0 :
            print( "\n\nHmm. I'm not sure where I should put the labels." )
            print( "Tell me the shift in Y between the pattern " )
            print( "center and the label, in microns (+ or -) > ", end='' )
            sys.stdout.flush()
            dy = float( sys.stdin.readline() )
            idy = int( dy / dbu )
        
        x0 = dosetable[col][row][2] - itextsize * 4
        y0 = dosetable[col][row][3] + idy / 2

        # two labels, ye gods gds is so verbose

        if layer1 >= 0 :
            gds_record( outfile, "TEXT" )
            gds_record( outfile, "LAYER: 0" )
            gds_record( outfile, "TEXTTYPE: 0" )
            gds_record( outfile, "PRESENTATION: 0" )
            gds_record( outfile, "WIDTH: %d" % itextsize )
            gds_record( outfile, "STRANS: 0" )
            gds_record( outfile, "ANGLE: 0" )
            gds_record( outfile, "XY: %d, %d" % (x0,y0 + itextsize) )
            gds_record( outfile, "STRING: \"L%d  %d\"" % (layer1, dosetable[col][row][0]) )
            gds_record( outfile, "ENDEL" )

        if layer2 >= 0 :
            gds_record( outfile, "TEXT" )
            gds_record( outfile, "LAYER: 0" )
            gds_record( outfile, "TEXTTYPE: 0" )
            gds_record( outfile, "PRESENTATION: 0" )
            gds_record( outfile, "WIDTH: %d" % itextsize )
            gds_record( outfile, "STRANS: 0" )
            gds_record( outfile, "ANGLE: 0" )
            gds_record( outfile, "XY: %d, %d" % (x0, y0 - itextsize) )
            gds_record( outfile, "STRING: \"L%d  %d\"" % (layer2, dosetable[col][row][1]) )
            gds_record( outfile, "ENDEL" )
    print()

gds_record( outfile, "ENDSTR" )
gds_record( outfile, "ENDLIB" )

outfile.close()

# Use Layout to convert dose labels to polygons.
# Wow, and you thought this would be hard.
# Hey we could have done this entire program
# as a layout macro. Maybe next time.

if layout_installed and labeldose > 0.0 :
    print( "\nConverting text to polygons...\n" )
    sys.stdout.flush()
    L = project.newLayout()
    L.open( "dose_matrix_temp.gds" )
    c = L.drawing.currentCell
    c.textToPolygon( itextsize )
    L.drawing.saveFile( "dose_matrix.gds" )
else:
    # filter the gds file to fix the long records that upset Beamer
    # we don't need to do this if we run the pattern through Layout

    print( "\nFixing record size in output file...\n" )
    sys.stdout.flush()
    os.system( "flatten dose_matrix_temp.gds dosematrix" )
    os.system( "mv flat.gds dose_matrix.gds" )

os.system( "rm -f dose_matrix_temp.gds" )



# now spit out a script that will run the pattern through freebeam

if freebeam_installed :
    sh = open( "dose_matrix.sh", "w" )
    sh.write( "#!/bin/bash\n" )
    sh.write( "infile=\"dose_matrix\"\n" )
    sh.write( "suffix=\"gds\"\n" )
    sh.write( "topcell=\"chip\"\n" )
    sh.write( "outfile=\"dose_matrix\"\n" )
    sh.write( "layer=\"*\"\n" )
    sh.write( "bss=10               #******* EDIT THIS\n" )
    sh.write( "lsb=1\n" )
    sh.write( "pss=1.0\n" )
    sh.write( "xblock=600           #******* EDIT THIS\n" )
    sh.write( "yblock=600           #******* EDIT THIS\n" )
    sh.write( "xsub=0\n" )
    sh.write( "ysub=0\n" )
    sh.write( "llx=0                #******* EDIT THIS\n" )
    sh.write( "lly=0                #******* EDIT THIS\n" )
    sh.write( "urx=0                #******* EDIT THIS\n" )
    sh.write( "ury=0                #******* EDIT THIS\n" )
    sh.write( "polygons=\"%s\"\n" % polygons )
    sh.write( "dosefile=\"dose_free.txt\"\n" )                  
    sh.write( "crllx=0\n" )
    sh.write( "crlly=0\n" )
    sh.write( "crurx=0\n" )
    sh.write( "crury=0\n" )
    sh.write( "remove_overlaps=\"no\"\n" )
    sh.write( "voltage=\"100\"\n" )
    sh.write( "split=\"yes\"\n" )
    sh.write( "nsplits=0\n" )
    sh.write( "purge=\"yes\"\n" )
    sh.write( "alreadyflat=\"yes\"\n" )
    sh.write( "quiet=\"y\"\n" )
    sh.write( "angle=0\n" )
    sh.write( "array=\"no\"\n" )
    sh.write( "path=\"\"\n" )
    sh.write( "\n" )
    sh.write( ". freebeam.sh -$quiet   2>&1 | tee $outfile.log\n\n" )
    sh.write( "if [ -f fullstop.txt ]; then exit ; fi\n\n" )
    sh.write( "if [ -f $outfile.gpf ]; then\n" ) 
    sh.write( "    cview $outfile.gpf\n" )
    sh.write( "fi\n" )  
    sh.write( "echo\necho \"done.\"\necho\n" )
    sh.close()

    os.system( "chmod a+x dose_matrix.sh" )

print( "\nDone.\n" )

print( "===================================================================" )
print( "*" )
if freebeam_installed :
    print( "*  Edit and run dose_matrix.sh if you are using Freebeam.      " )
    print( "*                                                              " )
print( "*  If you are using Beamer, select the gds file dose_matrix.gds     " )
print( "*  and then import dose_fda.txt in the FDA module.  " )
print( "*                                                              " )
if script_name != "" :
    print( "*  Use ./%s to run this program again.   " % script_name )
    print( "*                                                              " )
print( "*  Be sure to use a base dose of %1.2f uC/cm2 in cjob." % basedose )
print( "*                                                              " )
print( "===================================================================" )
print("\n")
