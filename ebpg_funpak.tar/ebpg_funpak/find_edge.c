/*

find_edge.c    version 2.1

Michael Rooks, Yale University  michael.rooks@yale.edu

Given the image of an edge, find the edge by calculating a
simple-minded fit to a step function. The rows (or columns) of the
image are first averaged, forming a one-dimensional signal. The signal
is normalized and then fit to a step. The image might be
collected with a command such as

        pg image grab 0,0 1000,1000 128,128 left

which dumps a raw image into the file left.img. In this example the
pixel pitch is 1000 nm, and there are 128x128 pixels.

Be sure to include the line

        export PG_IMAGES=.

in /home/pg/local_commands (or in /etc/bashrc) so that "pg image grab"
will dump image files in the current directory.

use: find_edge [vertical|horizontal] [bright-dark|dark-bright] \
     imagefile.img xpixels ypixels nm/pixel [plot] [title] [threshold]

v2: Use int instead of short int for image file- better normalization

v2.1: Add threshold as a line option.

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define BYTE  unsigned char
#define BOOL  short
#define TRUE  1
#define FALSE 0

#define THRESHOLD 10       // minimum contrast, percent


int **int_matrix( int nrl, int nrh, int ncl, int nch)

    {

    // Allocate a matrix of pointers to int

    int    i;
    int  **m;
      
    m=(int **) malloc((nrh-nrl+1)*sizeof( int* ));

    if ( ! m ) 
        {
        printf("\n\nERROR: allocation failure 1 in int_matrix()\n\n");
        exit(-1);
        }

    m -= nrl;

    for(i=nrl;i<=nrh;i++) 
        {
        m[i]=(int *) malloc((unsigned) (nch-ncl+1)*sizeof(int));
        if (! m[i] ) 
            {
            printf("\n\nERROR: allocation failure 2 in si_matrix()\n\n");
            exit(-1);
            }
        m[i] -= ncl;
        }

    return m; 

    }

//-- end int_matrix ----------------------------------------------------------------


void
normalize( int **image, int nr, int nc )
    {
    int
        shift,
        max,
        min,
        aver,
        r,
        c;

    max = image[0][0];
    min = max;

    for( r=0; r < nr; r++ )    
        {
        for( c=0; c < nc; c++ )
            {
            if ( image[r][c] < min ) min = image[r][c];
            if ( image[r][c] > max ) max = image[r][c];
            }
        }

    if ( min == max )
        {
        printf( "\n\nERROR: no contrast in image.\n\n" );
        exit(0);
        }

    aver = (max + min) / 2;

    shift = 16384 - aver;
    max   = max + shift;
    min   = min + shift;
 
    for( r=0; r < nr; r++ )    
        {
        for( c=0; c < nc; c++ )
            {
            image[r][c] += shift;
            image[r][c] = 32768 * (image[r][c] - min)  / (max  - min); 
            }
        }

    }

//-- end normalize --------------------------------------------------------------------

long *
squish( int **image, int nr, int nc, BOOL vertical )
    {

    // Average the rows or columns of the image, reuturning a 1D signal.

    int r, c;
    long *signal;

    if ( vertical )
        signal = (long *) malloc( nc * sizeof( long ) );
    else
        signal = (long *) malloc( nr * sizeof( long ) );

    if ( vertical )
        {
        for ( c=0; c < nc; c++ )
            {
            for ( r=0; r < nr; r++ )
                {
                signal[c] = (signal[c] * r + image[r][c]) / (r + 1);
                }
            }
        }    
    else
        {
        for ( r=0; r < nr; r++ )        
            {
            for ( c=0; c < nc; c++ )
                {
                signal[r] = (signal[r] * c + image[r][c]) / (c + 1);
                }
            }
        }    


    return( signal );
    }

//-- end squish -----------------------------------------------------------------------

int
find_edge( long *signal, int nsig, BOOL bright_dark, BOOL plotit, float resol, double threshold )
    {
    // Use a simple 1D fit to find an edge in the signal.
    // No fancy FFTs here. If the contrast is below THRESHOLD then
    // return -1.

    long 
        top_rail,
        bottom_rail,
        model,
        temp;

    int
        n,
        e,
        mine,
        i,
        margin;

    double
        ft,
        fb,
        contrast,
        min,
        corr;
    
    BOOL
        bad,
        first;

    FILE
        *out;

    // The model edge is a step from top_rail to bottom_rail.
    // These rails are determined from the leading and training
    // 10% of the signal. It would be bad to use min/max values
    // for the rails, since there might be a spike at the edge.

    bad = FALSE;  // low contrast?

    margin = nsig / 10;

    for ( i=0; i < margin; i++ )
        top_rail = (top_rail * i + signal[i]) / (i + 1);

    n = 0;
    for ( i=nsig-1; i > (nsig-margin); i-- )
        {
        bottom_rail = (bottom_rail * n + signal[i]) / (n + 1);
        n++;
        }

    if ( ! bright_dark )
        {
        temp = bottom_rail;
        bottom_rail = top_rail;
        top_rail = temp;
        }

    if ( top_rail <= bottom_rail )
        {
        printf( "\n\nWARNING: signal levels look wrong. Setting shift to zero.\n\n" );
        bad = TRUE;
        }

    ft = top_rail;
    fb = bottom_rail;
    contrast = 100.0 * fabs( ft - fb ) / ( (ft + fb)/2.0 );

    if ( contrast < threshold )
        {
        printf( "\n\nWARNING: contrast is too low (%1.1f). Setting shift to zero.\n\n", contrast );
        bad = TRUE;
        }

    if ( bad )  // dump a straight line into model.dat and return -1
        {
        if ( plotit )
            {
            out = fopen( "model.dat", "w" );
            for ( i=0; i < nsig; i++ )
                {
                model = bottom_rail;
                fprintf( out, "%f %d\n", i*resol,  model ); 
                }
            fclose( out );
            }
        return( -1 );
        }


    first = TRUE;

    for ( e=0; e < nsig; e++ )               // e is the edge. calculate the fit
        {                                    // to a model step 
        corr = 0.0;
        for ( i=0; i < nsig; i++ )
            {
            if ( i >= e )                    // the model is just a step from top_rail  
                {                            // to bottom_rail
                if ( bright_dark )
                    model = bottom_rail;
                else
                    model = top_rail; 
                }
            else
                {
                if ( bright_dark )
                    model = top_rail;
                else
                    model = bottom_rail;
                }

            corr = corr + fabs( model - signal[i] );
            }

        if ( first )
            {
            first = FALSE;
            min  = corr;
            mine = e;
            }
        else if ( corr < min )
            {
            min  = corr;
            mine = e;
            }
        }

    // printf( "\nBest fit found at %d\n", mine );

    if ( plotit )
        {
        out = fopen( "model.dat", "w" );
        for ( i=0; i < nsig; i++ )
            {
            if ( i >= mine )            
                {
                if ( bright_dark )
                    model = bottom_rail;
                else
                    model = top_rail; 
                }
            else
                {
                if ( bright_dark )
                    model = top_rail;
                else
                    model = bottom_rail;
                }
            fprintf( out, "%f %d\n", i*resol,  model ); 
            }
        fclose( out );
        }

    return( mine );

    }

//-- end find_edge --------------------------------------------------------------------

void
show_plot( char *title )
    {            // Use gnuplot to show the signal and edge
    FILE *gnu;   // Generate signal.gnu file
    
    gnu = fopen( "signal.gnu", "w" );
    if ( strlen( title ) > 0 ) fprintf( gnu, "set title \"%s\"\n", title ); 
    fprintf( gnu, "set xlabel \"um\"\n" );
    fprintf( gnu, "set ylabel \"signal\"\n" );
    fprintf( gnu, "plot \"signal.dat\" title \"signal\" with lines lt rgb \"blue\", \\\n" );
    fprintf( gnu, "\"model.dat\"  title \"model\"  with lines lt rgb \"red\"\n" ); 
    fclose(  gnu );

    system( "gnuplot -persist signal.gnu" );
    }



//-- end show_plot --------------------------------------------------------------------
    
//-------------------------------------------------------------------------------------

int main( int argc, char *argv[] )
    {

    int
        edge,
        i,
	nsig,
        fd,
        r,
        c,
        nr,
        nc;

    float
        x,
        shift,
        resol;

    double
        threshold;

    char
        *title,
        *command,
        *imagename,
        *argstr;

    BOOL
        plotit,
        vertical,
        bright_dark;

    short int
        si;

    int
        **image;

    long
        *signal;

    FILE
        *plot;

    argstr    = (char *) malloc( 256 );
    imagename = (char *) malloc( 256 );
    command   = (char *) malloc( 256 );


    if( argc < 7 )
        {
        printf( "\nUse: find_edge [vertical|horizontal] [bright-dark|dark-bright] imagefile.img xpixels ypixels nm/pixel [plot] [title] [threshold %]\n\n" );
        printf(   "     Given an image of an edge, measure the position of that edge and then move the EBPG\n" );
        printf(   "     stage to that location. If the edge is vertical, then the stage will move in X.\n" );
        printf(   "     [vertical| horizontal] refer to the edge itself - Is the edge horizontal or vertical?\n" );
        printf(   "     If the left-to-right transition is from bright to dark then use the option bright-dark.\n" );
        printf(   "     If the top-to-bottom transition is from bright to dark then use the option bright-dark.\n" );
        printf(   "     There are no defaults, so you must include all the options, in the correct order.\n" );
        printf(   "     Well ok, except for the last one: threshold defaults to 10% \n" );
        printf(   "     Image files are 16-bit raw format. The suffix ('.img' or '.raw') should be included.\n" );
        printf(   "     Use the 'plot' option to display the signal and edge detection results.\n" );
        printf(   "     After finding the edge, this program will move the EBPG stage to that edge. Your script\n" );
        printf(   "     can then grab the stage coordinate with 'pg get table'. \n\n" );
        exit(0);
        }

    plotit = argc > 7;

    imagename = argv[3];
    sscanf( argv[4], "%d", &nc );
    sscanf( argv[5], "%d", &nr );
    sscanf( argv[6], "%f", &resol );

    argstr = argv[1]; 
    vertical = (strcmp( argstr, "vertical") == 0);

    argstr = argv[2];
    bright_dark = (strcmp( argstr, "bright-dark" ) == 0);

    if ( argc > 8 )
        {
        title = argv[8];
        }
    else
        {
        title = (char *) malloc( 1 );
        title[0] = 0;
        }

    if ( argc > 9 )
        sscanf( argv[9], "%lf", &threshold );
    else
        threshold = THRESHOLD;

    printf( "        Image: %s\n", imagename );
    printf( "        Size:  %d x %d \n", nr, nc ); 
    printf( "        Resol: %8.5f nm\n", resol );
    printf( "        Threshold: %1.2lf \045 \n", threshold );
 
    if ( vertical ) 
        {
        printf( "        We are looking for a vertical edge.\n" );
        if ( bright_dark )
            printf( "        The image should be bright on the left.\n" );
        else
            printf( "        The image should be bright on the right.\n" );
        }
    else
        {
        printf( "        We are looking for a horizontal edge.\n" );
        if ( bright_dark )
            printf( "        The image should be bright on the top.\n" );
        else
            printf( "        The image should be bright on the bottom.\n" );
        }
    

    resol = resol / 1000.0;   // um

    image = (int **) int_matrix( 0, nc-1, 0, nr-1 );

    fd  = open( imagename, 0 );
    if ( fd <= 0 )
        {
        printf( "\nERROR: unable to open %s\n\n", imagename );
        exit(0);
        }

    for ( r=0; r < nr; r++ )
        for ( c=0; c < nc; c++ )
            {
            if( ! read( fd, &si, 2 ) )
                {
                printf( "\nERROR: unexpected end of file %s\n", imagename );
                exit(0);
                }
            image[r][c] = si;
            }

    close( fd );

    normalize( image, nr, nc );

    signal = squish( image, nr, nc, vertical );

    if ( vertical )
        nsig = nc;
    else
        nsig = nr;

    edge = find_edge( signal, nsig, bright_dark, plotit, resol, threshold );

    if ( plotit )
        {
        plot = fopen( "signal.dat", "w" );
        for ( i=0; i < nsig; i++ ) 
            { 
            x = i * resol;
            fprintf( plot, "%1.3f %d\n", x, signal[i] );
            }
        fclose( plot );
        show_plot( title );
        }

    // Move the stage to center the edge.

    if ( edge < 0 )
        shift = 0.0;
    else
        shift = resol * (edge - (nsig - 1.0) / 2.0);
   
    if ( vertical )
        {
        sprintf( command, "pg move pos --rel %1.3f,0", shift );
        }
    else
        {
        shift = -shift;
        sprintf( command, "pg move pos --rel 0,%1.3f", shift );
        }

    printf( "\n        %s\n\n", command );

    system( command );

    // The calling script must now query the stage coordinate
    // with "pg get tab_x" or "pg get tab_y".

    }

