#!/usr/bin/env python3

# A calculator for e-beam parameters, helping you
# find a good beam step size for a given dose, 
# current, and maximum pixel clock. You should 
# edit MAXCLOCK below to match your e-beam system.

# INSTALLATION
#
# Requires python3 and qt5. Do you already have python3 ?
# Try typing
#
#         python3
#
# If that does not give you a prompt >>> then you can
# install python3 with
#
#         sudo yum install python3
# 
# Next you need QT5 for graphics. One way to install qt5
# for python is...
#
#         python3 -m pip install --upgrade pip
#                                              (wait patiently ~2 min)
#         python3 -m pip install pyqt5
# 
# Now try running this calculator program with
#
#        ./qtcalc.py
#
# You can assign the calculator to a desktop icon using by putting
# the file calc.desktop in your ~/Desktop folder. You might have to 
# edit calc.desktop if you put calc.py somewhere other than /usr/local/bin


 
import sys
import os
import math

from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui

MAXCLOCK = 50  # MHz


class GroupBox(QWidget):

    def __init__(self):
        QWidget.__init__(self)
        global MAXCLOCK

        self.setWindowTitle("e-beam calculator")
        layout = QGridLayout()
        self.setLayout(layout)

        groupbox = QGroupBox("Output")
        groupbox.setStyleSheet("color: blue;")
        layout.addWidget(groupbox)
        
        vbox = QGridLayout()
        groupbox.setLayout(vbox)

        exp_label = QLabel( "Exp time" )
        exp_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        vbox.addWidget( exp_label, 0, 0 )

        self.time_box = QLineEdit('...')
        vbox.addWidget( self.time_box, 0, 1 )

        self.unitsComboBox = QComboBox()
        self.unitsComboBox.addItem('minutes')
        self.unitsComboBox.addItem('hours')
        self.unitsComboBox.addItem('days')
        self.unitsComboBox.addItem('years')
        self.unitsComboBox.addItem('centuries')
        vbox.addWidget( self.unitsComboBox, 0, 2 )
        self.unitsComboBox.activated.connect( self.evaluate )

        spacer = QLabel( "            " )
        vbox.addWidget( spacer, 0, 3 )

        clock_label = QLabel( "Clock" )
        clock_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        vbox.addWidget( clock_label, 0, 4 )

        self.clock_box = QLineEdit('...')
        vbox.addWidget( self.clock_box, 0, 5 )

        mhz_label = QLabel( "MHz (max %d)" % MAXCLOCK )
        mhz_label.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        vbox.addWidget( mhz_label, 0, 6 )

        spacer = QLabel( "            " )
        vbox.addWidget( spacer, 1, 0 )

        minstep_label = QLabel( "Min step" )
        minstep_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        vbox.addWidget( minstep_label, 2, 0 )

        self.minstep_box = QLineEdit('...')
        vbox.addWidget( self.minstep_box, 2, 1 )

        nm_label = QLabel( "nm" )
        nm_label.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        vbox.addWidget( nm_label, 2, 2 )

        mc_label = QLabel( "Max current" )
        mc_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        vbox.addWidget( mc_label, 2, 4 )

        self.mc_box = QLineEdit('...')
        vbox.addWidget( self.mc_box, 2, 5 )

        na_label = QLabel( "nA" )
        na_label.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        vbox.addWidget( na_label, 2, 6 )

        #------------

        spacer = QLabel( "            " )
        layout.addWidget( spacer )

        groupbox2 = QGroupBox("Input")
        layout.addWidget( groupbox2 )
        
        vbox2 = QGridLayout()
        groupbox2.setLayout( vbox2 )

        step_label = QLabel( "Step size" )
        step_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        vbox2.addWidget( step_label, 0, 0 )

        self.step_box = QLineEdit('5')
        vbox2.addWidget( self.step_box, 0, 1 )
        self.step_box.returnPressed.connect( self.evaluate )

        nm_label = QLabel( "nm                  " )
        nm_label.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        vbox2.addWidget( nm_label, 0, 2 )

        spacer = QLabel( "            " )
        vbox2.addWidget( spacer, 0, 3 )

        current_label = QLabel( "     Current" )
        current_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        vbox2.addWidget( current_label, 0, 4 )

        self.current_box = QLineEdit('10')
        vbox2.addWidget( self.current_box, 0, 5 )
        self.current_box.returnPressed.connect( self.evaluate )

        na_label = QLabel( "nA                  " )
        na_label.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        vbox2.addWidget( na_label, 0, 6 )

        spacer = QLabel( "            " )
        vbox2.addWidget( spacer, 1, 0 )

        area_label = QLabel( "Area" )
        area_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        vbox2.addWidget( area_label, 2, 0 )

        self.area_box = QLineEdit('...')
        vbox2.addWidget( self.area_box, 2, 1 )
        self.area_box.returnPressed.connect( self.evaluate )

        self.areaunitsCB = QComboBox()
        self.areaunitsCB.addItem('um2')
        self.areaunitsCB.addItem('mm2')
        self.areaunitsCB.addItem('cm2')
        self.areaunitsCB.addItem('m2')
        self.areaunitsCB.addItem('acres')
        vbox2.addWidget( self.areaunitsCB, 2, 2 )
        self.areaunitsCB.activated.connect( self.evaluate )

        dose_label = QLabel( "Dose" )
        dose_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        vbox2.addWidget( dose_label, 2, 4 )

        self.dose_box = QLineEdit('1000')
        vbox2.addWidget( self.dose_box, 2, 5 )
        self.dose_box.returnPressed.connect( self.evaluate )

        uc_label = QLabel( "uC/cm2" )
        uc_label.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        vbox2.addWidget( uc_label, 2, 6 )

        spacer = QLabel( "            " )
        vbox2.addWidget( spacer, 3, 0 )

        eval_label = QLabel( "Evaluate" )
        eval_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        vbox2.addWidget( eval_label, 4, 4 )

        equals = QPushButton('=')
        vbox2.addWidget( equals, 4, 5 )        
        equals.clicked.connect( self.evaluate )

    def evaluate( self ):
        global MAXCLOCK
        self.current_box.setStyleSheet("color: black;")
        self.step_box.setStyleSheet(   "color: black;")
        self.area_box.setStyleSheet(   "color: black;")
        self.dose_box.setStyleSheet(   "color: black;")
        self.clock_box.setStyleSheet(  "color: black;")
        self.minstep_box.setStyleSheet("color: black;")
        self.mc_box.setStyleSheet(     "color: black;")


        time_unit = self.unitsComboBox.currentText()
        area_unit = self.areaunitsCB.currentText()

        try:
            current = float( self.current_box.text() )
        except:
            current = 10.0
            self.current_box.setText( "ERROR" )
            self.current_box.setStyleSheet("color: red;")
            self.clock_box.setText( "ERROR" )
            self.clock_box.setStyleSheet("color: red;")
            return
        if current < 0 :
            current = -current
            self.current_box.setText( "%1.2f" % current )
        if current == 0 :
            self.current_box.setText( "ERROR" )
            self.current_box.setStyleSheet("color: red;")
            self.clock_box.setText( "ERROR" )
            self.clock_box.setStyleSheet("color: red;")
            return

        try:
            step = float( self.step_box.text() )
        except:
            step = 5
            self.step_box.setText( "ERROR" )
            self.step_box.setStyleSheet("color: red;")
            self.clock_box.setText( "ERROR" )
            self.clock_box.setStyleSheet("color: red;")
            return
        if step <= 0 :
            self.step_box.setText( "ERROR" )
            self.step_box.setStyleSheet("color: red;")
            self.clock_box.setText( "ERROR" )
            self.clock_box.setStyleSheet("color: red;")
            return
        
        try:
            area = float( self.area_box.text() )
        except:
            area = 0.0
            self.area_box.setText( "0" )
        if area < 0 :
            area = 0.0
            self.area_box.setText( "0" )
            
        try:
            dose = float( self.dose_box.text() )
        except:
            dose = 1000.0
            self.dose_box.setText( "ERROR" )
            self.dose_box.setStyleSheet("color: red;")
            self.clock_box.setText( "ERROR" )
            self.clock_box.setStyleSheet("color: red;")
            return
        if dose < 0 :
            dose = -dose
            self.dose_box.setText( "%1.2f" % dose )
        if dose == 0 :
            self.dose_box.setText( "ERROR" )
            self.dose_box.setStyleSheet("color: red;")
            self.clock_box.setText( "ERROR" )
            self.clock_box.setStyleSheet("color: red;")
            return

        if area_unit == "um2" :
            scale = 1e-8
        elif area_unit == "mm2" :
            scale = 1e-2
        elif area_unit == "cm2" :
            scale = 1.0
        elif area_unit == "m2" :
            scale = 1e4
        elif area_unit == "acres" :
            scale = 40468564.2
        else:
            print("ERROR: unknown area unit [%s]" % self.area_unit)

        if time_unit == "seconds" :
            timescale = 1
        elif time_unit == "minutes" :
            timescale = 1.0/60.0
        elif time_unit == "hours" :
            timescale = 1.0/(60.0 * 60.0)
        elif time_unit == "days" :
            timescale = 1.0/(60.0 * 60.0 * 24.0)
        elif time_unit == "years" :
            timescale = 1.0/(60.0 * 60.0 * 24.0 * 365.25)
        elif time_unit == "centuries" :
            timescale = 1.0/(60.0 * 60.0 * 24.0 * 365.25 * 100.0)
        else:
            print("ERROR: unknown time unit [%s]" % self.time_unit)

        """
        print()
        print( "current:    %1.2f nA" % current )
        print( "step:       %1.2f nm" % step )
        print( "area:       %1.2f %s" % (area, area_unit) )
        print( "dose:       %1.2f uC/cm2" % dose )
        print( "time scale: %1.2f" % (1.0/timescale) )
        print()
        """

        current   = current * 1e-9         # amps
        step      = step * 1e-7            # cm
        area      = area * scale           # cm2
        dose      = dose * 1e-6            # C/cm2
        pixelarea = step * step            # cm2

        time = timescale * dose * area / current  

        if time > 0.1 and time < 10000 :
            self.time_box.setText( "%4.2f" % time )
        else:
            self.time_box.setText( "%4.2g" % time )

        self.time_box.setStyleSheet("color: blue;")

        maxcur = dose * pixelarea * MAXCLOCK * 1e6 * 1e9 # nA

        if maxcur > 0.1 and maxcur < 10000 :
            self.mc_box.setText( "%4.2f" % maxcur )
        else:
            self.mc_box.setText( "%4.2g" % maxcur )

        self.mc_box.setStyleSheet("color: blue;")

        minstep = math.sqrt( current / (MAXCLOCK * 1e6 * dose) ) * 1e7  # nm

        if minstep > 0.1 and minstep < 10000 :
            self.minstep_box.setText( "%4.1f" % minstep )
        else:
            self.minstep_box.setText( "%4.2g" % minstep )

        self.minstep_box.setStyleSheet("color: blue;")

        clock = 1e-6 * current / (dose * pixelarea)  # MHz
  
        if clock > 0.1 :
            self.clock_box.setText( "%4.2f" % clock )
        else:
            self.clock_box.setText( "%6.2g" % clock )

        if clock > MAXCLOCK or clock < (0.04 * 1e-6) :
            self.clock_box.setStyleSheet("color: red;")
        else:
            self.clock_box.setStyleSheet("color: blue;")


#============================================================   

app = QApplication(sys.argv)
calc = GroupBox()
calc.show()
sys.exit(app.exec_())
