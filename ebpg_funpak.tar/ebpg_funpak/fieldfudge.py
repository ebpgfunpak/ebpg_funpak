#!/usr/bin/env python3

import sys
import os

version = 2.0

# v2.0   Old Beamers generate gpf without Z coordinates
#        so now we deal with that.

def use() :
    print( "\nField Fudge %1.1f" % version )
    print( "\nUse: fieldfudge infile.gpf outfile.gpf overlap(nm)" )
    print( "\nMove gpf field placements so the pattern" )
    print(   "overlaps at field boundaries. This will produce" )
    print(   "a double exposure at field crossings. " )
    print(   "The pattern center remains the same, but" )
    print(   "the new pattern will not properly overlay" )
    print(   "other patterns, unless the other patterns also" )
    print(   "have the same fudge and the same center.\n" )
    print(   "This program works best with tiled fields." )
    print(   "Floating fields will work, but the results will" )
    print(   "be confusing and non-optimal.\n\n" )
    sys.exit()
    

# main

if len( sys.argv ) < 4 : use()
if not ".gpf" in sys.argv[1] : use()
if not ".gpf" in sys.argv[2] : use()
try:
    overlap = float( sys.argv[3] )
except:
    use()
    
infile = sys.argv[1]
outfile = sys.argv[2]
ingtxname  = infile.split('.')[0] + ".gtx"
outgtxname = outfile.split('.')[0] + ".gtx"

print( "\n\nInput:   %s" % infile )
print(     "Output:  %s" % outfile )
print(     "Overlap: %1.1f nm\n\n" % overlap )


print(     "gpfgtx %s %s" % (infile, ingtxname) )
os.system( "gpfgtx %s %s" % (infile, ingtxname) )

gtxin  = open( ingtxname, "r" )
gtxout = open( outgtxname, "w" )

# copy the header and grab the field size

mfr   = 0.0
resol = 0.0
line  = ""
init_resol = False
init_mfr = False
floating = False

while not "END" in line :
    line =  gtxin.readline()
    linelower = line.lower()
    item = linelower.split()

    if len( item ) > 1 :
        if item[0] == "mainfieldresolution" :
            mfr  = float( item[1].split(',')[0] )
            print( "\n\nMain field resolution: %1.4f um" % mfr )
            init_mfr = True

        elif item[0] == "resolution" :
            resol = float( item[1].split(',')[0] )
            init_resol = True

        elif item[0] == "mainfieldsize" :
            if not init_mfr :
                print( "\n\nERROR: I did not find the mfr in the header.\n" )
                sys.exit()
            if not init_resol :
                print( "\n\nERROR: I did not find the resolution in the header.\n" )
                sys.exit()
            fields = item[1].split(',')
            xfield = resol * mfr * float( fields[0] ) 
            yfield = resol * mfr * float( fields[1] )
            print( "Field (block) size: %1.2f %1.2f um\n" % (xfield, yfield) )

        elif item[0] == "mainfieldplacement":
            floating = (item[1] == "floating")
            if not floating and item[1] != "meander" :
                print( "\n\nERROR: unknown field placement type: %s\n\n" % item[1] )
                sys.exit()
            if not floating:
                line = line.replace( "MEANDER", "FLOATING" )

    gtxout.write( line )

        
if floating:
    print( "\nMain field placement type: floating\n" )
else:
    print( "\nMain field placement type: meander\n" )

    
# read the fields and fudge the field placement

overlapx = 1.0 - 0.001 * overlap / xfield   # fractional change
overlapy = 1.0 - 0.001 * overlap / yfield

zstage = True           # initial value... you might have an old Beamer

end_of_file = False

while not end_of_file :
    line = gtxin.readline()
    linelower = line.lower()
    end_of_file = len( line ) == 0
    word = linelower.split()

    if len(word) > 0 and word[0] == "field" :
        
        if floating:
            item = word[1].split(',')
            x = float( item[0] )
            y = float( item[1] )
            try:
                z = float( item[2] )
                zstage = True
            except:
                z = 0
                zstage = False
        else:                           # we are counting on gpfgtx
            x = float( word[4][1:] )    # to insert x,y,z in the comment 
            y = float( word[6] )        # and we hope they never change.
            try:
                z = float( word[8] )     
                zstage = True
            except:
                z = 0
                zstage = False          # older Beamers do not support Z stage
            
        x = x * overlapx        
        y = y * overlapy
        
        if zstage :
            print( "FIELD %1.6f,%1.6f,%1.6f ! (um)" % (x, y, z) )
            gtxout.write( "FIELD %1.6f,%1.6f,%1.6f ! (um) fudged\n" % (x, y, z) )
        else:
            print( "FIELD %1.6f,%1.6f ! (um)" % (x, y) )
            gtxout.write( "FIELD %1.6f,%1.6f ! (um) fudged\n" % (x, y) )


    else:
        gtxout.write( "%s" % line )
    
gtxout.close()
gtxin.close()

print(     "gtxgpf %s %s" % (outgtxname, outfile) )
os.system( "gtxgpf %s %s" % (outgtxname, outfile) )
os.system( "rm %s %s" % (outgtxname, ingtxname) )

print( "\n\n%s >>> %s" % (infile, outfile) )
print( "overlap: %1.1f nm" % overlap )

print( "\n\nDone.\n\n" )


