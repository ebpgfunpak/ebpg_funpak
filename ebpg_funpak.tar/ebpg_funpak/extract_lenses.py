#!/usr/bin/python3

# create c1c2cur.dat for use in set_current
# This program extracts C1 and C2 values using
# pg info arc beam. We use the values for the
# 300 um aperture. We do not need curves for
# the other apertures, since current values can
# be scaled by diameter^2.

import sys
import os
import string
import operator


def sort_table(table, cols):
    """                                                                             
    sort a table by multiple columns                                                
    table: a list of lists (or tuple of tuples) where each inner list
           represents a row      
    cols:  a list (or tuple) specifying the column numbers to sort by               
    """

    is_a_list = True
    
    try:
        len( cols )
    except:
        is_a_list = False

    if is_a_list:
        rcols = reversed( cols )
        for col in rcols :
            table = sorted(table, key=operator.itemgetter(col))
    else:
        table = sorted(table, key=operator.itemgetter(cols))


    return table

#---------------------------------------------------------------------------

def archive_list() :
    #
    # Create a list of beam archive files (100 kV)
    # File names can be of the form 10na_300,beam_100 or 10na_300um_2.beam_100
    # and they must be in /home/pg/archive of course.
    #
    # Return a table of [filename, current, aperture] whose
    # values were extracted from the file names.

    stuff = os.popen( "ls /home/pg/archive/*.beam_100" ).read()
    files = stuff.split()
    table = []

    for file in files :
        filename = file.split('/')[4]
        basename = filename.split('.')[0]
        scurrent = filename.split('_')[0]
        if "pa" in scurrent :
            current = float( scurrent.replace( "pa", "." ) )
            current = current / 1000.0
        else:
            current = float( scurrent.replace( "na", "." ) )
        saperture = filename.split('_')[1]
        if "um" in saperture :
            saperture = saperture.split('u')[0]     # old style
        else:
            saperture = saperture.split('.')[0]     # new style
        aperture = int( saperture )
        table.append( [basename, current, aperture] )

    table = sort_table( table, (2,1) )    # sort by aperture, then current

    return( table )

#---------------------------------------------------------------------------
# main


beam_table = archive_list()     # [filename, current, aperture]  derived from the filenames
table = []                      # [filename, c1, c2, current]    derived from 'pg info arc beam'

for beam in beam_table :
    filename = beam[0]
    current  = beam[1]
    aperture = beam[2]
 
    if aperture == 300 :
        stuff = os.popen( "pg info arc beam %s" % filename ).readlines()
        for line in stuff:
            if "Archive" in line:
                word = line.split()
                name = word[1]
            if "C1 setting" in line :
                word = line.split()
                c1 = word[2]
                c2 = word[8]
            if "beamcurrent" in line :
                word = line.split()
                current = float( word[7] )
                units   = word[8]
                if "pA" in units :
                    current = current / 1000.0
                #print( "%s %s %1.2f" % (c1, c2, current) )
                table.append( [name, c1, c2, current] )
        
            
table = sort_table( table, 3 ) # sort by current

print( "\n" )

out = open( "c1c2cur.dat", "w" )

for row in table :
    print( "%s %1.2f %s %s" % (row[0], row[3], row[1], row[2] ) )
    out.write( "%s %s %1.2f\n" % (row[1], row[2], row[3]) )

out.close()

print( "\nThe file c1c2cur.dat has been created." )
print( "Make sure it is in /home/pg/bin \n" )

