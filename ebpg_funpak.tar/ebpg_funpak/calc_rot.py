#!/usr/bin/env python3

import sys
import math

try:
    data = open( "temp_rot.txt", "r" )
except:
    print("\nUnable to read mark location data from temp_rot.txt\n")
    sys.exit()

first  = data.readline()
second = data.readline()

(sx1, sy1) = first.split(',')
(sx2, sy2) = second.split(',')

x1 = float( sx1.split('_')[0] )
y1 = float( sy1.split('_')[0] )
x2 = float( sx2.split('_')[0] )
y2 = float( sy2.split('_')[0] )

horizontal = abs(x1 - x2) > 5.0 * abs(y1 - y2)
vertical   = abs(y1 - y2) > 5.0 * abs(x1 - x2)

if not horizontal and not vertical :
    print("\nERROR: these marks are neither horizontally nor vertically aligned,")
    print("       or the rotation is greater than 11 degrees.\n")
    sys.exit()

if horizontal :
    angle = (180.0 / 3.1415926) * math.atan( (y2 - y1) / (x2 - x1) )
else:
    angle = (180.0 / 3.1415926) * math.atan( (x2 - x1) / (y2 - y1) )

print("\nThe substrate is rotated by %1.2f degrees." % angle)

if abs( angle ) > 0.2 :
    print("This is too large. You should unload the substrate and readjust the rotation.\n")
else:
    print("Good enough.\n")

