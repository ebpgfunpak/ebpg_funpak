#!/usr/bin/env python3


"""
radial_sort.py 

Requires gpfgtx and gtxgpf programs.

This program reads a gpf file and sorts the shapes into radial
order. Actually, this might more accurately be described as a "spiral
sort".  The shapes in a radial region are also sorted by angle, so the
resulting writing order should be fastest tangentailly and slower
radially. The center point is fixed, usually at the field center, as
specified by the constants X0 and Y0.

It would be wise to look for bad shapes, but currently the 
"bad_shape" function does not work. The roundoff errors are
very difficult.

v2    Sorts multiple fields

v3    Does not use any implied parameters, since this is 
      mysteriously difficult to get right.

v4    gtxgpf is now more fussy about shapes fitting into the
      given subfield size, and so we increase the subfield size
      (as stated in the header) by ten percent.

v4.1  Deals with the stupid change in the syntax of gpfgtx

v4.2  some versions of gptgtx screw with the output file name
      so we unscrew it

v4.3  converted to python3
"""
import os
import sys
import math
import string
import operator
from math import *

version = 4.3

# Center of the pattern is X0,Y0. 524288 is half of 1048576 = 2^20.
# If the center of the pattern is not in the center of the field,
# then you should change this:

X0 = 524288
Y0 = 524288

CHUNK = 1.0   # micron. Size of a chunk sorted as one group of shapes.

PI    = 3.1415926
PI2   = PI / 2.0
TWOPI = 2.0 * PI


# This is where you can specify a different command for gpfgtx and gtxgpf,
# in case you have kept the old, fast versions in a different place.

GPFGTX="gpfgtx"
GTXGPF="gtxgpf"

#-----------------------------------------------------------------------------------------------

def gpfgtx( infile, outfile ):
    #
    # The old gpfgtx worked just fine, but the new version 
    # screws with the file names. This function will 
    # try first with the old syntax. If that fails, it 
    # will try again with the new syntax. Finally, we 
    # will unscrew the file names if necessary.
    # 
    global GPFGTX

    if not ".gpf" in infile :
        print("\nERROR: gpf file name must end in .gpf\n") 
        sys.exit()
    if not ".gtx" in outfile :
        print("\nERROR: gtx file name must end in .gtx\n") 
        sys.exit()

    os.system( "%s %s %s &> gpfgtx.log" % (GPFGTX, infile, outfile) )
    log = open( "gpfgtx.log", "r" )
    no_file = False
    for stuff in log.readlines() :
        stuff = stuff.lower()
        if "could not open" in stuff or \
           "can't open"     in stuff or \
           "no such file"   in stuff or \
           "usage"          in stuff :
            no_file = True
            break
    log.close()
    
    # maybe we have the new, stupid version

    if no_file :
        name = infile.split('.')[0]
        os.system( "%s ./%s.gpf &> gpfgtx.log" % (GPFGTX, name) )
        log = open( "gpfgtx.log", "r" )
        no_file = False
        for stuff in log.readlines() :
            stuff = stuff.lower()
            if "could not open" in stuff or \
               "can't open"     in stuff or \
               "no such file"   in stuff or \
               "usage"          in stuff :
                no_file = True
                break
        log.close()
        if no_file :
            print("\nERROR: no such file: %s\n" % infile)
            sys.exit()
        os.system( "mv %s_gpf.gtx %s" % (name, outfile) )    


    # maybe we gpfgtx screwed with the output file name
    # Raith says, because f*#k you that's why

    try:
        fooked_name = outfile.split('.')[0] + "_gpf.gtx"
        fooked = open( fooked_name, "r" )
        fooked.close()
        print((     "mv %s %s" % (fooked_name, outfile) ))
        os.system( "mv %s %s" % (fooked_name, outfile) )
    except:
        print(":)")


#-----------------------------------------------------------------------------------------------

def sort_table(table, cols):
    """ 
    sort a table by multiple columns
    table: a list of lists (or tuple of tuples) where each inner list represents a row
    cols:  a list (or tuple) specifying the column numbers to sort by
    """

    is_a_list = True
    try:
        len( cols )
        print("...") 
    except:
        is_a_list = False

    if is_a_list:
        rcols = reversed( cols )
        for col in rcols :
            table = sorted(table, key=operator.itemgetter(col))
    else:
        table = sorted(table, key=operator.itemgetter(cols))


    return table

#-----------------------------------------------------------------------------------------------

def bad_shape( shift_rb_used, shift_lt_used,  \
               bss_sub, base_lsw, height_lsw, \
               shift_lt_lsw, shift_rb_lsw, activate_line ):

    # Look for illegal shapes.
    # This has some unknown problem. It does not yet work.

    base   = int( base_lsw )
    height = int( height_lsw )

    if height == 0 : return( True )

    attributes = activate_line.split()

    if shift_rb_used:
        srb = int( shift_rb_lsw )
    elif "rb45" in attributes:
        srb = height
    else:
        srb = 0

    if shift_lt_used:
        slt = int( shift_lt_lsw )
    elif "lt45" in attributes:
        slt = height
    else:
        slt = 0

    if "ltNeg" in attributes : slt = -slt
    if "rbNeg" in attributes : srb = -srb

    return ( slt > (base * bss_sub + srb) )

#-----------------------------------------------------------------------------------------------

def angle_360( x, y ):

    # calculate the angle in the range 0..2PI

    if x == 0.0 : 
        if y > 0.0 :
            a = PI2
        else:
            a = -PI2
    elif y == 0.0 :
        if x > 0.0 :
            a = 0.0
        else:
            a = PI
    elif x > 0.0 and y > 0.0 :
        a = math.atan( y / x )
    elif x < 0.0 and y > 0.0 :
        a = PI - math.atan( y / (-x) )
    elif x < 0.0 and y < 0.0 :
        a = PI + math.atan( y / x )
    else:
        a = TWOPI - math.atan( -y/x )

    return( a )


#-----------------------------------------------------------------------------------------------

def sorting_parameter( x, y, chunk ):

    r = chunk * math.floor( math.sqrt( x * x + y * y ) / chunk )
    a = angle_360( x, y )
    s = chunk * math.floor((r * a + 1000 * r) / chunk )

    return( s )

#-----------------------------------------------------------------------------------------------

# Parse one line of "repetition". This is woefully and gloriously complex, 
# and should not be necessary.


def parse( bit, mx1c, mx2c, my1c, my2c, sx1c, sx2c, sy1c, sy2c, m1dx, m1dy, m2dx, m2dy, s1dx, \
    s1dy, s2dx, s2dy, base, height, msf, main_resol, sub_resol ) :
    if not hasattr( parse, "init" ): 
        parse.init = True
        parse.m1c  = 0
        parse.m2c  = 0  # static variables
        parse.s1c  = 0
        parse.s2c  = 0

    bits = bit.split()

    if "Repetition Main 1 X Count" in bit: 
        mx1c = int( bits[5] )
        parse.m1c = mx1c
    elif "Repetition Main 1 X LSW" in bit:
        m1dx = int( bits[5] )
    elif "Repetition Main 1 Y Count" in bit: 
        my1c = int( bits[5] )
    elif "Repetition Main 1 Y LSW" in bit:
        m1dy = int( bits[5] )
    elif "Repetition Main 1 Count" in bit and not ("Y" in bits) and not ("X" in bits) :
        parse.m1c  = int( bits[4] )  
    elif "Repetition Main 2 Count" in bit and not ("Y" in bits) and not ("X" in bits) :
        parse.m2c  = int( bits[4] )
    elif "Repetition Main 2 X LSW" in bit:
        m2dx = int( bits[5] )
    elif "Repetition Main 2 X Count" in bit:
        mx2c = int( bits[5] )
    elif "Repetition Main 2 Y Count" in bit:
        my2c = int( bits[5] )
        parse.m2c = my2c
    elif "Repetition Main 2 Y LSW" in bit:
        m2dy = int( bits[5] )
    elif "Repetition Sub 1 X" in bit and not ("Count" in bits):
        s1dx = int( bits[4] )
    elif "Repetition Sub 1 X Count" in bit: 
        sx1c = int( bits[5] )
        parse.s1c = sx1c
    elif "Repetition Sub 1 Y Count" in bit:
        sy1c = int( bits[5] )
    elif "Repetition Sub 1 Y" in bit and not ("Count" in bits):
        s1dy = int( bits[4] )
    elif "Repetition Sub 1 Count" in bit and not ("Y" in bits) and not ("X" in bits) :
        parse.s1c  = int( bits[4] )   
    elif "Repetition Sub 2 X" in bit and not ("Count" in bits):
        s2dx = int( bits[4] )
    elif "Repetition Sub 2 X Count" in bit:
        sx2c = int( bits[5] )
    elif "Repetition Sub 2 Y" in bit and not ("Count" in bits):
        s2dy = int( bits[4] )
    elif "Repetition Sub 2 Y Count" in bit:
        sy2c = int( bits[5] )
        parse.s2c = sy2c
    elif "Repetition Sub 2 Count" in bit and not ("Y" in bits) and not ("X" in bits) :
        parse.s2c  = int( bits[4] )
    elif "Repetition" in bits:
        print("\nUnknown repetition line: [%d]\n" % bit) 

    # Are the following correct? It might be that some parameters need to be
    # retained and used by implication in successive Activate lines.

    if "Activate" in bits and "SRV1" in bits and not ("SRV2" in bits):
        m1dx = 0
        m1dy = 0
        m2dx = 0
        m2dy = 0
        mx1c = 0
        my1c = 0
        mx2c = 0
        my2c = 0
        sx2c = 0
        sy2c = 0
        s2dx = 0
        s2dy = 0

    if "Activate" in bits and "SRV2" in bits and not ("SRV1" in bits):
        m1dx = 0
        m1dy = 0
        m2dx = 0
        m2dy = 0
        mx1c = 0
        my1c = 0
        mx2c = 0
        my2c = 0
        sx1c = 0
        sy1c = 0
        s1dx = 0
        s1dy = 0

    if "Activate" in bits and "MRV1" in bits and not ("MRV2" in bits):
        s1dx = 0
        s1dy = 0
        s2dx = 0
        s2dy = 0
        sx1c = 0
        sy1c = 0
        sx2c = 0
        sy2c = 0
        mx2c = 0
        my2c = 0
        m2dx = 0
        m2dy = 0

    if "Activate" in bits and "MRV2" in bits and not ("MRV1" in bits):
        s1dx = 0
        s1dy = 0
        s2dx = 0
        s2dy = 0
        sx1c = 0
        sy1c = 0
        sx2c = 0
        sy2c = 0
        mx1c = 0
        my1c = 0
        m1dx = 0
        m1dy = 0

    if "Activate" in bits and "SRV1" in bits and "SRV2" in bits:
        m1dx = 0
        m1dy = 0
        m2dx = 0
        m2dy = 0
        mx1c = 0
        my1c = 0
        mx2c = 0
        my2c = 0

    if "Activate" in bits and "MRV1" in bits and "MRV2" in bits:
        s1dx = 0
        s1dy = 0
        s2dx = 0
        s2dy = 0
        sx1c = 0
        sy1c = 0
        sx2c = 0
        sy2c = 0

    if "Activate" in bits and "MRV1" in bits:
        mx1c = parse.m1c
        
    if "Activate" in bits and "MRV2" in bits:
        my2c = parse.m2c

    if "Activate" in bits and "SRV1" in bits:
        sx1c = parse.s1c
        
    if "Activate" in bits and "SRV2" in bits:
        sy2c = parse.s2c

    # RYH and RXB are used to chop shapes into subfield traps.
    # The savings in space is negligible, but it might prevent
    # blanking between shapes. Let's hope so; otherwise,
    # it's just stupid.

    # V1 is X only, V2 is Y only 

    if "RXB" in bits or "RYH" in bits:  
        s1dx = 0
        s1dy = 0
        s2dx = 0
        s2dy = 0
        m1dx = 0
        m1dy = 0
        m2dx = 0
        m2dy = 0

    if sub_resol <= 0 :
        print("\nERROR: subfield resolution not defined.\m")
        sys.exit()

    h = int( height )
    b = int( base )
    m = int( msf )

    if "RYH" in bits:                           
        if "SRV1" in bits or "SRV2" in bits: 
            s2dy = (h + 1) * m
        elif "MRV1" in bits or "MRV2" in bits:
            m2dy = (h + 1) * m * main_resol/sub_resol

    if "RXB" in bits:
        if "SRV1" in bits or "SRV2" in bits: 
            s1dx = (b + 1) * m
        elif "MRV1" in bits or "MRV2" in bits:
            m1dx = (b + 1) * m * main_resol/sub_resol



    return( (mx1c, mx2c, my1c, my2c, sx1c, sx2c, sy1c, sy2c, m1dx, m1dy, m2dx, m2dy, s1dx, s1dy, s2dx, s2dy ) )


#-----------------------------------------------------------------------------------------------

def expand_array( entry, n, table, chunk, mx1c, mx2c, my1c, my2c, sx1c, sx2c, sy1c, sy2c, \
                  m1dx, m1dy, m2dx, m2dy, s1dx, s1dy, s2dx, s2dy ):
           
    # Loop over x and y repeats, generating new table entries 
    # Could there be both main and subfield repeats on the same line?
    # That would be perverse, so let's just check for perversity first.

    main_repeat = mx1c > 0 or mx2c > 0 or my1c > 0 or my2c > 0
    sub_repeat  = sx1c > 0 or sx2c > 0 or sy1c > 0 or sy2c > 0

    if main_repeat and sub_repeat:
        print("\nERROR: mainfield and subfield arrays appear sumultaneously. This freaks me out, man.")
        print("Try disabling all compaction modes in Beamer (or whatever you used to generate gpf).")
        print("Be sure to disable Beamer's 'compaction diagonal array' option, which is evil.")
        print("Program aborted.")
        sys.exit()

    if not main_repeat and not sub_repeat:
        print("\nERROR: an array contains no repetition values\n") 
        sys.exit()

    activate_line = entry[0]
    main_x_lsw    = entry[1]
    main_y_lsw    = entry[2]
    freq_lsw      = entry[3]
    freq_msw      = entry[4]
    base_lsw      = entry[5]
    height_lsw    = entry[6]
    msf           = entry[7]
    shift_lt_lsw  = entry[8]
    shift_rb_lsw  = entry[9]
    offset_x_lsw  = entry[10]
    offset_y_lsw  = entry[11]
    shift_rb_used = entry[12]
    shift_lt_used = entry[13]

    table[n][0] = "deleted"    

    if main_repeat:
        # strip out MRV1, MRV2, RXB, and RYH from acitivate line
        # loop over mx1c and my2c. Watch for nonzero my1c and mx2c.

        newline = ""
        words = activate_line.split()

        begin = False
        for word in words:
            if (word == "Activate"): begin = True
            if begin and word != "MRV1" and word != "MRV2" and word != "RXB" and word != "RYH" :
                newline = newline + " " + word

        #print "[%s]" % newline
 
        if my1c != 0 or mx2c != 0 :
            print("\nERROR: strange array with my1c or mx2c not zero: [%s]." % activate_line)
            print("What does it mean?\n")
            sys.exit() 
        
        mainx = int( main_x_lsw )
        mainy = int( main_y_lsw )

        for row in range( my2c+1 ):
            y = mainy + m2dy * row
            mainy_s = "%d" % y
            for col in range( mx1c+1 ):
                x = mainx + m1dx * col
                mainx_s = "%d" % x
                s = sorting_parameter( x, y, chunk )
                table.append( [ newline, \
                                mainx_s,       \
                                mainy_s,       \
                                freq_lsw,      \
                                freq_msw,      \
                                base_lsw,      \
                                height_lsw,    \
                                msf,           \
                                shift_lt_lsw,  \
                                shift_rb_lsw,  \
                                offset_x_lsw,  \
                                offset_y_lsw,  \
                                shift_rb_used, \
                                shift_lt_used, \
                                s              ]  )
    else:  # subfield repeat
        # strip out SRV1, SRV2, RXB, and RYH from acitivate line
        # loop over sx1c and sy2c. Watch for nonzero sy1c and sx2c.

        newline = ""
        words = activate_line.split()

        begin = False
        for word in words:
            if (word == "Activate"): begin = True
            if begin and word != "SRV1" and word != "SRV2" and word != "RXB" and word != "RYH" :
                newline = newline + " " + word

        #print "[%s]" % newline
 
        if sy1c != 0 or sx2c != 0 :
            print("\nERROR: strange array with sy1c or sx2c not zero: [%s]." % activate_line) 
            print("What does it mean?\n")
            sys.exit() 
        
        subx = int( offset_x_lsw )
        suby = int( offset_y_lsw )

        for row in range( sy2c+1 ):
            y = suby + s2dy * row
            suby_s = "%d" % y
            for col in range( sx1c+1 ):
                x = subx + s1dx * col
                subx_s = "%d" % x
                s = sorting_parameter( x, y, chunk )
                table.append( [ newline, \
                                main_x_lsw,    \
                                main_y_lsw,    \
                                freq_lsw,      \
                                freq_msw,      \
                                base_lsw,      \
                                height_lsw,    \
                                msf,           \
                                shift_lt_lsw,  \
                                shift_rb_lsw,  \
                                subx_s,        \
                                suby_s,        \
                                shift_rb_used, \
                                shift_lt_used, \
                                s              ]  )


    return( table )

#-----------------------------------------------------------------------------------------------


def flatten( table, main_resol, sub_resol, chunk ):

    # look for repetition lines, creating explicit shapes instead

    mx1c = 0  # main x1 count
    mx2c = 0  # main x2 count
    my1c = 0
    my2c = 0
    sx1c = 0  # subfield x1 count
    sx2c = 0  # subfield x2 count
    sy1c = 0
    sy2c = 0
    m1dx = 0  # main 1 delta x, in mainfield resolution units
    m1dy = 0
    s1dx = 0  # subfield 1 delta x, in subfield resolution units
    s1dy = 0
    m2dx = 0  
    m2dy = 0
    s2dx = 0  
    s2dy = 0

    #print "mx1c mx2c my1c my2c sx1c sx2c sy1c sy2c m1dx m1dy m2dx m2dy s1dx s1dy s2dx s2dy"

    n = 0
    for entry in table:
        base   = entry[5]
        height = entry[6]
        line   = entry[0]
        msf    = entry[7]
        item = line.split()
        if "SRV1" in item or "SRV2" in item or "MRV1" in item or "MRV2" in item :
            part = line.split( "\n" )
            for bit in part:
                mx1c, mx2c, my1c, my2c, sx1c, sx2c, sy1c, sy2c, m1dx, m1dy, m2dx, m2dy, s1dx, s1dy, s2dx, s2dy  = \
                parse( bit, mx1c, mx2c, my1c, my2c, sx1c, sx2c, sy1c, sy2c, m1dx, m1dy, m2dx, m2dy, s1dx, s1dy, \
                s2dx, s2dy, base, height, msf, main_resol, sub_resol ) 
            #print "%4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d " % \
            #(mx1c, mx2c, my1c, my2c, sx1c, sx2c, sy1c, sy2c, m1dx, m1dy, m2dx, m2dy, s1dx, s1dy, s2dx, s2dy )
            table = expand_array( entry, n, table, chunk, mx1c, mx2c, my1c, my2c, sx1c, sx2c, sy1c, sy2c, \
            m1dx, m1dy, m2dx, m2dy, s1dx, s1dy, s2dx, s2dy )
        n = n + 1

    return( table )

#-----------------------------------------------------------------------------------------------
# MAIN


print()
print("GTX sorting utility, version %d" % version)
print()

if len( sys.argv ) == 1 : 
    print("\nUse: radial_sort.py file.gpf")
    print("\n     The output file will be file_sorted.gpf\n\n") 
    sys.exit()
    
if len( sys.argv ) > 1 :
    if sys.argv[1] == "-h" or sys.argv[1] == "-help" or sys.argv[1] == "--help" :
        print("\nUse: radial_sort.py file.gpf")
        print("\n     The output file will be file_sorted.gpf\n\n") 
        sys.exit()
    filein = sys.argv[1]
else:
    print()
    print("Enter input gpf file name> ", end=' ')
    sys.stdout.flush()
    filein = sys.stdin.readline()
    filein = filename[0:-1]

if not (".gpf" in filein) and not ("." in filein):
    filein = filein + ".gpf" 

name = filein.split( "." )
fileout = name[0] + "_sorted.gpf"

print()
print("Input gpf file:  ", filein)
print("Output gpf file: ", fileout)
print()


print("\nConverting to gtx...\n")
gpfgtx( filein, "temp_in.gtx" ) #os.system( "gpfgtx %s temp_in.gtx" % filein )


gtxin  = open( "temp_in.gtx",  "rb" )
gtxout = open( "temp_out.gtx", "w" )

print("\nCopying header... \n")

word  = []

# copy header

line = gtxin.readline().decode('utf8')
line = line.replace( "RANDOM", "FLOATING" )

if not line:
    print("\nERROR: unexpected end of file.\n\n")
    sys.exit()

word = line.split()
if len( word ) == 0 :
    word.append( "\n" )

bss = 0.0
mfr = 0.0
sfr = 0.0

while word[0] != "END" :
    if not line:
        print("\nERROR: unexpected end of file.\n\n")
        sys.exit()
        
    word = line.split()

    if len( word ) == 0 :
        word.append( "\n" )

    if word[0] == "BeamStepSize" :
        stuff = word[1].split( "," )
        sub_resol = int( stuff[0] ) 
        msf = sub_resol  
        bss = sub_resol
        print("        Beam step size (bits) :      ", bss)
    elif word[0] == "Resolution":
        stuff = word[1].split( "," )
        main_resol = int( stuff[0] )         
    elif word[0] == "MainFieldResolution" :
        stuff = word[1].split( "," )
        mfr = float( stuff[0] )
        print("        Main field resolution (um) : ", mfr) 
    elif word[0] == "SubFieldResolution" :
        stuff = word[1].split( "," )
        sfr = float( stuff[0] )
        print("        Subfield resolution (um) :   ", sfr) 
    elif word[0] == "SubFieldSize" :
        stuff = word[1].split( "," )
        sfsx = float( stuff[0] )
        sfsy = float( stuff[1] )
        fsx = sfsx * 1.1
        if (fsx*sfr*bss) > 8 : fsx = 8 / (sfr*bss)
        fsy = sfsy * 1.1
        if (fsy*sfr*bss) > 8 : fsy = 8.0 / (sfr*bss)
        sx  = int( fsx )
        sy  = int( fsy )
        print("        Subfield size (bits) :       ", sx, sy)    

    if word[0] == "SubFieldSize" :
        gtxout.write( "  SubFieldSize          %1d,%1d ! \n" % (sx, sy) )
    else:
        gtxout.write( line )

    line = gtxin.readline().decode('utf8')
    line = line.replace( "RANDOM", "FLOATING" )


if bss == 0.0 or mfr == 0.0 or sfr == 0.0 :
    print("\nERROR: units not found in header.\n")
    sys.exit()

gtxout.write( line )    # write "END" after header

bss_sub = msf
#print "        Number of subfield bits in a beam step: %d\n" % bss_sub

chunk = CHUNK / mfr   # usually, 1 um / 0.001 = 1000 bits
#print "chunk = ", chunk

print()
print("Reading...")
print()

end_of_file = False

while not end_of_file:             # while not EOF, sort each field
    print("---------------------------------------------------------------")
    new_field = True

    main_x_lsw   = 0
    main_y_lsw   = 0
    base_lsw     = "0"
    height_lsw   = "0"
    shift_lt_lsw = "0"
    shift_rb_lsw = "0"
    offset_x_lsw = "0"
    offset_y_lsw = "0"
    msf          = 0
    freq_msw     = "0"
    freq_lsw     = "0"

    append_next_line = False     
    n = 0
    end_of_field = False
    nbad = 0
    each_line = " "
    table = []

    while True:                       # for each_line in gtxin.readlines() :

        if len( each_line ) == 0 :
            end_of_file = True
            break

        if end_of_field : 
            break

        each_line = gtxin.readline().decode('utf8')

        if append_next_line:                     # True for repetition lines
            line = line + "\n" + each_line[:-1]
            append_next_line = False
        else:
            line = each_line[:-1]

        word = each_line.split()

        unknown = False

        if len( word ) > 0:
            if word[0] ==                         "END":
                end_of_field = True
            elif word[0] ==                       "Main":
                if word[1] == "X":
                    main_x_lsw = int( word[3] )
                else:
                    main_y_lsw = int( word[3] )
            elif word[0] ==                       "Frequency":
                if word[1] == "LSW":
                    freq_lsw = word[2]
                else:
                    freq_msw = word[2]
            elif word[0] ==                       "MoveStage":
                gtxout.write( each_line )
            elif word[0] ==                       "Base":
                base_lsw = word[2]
            elif word[0] ==                       "Height":
                height_lsw = word[2]
            elif word[0] ==                       "MSF":
                msf = word[1]                                     # subfield (e.g. 20 => 10nm)
            elif word[0] ==                       "Shift":
                if word[1] == "LT":
                    shift_lt_lsw = word[3]
                else:
                    shift_rb_lsw = word[3]
            elif word[0] ==                       "Offset":
                if word[1] == "X":
                    offset_x_lsw = word[3]
                else:
                    offset_y_lsw = word[3]
            elif word[0] ==                       "Repetition":
                append_next_line = True                            # tricky!
            elif word[0] ==                       "Activate":
                n = n + 1
                attributes = line.split()

                if "hb" in attributes :            # careful! hb applies only to this item
                    this_height_lsw = base_lsw 
                else:
                    this_height_lsw = height_lsw

                shift_rb_used = not ("rb45" in attributes or "rb90" in attributes)
                shift_lt_used = not ("lt45" in attributes or "lt90" in attributes)

                x = float( main_x_lsw ) - X0
                y = float( main_y_lsw ) - Y0

                # We want to sort by radius, sort of.
                # Shapes are grouped into chunks (say, 1x1 um)
                # and then sorted by the parameter "s",
                # which is weighted so that radial movement will
                # be slower than tangential.

                s = sorting_parameter( x, y, chunk )

                if False :
                    # if bad_shape( shift_rb_used, shift_lt_used, bss_sub, \
                    #               base_lsw, this_height_lsw, shift_lt_lsw, shift_rb_lsw, line ) : 
                    nbad = nbad + 1
                    #print "base:     ", base_lsw
                    #print "height:   ", this_height_lsw
                    #print "shift lt: ", shift_lt_lsw
                    #print "shift rb: ", shift_rb_lsw
                    #print line
                else:
                    table.append( [ line,          \
                                    main_x_lsw,    \
                                    main_y_lsw,    \
                                    freq_lsw,      \
                                    freq_msw,      \
                                    base_lsw,      \
                                    this_height_lsw,    \
                                    msf,           \
                                    shift_lt_lsw,  \
                                    shift_rb_lsw,  \
                                    offset_x_lsw,  \
                                    offset_y_lsw,  \
                                    shift_rb_used, \
                                    shift_lt_used, \
                                    s              ]  )
            else:
                if not "FIELD" in line :
                    print("Failure to encounter FIELD line: [%s]" % line)
                    print("Abort.\n")
                    sys.exit()
                print(line)
                print()
                gtxout.write( "%s\n" % line )   
                sys.stdout.flush() 

            # end if word[0]

        if (n > 0) and (n % 1000 == 0) : 
            print("                              shape %d \015" % n, end=' ') 
            sys.stdout.flush()

        # end if len( word ) > 0

    # end while each_line


    if end_of_file: break

    print("                              shape %d " % n) 

    print("\nFlattening...\n")
    sys.stdout.flush()

    table = flatten( table, main_resol, sub_resol, chunk )

    print("\nSorting by angle and radius... ", end=' ')
    sys.stdout.flush()

    table = sort_table( table, 14 )

    print("Done.\n") 

    # print "\nNumber of bad shapes: %d\n" % nbad 

    #---------------------------------------------------------------
    # Write the rest of the gtx file (the header was copied already)

    num_shapes = len( table )
    #print "\n\nNumber of shapes: %d\n" % num_shapes 

    if num_shapes < 1 :
        print("\nERROR: there are no shapes in this gtx file.\n")
        sys.exit()

    print("Writing...")

    activate_line     = table[0][0]
    prev_main_x_lsw   = table[0][1]
    prev_main_y_lsw   = table[0][2]
    prev_freq_lsw     = table[0][3]
    prev_freq_msw     = table[0][4]
    prev_base_lsw     = table[0][5]
    prev_height_lsw   = table[0][6]
    prev_msf          = table[0][7]
    prev_shift_lt_lsw = table[0][8]
    prev_shift_rb_lsw = table[0][9]
    prev_offset_x_lsw = table[0][10]
    prev_offset_y_lsw = table[0][11]
    shift_rb_used     = table[0][12]
    shift_lt_used     = table[0][13]

    if not ("deleted" in activate_line):
        gtxout.write( "  Frequency  LSW %s\n"    % prev_freq_lsw     )
        gtxout.write( "  Frequency  MSW %s\n"    % prev_freq_msw     )
        gtxout.write( "  MSF        %s\n"        % prev_msf          )
        gtxout.write( "  Main       X LSW %s\n"  % prev_main_x_lsw   )
        gtxout.write( "  Main       Y LSW %s\n"  % prev_main_y_lsw   )
        gtxout.write( "  Offset     X LSW %s\n"  % prev_offset_x_lsw )
        gtxout.write( "  Offset     Y LSW %s\n"  % prev_offset_y_lsw )
        gtxout.write( "  Base       LSW %s\n"    % prev_base_lsw     )
        if not ("hb" in activate_line ) :
            gtxout.write( "  Height     LSW %s\n"    % prev_height_lsw   )
        if shift_lt_used:
            gtxout.write( "  Shift      LT LSW %s\n" % prev_shift_lt_lsw )
        if shift_rb_used:
            gtxout.write( "  Shift      RB LSW %s\n" % prev_shift_rb_lsw )
        gtxout.write( "%s\n" % activate_line )
        new_field = False
    elif new_field:
        new_field = False
        gtxout.write( "  Frequency  LSW %s\n"    % prev_freq_lsw     )
        gtxout.write( "  Frequency  MSW %s\n"    % prev_freq_msw     )
        gtxout.write( "  MSF        %s\n"        % prev_msf          )
        gtxout.write( "  Main       X LSW %s\n"  % prev_main_x_lsw   )
        gtxout.write( "  Main       Y LSW %s\n"  % prev_main_y_lsw   )
        gtxout.write( "  Offset     X LSW %s\n"  % prev_offset_x_lsw )
        gtxout.write( "  Offset     Y LSW %s\n"  % prev_offset_y_lsw )
        gtxout.write( "  Base       LSW %s\n"    % prev_base_lsw     )
        
    n = 0

    if num_shapes > 1 :
        for item in table[1:] :
            if n % 1000 == 0 : 
                print("                              shape %d \015" % n, end=' ') 
                sys.stdout.flush()
            n = n + 1

            activate_line = item[0]
            main_x_lsw    = item[1]
            main_y_lsw    = item[2]
            freq_lsw      = item[3]
            freq_msw      = item[4]
            base_lsw      = item[5]
            height_lsw    = item[6]
            msf           = item[7]
            shift_lt_lsw  = item[8]
            shift_rb_lsw  = item[9]
            offset_x_lsw  = item[10]
            offset_y_lsw  = item[11]
            shift_rb_used = item[12]
            shift_lt_used = item[13]

            # Setting values by implication does not work reliably,
            # so the output will be rather verbose. Oh well.

            if not ("deleted" in activate_line) :
                if True: # freq_lsw <> prev_freq_lsw :
                    gtxout.write( "  Frequency  LSW %s\n"    % freq_lsw     )
                if True: # freq_msw <> prev_freq_msw :
                    gtxout.write( "  Frequency  MSW %s\n"    % freq_msw     )
                if True: # msf <> prev_msf :
                    gtxout.write( "  MSF        %s\n"        % msf          )
                if True: # main_x_lsw <> prev_main_x_lsw :
                    gtxout.write( "  Main       X LSW %s\n"  % main_x_lsw   )
                if True: # main_y_lsw <> prev_main_y_lsw :
                    gtxout.write( "  Main       Y LSW %s\n"  % main_y_lsw   )
                if True: # PROBLEM: offset_x_lsw <> prev_offset_x_lsw :
                    gtxout.write( "  Offset     X LSW %s\n"  % offset_x_lsw )
                if True: # offset_y_lsw <> prev_offset_y_lsw :
                    gtxout.write( "  Offset     Y LSW %s\n"  % offset_y_lsw )
                if True: # base_lsw <> prev_base_lsw :
                    gtxout.write( "  Base       LSW %s\n"    % base_lsw     )
                if (not ("hb" in activate_line )): # PROBLEM: and (height_lsw <> prev_height_lsw) :
                    gtxout.write( "  Height     LSW %s\n"    % height_lsw   )
                if shift_lt_used:
                    gtxout.write( "  Shift      LT LSW %s\n" % shift_lt_lsw )
                if shift_rb_used:
                    gtxout.write( "  Shift      RB LSW %s\n" % shift_rb_lsw )

                gtxout.write( "%s\n" % activate_line )
                new_field = False

            prev_main_x_lsw    = item[1]
            prev_main_y_lsw    = item[2]
            prev_freq_lsw      = item[3]
            prev_freq_msw      = item[4]
            prev_base_lsw      = item[5]
            prev_height_lsw    = item[6]
            prev_msf           = item[7]
            prev_shift_lt_lsw  = item[8]
            prev_shift_rb_lsw  = item[9]
            prev_offset_x_lsw  = item[10]
            prev_offset_y_lsw  = item[11]

            # end for item
        # end if num_shapes > 1    

    if n > 0 : print("                              shape %d " % (n+1)) 

    gtxout.write( "END\n" )

    # end while not EOF

gtxin.close()
gtxout.close()

print("\nConverting back to gpf...\n")

os.system( "%s temp_out.gtx %s" % (GTXGPF, fileout) )

print( "\nThe output file is %s" % fileout )
print("\nDone.\n")
print()

