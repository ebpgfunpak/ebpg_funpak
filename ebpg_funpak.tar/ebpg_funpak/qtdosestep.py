#!/usr/bin/env python3

# For installation instructions, look at the comments at the top 
# of qtcalc.py

import sys
import os
import math

from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui


class GroupBox(QWidget):

    def __init__(self):
        QWidget.__init__(self)
        global MAXCLOCK

        self.setWindowTitle("dose step")

        vbox = QGridLayout()
        self.setLayout( vbox )

        first_label = QLabel( "First dose" )
        first_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        vbox.addWidget( first_label, 0, 0 )

        self.first_box = QLineEdit('')
        vbox.addWidget( self.first_box, 0, 1 )
        self.first_box.returnPressed.connect( self.evaluate )

        spacer = QLabel( "      " )
        vbox.addWidget( spacer, 1, 0 )

        last_label = QLabel( "Last dose" )
        last_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        vbox.addWidget( last_label, 2, 0 )

        self.last_box = QLineEdit('')
        vbox.addWidget( self.last_box, 2, 1 )
        self.last_box.returnPressed.connect( self.evaluate )

        spacer = QLabel( "      " )
        vbox.addWidget( spacer, 3, 0 )

        n_label = QLabel( "number of exposures" )
        n_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        vbox.addWidget( n_label, 4, 0 )

        self.n_box = QLineEdit('')
        vbox.addWidget( self.n_box, 4, 1 )
        self.n_box.returnPressed.connect( self.evaluate )

        spacer = QLabel( "      " )
        vbox.addWidget( spacer, 5, 0 )

        equals = QPushButton('=')
        vbox.addWidget( equals, 6, 1 )        
        equals.clicked.connect( self.evaluate )

        spacer = QLabel( "      " )
        vbox.addWidget( spacer, 7, 0 )

        step_label = QLabel( "multiplicative dose step" )
        step_label.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        vbox.addWidget( step_label, 8, 0 )

        self.step_box = QLineEdit('')
        vbox.addWidget( self.step_box, 8, 1 )



    def evaluate( self ):
        self.first_box.setStyleSheet("color: black;")
        self.last_box.setStyleSheet( "color: black;")
        self.n_box.setStyleSheet(    "color: black;")

        try:
            first = float( self.first_box.text() )
        except:
            self.first_box.setText( "ERROR" )
            self.first_box.setStyleSheet("color: red;")
            self.step_box.setText( "ERROR" )
            self.step_box.setStyleSheet("color: red;")
            return
        if first < 0 :
            first = -first
            self.first_box.setText( "%1.2f" % first )
        if first == 0 :
            self.first_box.setText( "ERROR" )
            self.first_box.setStyleSheet("color: red;")
            self.step_box.setText( "ERROR" )
            self.step_box.setStyleSheet("color: red;")
            return

        try:
            last = float( self.last_box.text() )
        except:
            self.last_box.setText( "ERROR" )
            self.last_box.setStyleSheet("color: red;")
            self.step_box.setText( "ERROR" )
            self.step_box.setStyleSheet("color: red;")
            return
        if last < 0 :
            last = -last
            self.last_box.setText( "%1.2f" % last )
        if last == 0 :
            self.last_box.setText( "ERROR" )
            self.last_box.setStyleSheet("color: red;")
            self.step_box.setText( "ERROR" )
            self.step_box.setStyleSheet("color: red;")
            return

        try:
            n = float( self.n_box.text() )
        except:
            self.n_box.setText( "ERROR" )
            self.n_box.setStyleSheet("color: red;")
            self.step_box.setText( "ERROR" )
            self.step_box.setStyleSheet("color: red;")
            return
        if n < 0 :
            n = -n
            self.n_box.setText( "%1d" % n )
        (frac, num) = math.modf( n )
        if frac != 0 :
            n = num
            self.n_box.setText( "%1d" % n )
        if n == 0 :
            self.n_box.setText( "ERROR" )
            self.n_box.setStyleSheet("color: red;")
            self.step_box.setText( "ERROR" )
            self.step_box.setStyleSheet("color: red;")
            return
        
        step = math.exp( math.log( last / first ) / (n-1.0) )
        self.step_box.setText( "%1.6f" % step )
        self.step_box.setStyleSheet("color: blue;")


#============================================================   

app = QApplication(sys.argv)
calc = GroupBox()
calc.show()
sys.exit(app.exec_())
