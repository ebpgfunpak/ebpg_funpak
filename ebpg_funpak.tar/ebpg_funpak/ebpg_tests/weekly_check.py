#!/usr/bin/python3

# Load each beam archive file and check the current.
# If necessary, readjust the current, optimize c2, and save the archive.

import os
import sys
import string
import select
import time
import operator

START_AT               = 0.0    # nA       start at this current
STOP_AT                = 260    # nA       stop  at this current
BEAM_CURRENT_TOLERANCE = 10     # percent  use set_current if necessary
SETTLING_TIME          = 10     # seconds, like beampar but temporary

# change these parameters after a tip change or other trauma:

CHECK_C1               = 24230
CHECK_C2               = 34713
CHECK_I                = 10.0
CHECK_EXTI             = 150.0

# adjust_beam is very unreliable.

# SETCURRENT             = "adjust_beam"
# NOC2FLAG               = ""               # adjust_beam tweaks C2 - not an option

# set_current is better and faster, but you have to install it

SETCURRENT             = "/home/pg/bin/set_current.py -quiet"
NOC2FLAG               = "-noc2"        

#---------------------------------------------------------------------------------

def sort_table(table, cols):
    """                                                                             
    sort a table by multiple columns                                                
    table: a list where each inner list represents a row      
    cols:  a list specifying the column numbers to sort by               
    """
    is_a_list = True
    
    try:
        len( cols )
    except:
        is_a_list = False

    if is_a_list:
        rcols = reversed( cols )
        for col in rcols :
            table = sorted(table, key=operator.itemgetter(col))
    else:
        table = sorted(table, key=operator.itemgetter(cols))

    return( table )

#---------------------------------------------------------------------------

def archive_list() :
    stuff = os.popen( "ls /home/pg/archive/*.beam_100" ).read()
    files = stuff.split()
    table = []

    for file in files :
        filename = file.split('/')[4]
        basename = filename.split('.')[0]
        scurrent = filename.split('_')[0]
        if "pa" in scurrent :
            current = float( scurrent.replace( "pa", "." ) )
            current = current / 1000.0
        else:
            current = float( scurrent.replace( "na", "." ) )
        saperture = filename.split('_')[1]
        if "um" in saperture :
            saperture = saperture.split('u')[0]     # old style
        else:
            saperture = saperture.split('.')[0]     # new style
        aperture = int( saperture )
        table.append( [basename, current, aperture] )

    table = sort_table( table, (2,1) )    # sort by aperture, then current

    print( "\nBeam archive files to be updated:\n" )
    for beam in table :
        current  = beam[1]
        filename = beam[0]
        if current > START_AT and current <= STOP_AT : print( filename )
    print()
    
    return( table )

#---------------------------------------------------------------------------

def do( athing ) :
    print( athing )
    os.system( athing )

#---------------------------------------------------------------------------

def KeyPressed():
    return select.select([sys.stdin], [], [], 0) == ([sys.stdin], [], [])

#---------------------------------------------------------------------------

def motorized_aperture() :
    line = os.popen( "pg get opt_smc" ).read()
    smc = "1" in line 
    return smc

#-------------------------------------------------------------------------------------

def get_holder() :
    holderinfo = os.popen( "pg info subs" ).read()
    holder = 0
    for line in holderinfo.split('\n') :
        if "Sys" in line :
            try:
                holder = int(line.split()[3])
            except:
                holder = 0
    return holder

#--------------------------------------------------------------------------

def get_current() :
    curcurs = os.popen( "mcur" ).read()[:-1]
    curcurss = curcurs.split('_')
    if len( curcurss ) < 2 :
        print( "\nERROR: cannot understand this current reading: %s\n" % curcurs )
        sys.exit()

    if "nA" in curcurss[1] :
        unit = 1.0
    elif "pA" in curcurss[1] :
        unit = 0.001
    else :
        print( "\nERROR: unknown current unit: %s\n" % curcurss[1] )
        sys.exit()

    word = curcurss[0].split(':')
    try:
        curcur = unit * float( word[1] )
    except:
        print( "ERROR: cannot understand this current reading: %s\n" % curcurss[0] )
        sys.exit()
   
    print( "  Beam current : %1.3f nA" % curcur )

    return( curcur )

#-----------------------------------------------------------------------------

def get_shift() :
    stuff = os.popen( "pg get sftcur" ).read()
    return( stuff[:-1] )

#-----------------------------------------------------------------------------

def get_tilt() :
    stuff = os.popen( "pg get tltcur" ).read()
    return( stuff[:-1] )

#-----------------------------------------------------------------------------

def get_pmhv() :
    stuff = os.popen( "pg get pmhv" ).read()
    return( stuff[:-1] )

#-----------------------------------------------------------------------------

def get_extraction_current() :
    stuff = os.popen( "pg get extcur --mea" ).read()
    word = stuff.split( "_" )
    if "uA" in word[1] :
        i = float( word[0] )
    else:
        print( "Extraction current unit: %s" % word[1] )
        i = 0.0
    return( i )

#-----------------------------------------------------------------------------

def check_for_abort() :
    if not KeyPressed() : return
    ch = sys.stdin.read(1)
    if ch == '\033' or os.path.exists( "fullstop.txt" ) :
        os.system( "pg set beamparinv 1" )
        print()
        print( "I used to be a scientist like you, but then I took an arrow in the knee.")
        print()
        sys.exit()

#-----------------------------------------------------------------------------

# MAIN

os.system( "rm -f fullstop.txt" )
bail = False

noc2 = ""
if len(sys.argv) > 1 :
    if "noc2" in sys.argv[1] : 
        noc2 = NOC2FLAG
        print( "\nSkip optimization of C2\n" )


esc = str(chr(27))
ff  = str(chr(12))

auto_aperture = motorized_aperture()

print()
print( "Realign gun and update beam archive files.")
print()
print( "Press [Esc] [Enter] to abort.")
print()

holder = get_holder()
os.system( "pg sel hol %d" % holder )

# check the tip and bail if it's wonky

print( "\nCheck the current with nominal 10 nA settings." )
print( "If the beam current is way off, then abort." )
print( "\nAfter installing a new tip, you should change" )
print( "the values of CHECK_* at the top of weekly_check.\n" )

do( "pg set cc1 --bin %d" % CHECK_C1 )
do( "pg set cc2 --bin %d" % CHECK_C2 )
do( "pg sel ap 300" )
do( "pg adj beam align" )
current = get_current()
di = abs( 100.0 * (current - CHECK_I) / CHECK_I )

bail = False

if di > 30.0 :
    print( "\nERROR: There is a problem with the tip. The current is way off." )
    print( "Abort.\n" )
    bail = True

exti = get_extraction_current()
di = abs( 100.0 * (exti - CHECK_EXTI) / CHECK_EXTI )

if di > 30.0 :
    print( "\nERROR: There is a problem with the tip. The extraction current is way off." )
    print( "Abort.\n" )
    bail = True

if bail : sys.exit()

archives = archive_list()

n = 0

for beam in archives :
    current = beam[1]
    if current > START_AT and current <= STOP_AT : 
        n = n + 1

if n < 5 :
    if n == 0 : 
        print( "\nThere are no beam archive files. That's definitely wrong." )
    elif n == 1 :
        print( "\nThere is only one beam archive file. That seems wrong." )
    else :
        print( "\nThere are only %d beam archive files. That seems wrong." % n )

    print( "The file names in /home/pg/archive must be of the form" )
    print( "10na_300.beam_100      and  1na5_200.beam_100      for newer machines, or" )
    print( "10na_300um_2.beam_100  and  1na5_200um_1.beam_100  for older machines." )
    print( "Or perhaps the values of START_AT and STOP_AT are silly.\n" )

first = True
ap = 0

# let's assume that we start with shift and tilt values that 
# work for the first archive. Maybe you did that one by hand.
# If this is the first one, then read the shift etc

firstarchive = True
tilt  = ""
shift = ""
pmhv  = ""
aperture_previous = 0
name = ""

do( "pg set beamparinv 0" )

i = 0
for beam in archives : 
    check_for_abort()
    name_previous = name
    name    = beam[0]
    current = beam[1]
    aperture_actuel = beam[2] 

    if not auto_aperture and (aperture_actuel != aperture_previous) and (current > START_AT) and (current <= STOP_AT) :
        aperture_previous = aperture_actuel
        ap = aperture_actuel     
        if ap > 200 :
            print( "%s[7;5m%s" % (esc, ff))
            print( "\nSet the %d micron aperture, then press Enter" % ap)
            print( "%s[0m" % esc)
            print( "%s" % ff)
            print()
            do( "pg set apert %d" % ap )

    if current > START_AT and current <= STOP_AT :
        i = i + 1
        if first :
            firstname = name
            firstaper = ap
            first = False
        print( "==================================================== Updating %s   %d of %d" % (name, i, n))

        check_for_abort()
        do( "pg arc rest beam %s" % name )

        # Future improvement: check the results of "pg arc rest beam" to see
        # if the aperture alignment worked. If it did not work, then 
        # we should do another "pg adj ap" after the beam alignment.
        # Upon failure the pg error would be ENG_W_NOMARK.

        # After an arc or vacuum burp, we might need 
        # to reset the gun tilt and shift manually.

        # We will extract the values of tilt, shift, and pmhv 
        # that worked for the previous archive.

        if firstarchive:
            firstarchive = False
            tilt  = get_tilt()
            shift = get_shift()
            pmhv  = get_pmhv()
            # or you could do this instead:
            # shift = "-16.52757_mA,24.97586_mA"
            # tilt  = "-21.025_mA,-21.517_mA"
            # pmhv  = "48664"
        else:
            do( "pg set sftcur %s" % shift )
            do( "pg set tltcur %s" % tilt  )
            do( "pg set pmhv   %s" % pmhv  )

        check_for_abort()

        print( "Wait %d seconds" % SETTLING_TIME )
        time.sleep( SETTLING_TIME )
        do( "mvm" )
        do( "atc" )
        do( "mcur" )
        do( "pg adj beam align" )
        result = os.popen( "pg get error" ).read()
        success = True

        if "E_NOMARK" in result or "E_VIDLTL" in result :
            do( "pg adj beam align reset" )
            do( "pg adj beam align" )
            result = os.popen( "pg get error" ).read()
            if "E_NOMARK" in result or "E_VIDLTL" in result :
                print( "                                    *******************************" );
                print( "                                      unable to align %s" % name )
                print( "                                    *******************************" );
                success = False

        check_for_abort()

        if success :
            os.system( "mvm" )
            os.system( "atc" )
            curcur = get_current()

            if (100.0 * abs( curcur - current ) / current) > BEAM_CURRENT_TOLERANCE :
                print( "\n---\n\nCurrent is out of tolerance. Setting current to %1.1f nA\n" % current )
                os.system( "%s %s %1.1f 0.7" % (SETCURRENT, noc2, current) )
                os.system( "mvm" )
                os.system( "atc" )
                curcur = get_current()

                if (100.0 * abs( curcur - current ) / current) > 30.0 :
                    print( "\nTHAT DID NOT GO WELL. LET'S TRY ONE MORE TIME...\n" )
                    if name_previous != "" : os.system( "pg arc rest beam %s" % name_previous )
                    os.system( "%s %s %1.1f 0.7" % (SETCURRENT, noc2, current) )
                    os.system( "mvm" )
                    os.system( "atc" )
                    curcur = get_current()
                
                if (100.0 * abs( curcur - current ) / current) > 30.0 :
                    print( "\n\nSORRY! THIS IS NOT GOING WELL." )
                    print( "The beam current is too far off. " )
                    print( "Try changing the parameters START_AT or STOP_AT" )
                    print( "to avoid the extremely low or high currents." )
                    print( "Abort.\n\n" )
                    sys.exit()

            do( "pg arc save beam %s" % name )

            tilt  = get_tilt()
            shift = get_shift()
            pmhv  = get_pmhv()

    check_for_abort()

if not bail :
    if os.path.exists( "fullstop.txt" ) : 
        print( "\nAbort. You should use pg arc rest beam now.\n" )
        sys.exit()

    os.system( "pg info arc beam" )

    print( "\n\nRecalibration complete.\n\n")

    if not auto_aperture:
        print( "Set the 300 micron aperture, then press Enter" )
        ch = sys.stdin.read(1)
        os.system( "pg set apert 300" )

    firstname = "30na_300"
    do( "pg arc rest beam %s" % firstname )
    print( "Wait %d seconds" % SETTLING_TIME )
    time.sleep( SETTLING_TIME )
    os.system( "pg set beamparinv 1" )
    os.system( "mvm" )
    os.system( "atc" )
    os.system( "mcur" )
    do( "rm -f /home/pg/archive/*.beam_100_*" )   # useless backups
    print()
    print( "Done.")
    print()
else:
    print( "\nAbort.\n" )
