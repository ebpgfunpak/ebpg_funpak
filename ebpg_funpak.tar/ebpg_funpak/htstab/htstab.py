#!/usr/bin/env python3

"""
Plot the data collected by htstab.sh, by splitting the data into separate files
that can be easily digested by gnuplot.  Gnuplot scripts are called, to display
plots and to save pdf versions of those plots.  The pdf plot files are collected
in a zip archive called htstab_<date>.zip

Usage: plot_htstab <file>
The default input file is htstab.log.

M. Rooks, Yale University
Version 1
"""

import os
import sys
import string

if len( sys.argv ) > 1 :
    infilename = sys.argv[1]
else:
    infilename = "htstab.log"

infile = open( infilename )
    
dyfile      = open( "htstab_drifty.dat", "w" )
dxfile      = open( "htstab_driftx.dat", "w" )
scalexfile  = open( "htstab_scalex.dat", "w" )
scaleyfile  = open( "htstab_scaley.dat", "w" )
rotxfile    = open( "htstab_rotx.dat", "w" )
rotyfile    = open( "htstab_roty.dat", "w" )
heightfile  = open( "htstab_height.dat", "w" )
currentfile = open( "htstab_current.dat", "w" )
extfile     = open( "htstab_ext.dat", "w" )
focusfile   = open( "htstab_focus.dat", "w" )

print("\nPlotting htstab data in %s...\n" % infilename) 

first = True

hdate = infile.readline()      # date, human form
date  = infile.readline()      # date, short form
date  = date[0:-1]
infile.readline()              # labels

print("Data collected on ", hdate)
print()

i = 2
first = True
time  = 0.0
x     = 0.0
y     = 0.0

for line in infile.readlines():
    i = i + 1
    line = line[0:-1]
    item = string.split( line, "," )
    
    if len(item) < 11 :
        print("ERROR: bad line [%d] in htstab.log" % i)
        sys.exit()

    item[1] = item[1][0:-3]
    item[2] = item[2][0:-3]
    item[7] = item[7][0:-3]
    item[8] = item[8][0:-3]
    item[9] = item[9][0:-3]

    # time x y scalex scaley rotx roty height current extraction focus

    previous_time = time
    previous_x = x
    previous_y = y
    
    time    = float( item[0]  )              # hours
    x       = float( item[1]  )              # mm
    y       = float( item[2]  )              # mm
    scalex  = float( item[3]  )              # bits
    scaley  = float( item[4]  )              # bits
    rotx    = float( item[5]  )              # bits
    roty    = float( item[6]  )              # bits
    height  = float( item[7]  )              # um
    current = float( item[8]  )              # nA
    extr    = float( item[9]  )              # uA
    focus   = float( item[10] )              # bits

    if first:
        first = False
        start = time
    else:
        hour = time - start

        if (time - previous_time) < 5e-4 :
            print("ERROR: probably bad data in htstab.log line [%d]" % i)
            sys.exit()
            
        dxdt = 16666.7 * abs(x - previous_x) / (time - previous_time)   # nm/min
        dydt = 16666.7 * abs(y - previous_y) / (time - previous_time)   # nm/min
        
        dyfile.write(      "%f %f\n" % (hour, dydt)    )        
        dxfile.write(      "%f %f\n" % (hour, dxdt)    )        
        scalexfile.write(  "%f %f\n" % (hour, scalex)  )        
        scaleyfile.write(  "%f %f\n" % (hour, scaley)  )
        rotxfile.write(    "%f %f\n" % (hour, rotx)    )        
        rotyfile.write(    "%f %f\n" % (hour, roty)    )        
        heightfile.write(  "%f %f\n" % (hour, height)  )        
        currentfile.write( "%f %f\n" % (hour, current) )        
        extfile.write(     "%f %f\n" % (hour, extr)    )        
        focusfile.write(   "%f %f\n" % (hour, focus)   )        


infile.close()
dyfile.close()
dxfile.close()
scalexfile.close()
scaleyfile.close()
rotxfile.close()
rotyfile.close()
heightfile.close()
currentfile.close()
extfile.close()
focusfile.close()

os.system( "htstab_drift.gnu   &" )
os.system( "htstab_scale.gnu   &" )
os.system( "htstab_rot.gnu     &" )
os.system( "htstab_height.gnu  &" )
os.system( "htstab_current.gnu &" )
os.system( "htstab_extr.gnu    &" )
os.system( "htstab_focus.gnu   &" )

print()

os.system( "sleep 4" )   # wait for plotting to finish
pdfout = "htstab_%s.zip" % date
os.system( "zip %s *.pdf" % pdfout )

print()
print("This set of plots has been saved in %s" % pdfout)
print() 
print("Done.")
print()
