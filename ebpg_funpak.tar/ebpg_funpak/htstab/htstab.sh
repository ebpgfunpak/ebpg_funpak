#!/bin/bash


mnemonics_error_handler ()
{
    exit $1
}

trap 'error=$? ; mnemonics_error_handler $error' ERR
trap 'trap - ERR' EXIT

if [ $# -eq 0 ];
    then
    jump=400
else
    jump=$1
fi



. script_init_template
echo 
echo "HTSTAB for EBPG"
echo "Yale University"
echo "version 1"
echo
echo "Use htstab.py to plot the results."
echo

#pg arc restore beam 1na_300um_2.beam_100
#pg adj ebpg

date > htstab.log
date +%m.%d.%g >> htstab.log
echo "time x y scalex scaley rotx roty height current extraction focus" >> htstab.log

i=0

# Use the "while" form to run indefinitely
# Use the "for" loop to run for a fixed time

i=0

while true; do
#for (( n=0; n<=50; n=$[$n + 1] )); do
    i=$[$i+1]
    echo "[$i]"
    #              The subtlety here is that we record the stage position _after_ the
    #              stage has drifted for some number of seconds. "pg adj ebpg" compensates 
    #              for stage drift, and so each measurement here shows the drift since 
    #              the previous calibration. We get a drift rate, but not a drifting position.
    mvm
    here=`pg get tab`
    pg adj ebpg 500
    mcur
    pg move pos $here
    now=`date +%s`
    hour=`dc -e "4k $now 3600.0 / 361000 - p"`
    scalex=`pg get pg_x`
    scaley=`pg get pg_y`
    rotx=`pg get pr_x`
    roty=`pg get pr_y`
    height=`pg get height --mea`
    current=`pg get bcm`
    extcur=`pg get extcur --mea`
    ff=`pg get ff`
    echo $hour,$here,$scalex,$scaley,$rotx,$roty,$height,$current,$extcur,$ff >> htstab.log
    echo $hour,$here,$scalex,$scaley,$rotx,$roty,$height,$current,$extcur,$ff 
    sleep 30
done
