#!/usr/bin/python3

"""
Peek at the high voltage and the filament current, then send mail if either one is off.
Peek at the gun pressure also, to watch for gun farts. Peek at the room temperature.
If the building cooling is off, the gun will overheat. Now we also peek at the
emission current, which should be < exti_max.

This program loops forever, checking parameters every 5 minutes. 

You should export SYSADMIN="email.of.the.person.who.gets.alerts.about.the.machine"

This assumes that the 'mail' command works on the ebpg. If it does not, try editing
the file /etc/postfix/main.cf to change the line "relayhost =" which often should 
look like "relayhost = [mail.yourschool.edu]"

A good place to start this program is at the end of fegup, with this line:

        setsid /home/pg/bin/peek_hv.sh &

Make sure peek_hv and vacmon keep running by putting the script start_peek.py
in /etc/cron.hourly

        



M. Rooks, Yale University
michael.rooks@yale.edu


"""

import os
import sys

failures = 0
sysadmin = os.popen( "echo $SYSADMIN" ).read()[:-1]

vac_threshold = 1e-8  # mBar
igp_threshold = 0.4   # uA  .. not used now because the new pump is wacky
exti_max      = 200.0 # uA  maximum extraction current

ebpg_sn = "EBPG"   # change this if you have more than one machine

#---------------------------------------------------------------------------

def message( stuff, recipient ) :
    os.system( "mail -s \"%s\" %s < /dev/null" % (stuff, recipient) )
    
#---------------------------------------------------------------------------

def get_hv( previous ) :
    global failures
    line = os.popen( "pg get htval --mea" ).readlines()
    unit = line[0][-3:-1]
    hvs = line[0].split('_')
    try:
        hv = float( hvs[0] )
    except:
        failures += 1
        print( "This is not a voltage value: [%s]" % hvs[0][:-1] )
        return previous
    if unit == "kV" : hv = hv * 1000
    return hv

#---------------------------------------------------------------------------

def get_igp() :
    line = os.popen( "pg get vacigp1" ).read()
    unit = line[-3:-1]
    value = float( line.split('_')[0] )
    if unit == "uA" :
        return( value )
    elif unit == "mA" :
        return( value * 1000.0 )
    elif unit == "nA" :
        return( value * 0.001 )
    elif unit == "pA" :
        return( valeu * 0.000001 )
    else:
        print( "\nERROR: unknown unit in IGP current reading: %s\n" % line[:-1] )
        return( -1.0 )

#---------------------------------------------------------------------------

def get_vacgun() :
    line = os.popen( "pg get vacgun" ).read()
    unit = line[-5:-1]
    value = float( line.split('_')[0] )

    if unit == "mBar" :
        return( value )
    else:
        print( "\nERROR: unknown unit for gun pressure: %s\n" % line[:-1] )
        return( -1.0 )

#---------------------------------------------------------------------------

def get_room_temp() :
    line = os.popen( "pg get temproom" ).read()
    temp = float( line.split( '_' )[0] )
    return( temp )

#---------------------------------------------------------------------------

def get_fil( previous ) :
    global failures
    os.system( "pg get filcur --mea > /tmp/fil.log" )
    log = open( "/tmp/fil.log" )
    line = log.readline()
    log.close()
    curs = line.split('_')
    try:
        cur = float( curs[0] )
    except:
        failures += 1
        print( "This is not a current value: [%s]" % curs[0][:-1] )
        return previous
    return cur

#-----------------------------------------------------------------------------

def get_extraction_current() :
    stuff = os.popen( "pg get extcur --mea" ).read()
    word = stuff.split( "_" )
    if "uA" in word[1] :
        i = float( word[0] )
    else:
        print( "Extraction current unit: %s" % word[1] )
        i = 0.0
    return( i )


# MAIN ============================================================================

if sysadmin == "" :
    print( "\nERROR: you must export SYSADMIN=\"email.of.someone\"" )
    print(   "       Also, you should make sure that the mail command works.\n" )
    sys.exit()

farts = 0
hotakes = 0
extraction_complaints = 0
silent_bd = False
hv_up = True
fil_up = True
max_room_temp = 24.0

first  = get_hv( 0 )
firsti = get_fil( 0 )

if firsti < 0.01 :
    print( "\nThe gun is off. Aborting peek_hv.\n" )
    sys.exit()

hv  = first
fil = firsti
if first <- 0.0 : first = 1.0

while hv_up and fil_up :
    hv  = get_hv( hv )
    fil = get_fil( fil )
    igp = get_vacgun()


    #print( "Gun pressure: %g uA" % igp )
    #sys.exit()
    
    if igp < 0 and not silent_bd :
        message( "ERROR: %s cannot read gun pressure" % ebpg_sn, sysadmin )
        silent_bd = True

    if igp > vac_threshold and farts < 5 :
        print( "\nGun fart!  Gun pressure = %4.3f mBar\n" % igp )
        message( "%s gun fart" % ebpg_sn, sysadmin )
        farts = farts + 1

    if farts >= 5 and not silent_bd :
        message( "Time to bake the gun on %s" % ebpg_sn, sysadmin )
        silent_bd = True

    if (100.0 * abs( first - hv ) / first) > 10.0  :
        hv_up = False
        print( "\nHigh voltage has tripped. V = %2.1f\n" % hv )
        message( "High voltage has tripped on %s" % ebpg_sn, sysadmin )
    elif (100.0 * abs( firsti - fil ) / firsti) > 10.0  :
        fil_up = False
        print( "\nThe heater current has failed." )
        message( "Heater has failed on %s" % ebpg_sn, sysadmin )
    else:
        print( "\nV = %1.0f kv  I = %1.1f A" % (hv/1000, fil) )
        os.system( "date" )
        os.system( "sleep 300" )
    
    if failures > 6 : 
        hv_up = False 
        message( "Too many bad readings from peek_hv on %s" % ebpg_sn, sysadmin )
        print( "\nToo many bad readings from peek_hv. Giving up now.\n" )
        sys.exit()

    temp = get_room_temp()
    if temp > max_room_temp and hotakes < 3 :
        print( "\nThe ebpg room is too hot: %1.1f C\n" % temp )
        message( "%s room is too hot: %1.1f C" % (ebpg_sn, temp), sysadmin )
        hotakes = hotakes + 1
        
    exti = get_extraction_current()
    if exti > exti_max and extraction_complaints < 3 :
        print( "\nThe extraction current is too high: %1.1f uA\n" % exti )
        message( "%s extraction current is too high: %1.1f uA" % (ebpg_sn, exti), sysadmin )
        extraction_complaints = extraction_complaints + 1
