#!/usr/bin/python3

# Start vacmon and peek_hv, if they are not already running.
# You might call this program from pgreset, or put it in
# /etc/cron.hourly

import os
import sys

def running( task ) :
    stuff = os.popen( "ps ax | grep -e \"%s\" | grep -v grep" % task ).read()
    return( task in stuff )

if not running( "peek_hv" ) :
    print( "restarting peek_hv" )
    os.system( "setsid /home/pg/bin/peek_hv.sh &" )
    os.system( "rm -f /home/pg/bin/shutup" )

if not running( "vacmon" ) :
    print( "restarting vacmon" )
    os.system( "vacmon -d" )
    os.system( "rm -f /home/pg/bin/shutup" )

     
