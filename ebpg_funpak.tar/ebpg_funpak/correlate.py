#!/usr/bin/python3

import sys
import os

#-------------------------- parameters you might want to change:

threshold      = 5        # percent
coarse_frames  = 0        # 2^0 = 1 frame
coarse_samples = 2
fine_frames    = 1        # 2^1 = 2 frames
fine_samples   = 2

cbss           = 20       # coarse beam step size, nm
                          # coarse scan will be 1000*cbss wide 
fbss           = 6        # fine beam step size, nm
                          # fine scan will be 1000*fbss wide

abort_on_failure  = False
coarse_model_name = "coarse_model"
fine_model_name   = "fine_model"

#--------------------------

# How to use correlation alignment:
#
# 1. Use a CAD program (such as Layout) to create a GDS drawing of the mark. This will become
#    the "model" image. Put the mark center at (0,0). Later, when setting up the alignment,
#    you will need to find the vector from each mark to the chip center. Therefore, you should
#    pick a "center" point that makes sense.
#
#    If you cannot create a CAD file for the mark, you can instead create a "model" image
#    by scanning one of these ridiculous marks. The maximum number of pixels is 1024x1024,
#    so we use 1000,1000 for convenience. Use commands like
#
#    pg image grab 0,0 20,20 1000,1000 coarse_model --sample=2 --frame=0
#    pg image grab 0,0 6,6   1000,1000 fine_model   --sample=2 --frame=1
#
#    This creates a raw image file coarse_model.img using a scan of 20 nm * 1000 = 20 um.
#    Check the image with the command "ijraw coarse_model". 
#    This technique will result in an unknown offset in the alignment. Either you 
#    don't care about the offset, or you measure it with a test run.
#    The other way of creating a model image is better. If you did it the better way,
#    then go on to step 2. Otherwise skip to step 4.
#
# 2. Convert the model mark GDS file to Raith GPF format, using Beamer. (You can't use Freebeam,
#    because of the next step.) Be sure that Beamer's export module uses "shape filling standard." 
#    Do not use 'spiral' or 'smooth' filling. Choose pattern extents that are symmetric,
#    leaving the center at (0,0). 
#
# 3. Convert the GPF model mark to raw images using commands like this: 
#
#    gpfraw goofymark.gpf coarse_model -- 0,0 0.02,0.02 1000,1000
#    gpfraw goofymark.gpf fine_model   -- 0,0 0.006,0.006 1000,1000
#
#    In this example, the model for coarse alignment has a beam step size of 0.02 um = 20 nm.
#    The model for fine alignment has a beam step size of 0.006 um = 6 nm.
#    In both cases the images will have 1000x1000 pixels; therefore 
#    the size of the coarse scan is 1000 * 0.02  = 20 um
#    the size of the fine   scan is 1000 * 0.006 =  6 um
#
#    The gpfraw command creates goofy*model.img in the current directory.
#    Check the image files with the command ijraw goofy*model.img
#
# 4. Make a copy of this python program in your local directory. Do not edit the one in /public.
#    Use this command to make a copy, then edit the copy:
#
#    cp /public/correlate.py .
#    gedit correlate.py
#
#    You might need to change some of the parameters, such as 'threshold' or 'coarse_frames'.
#    The default parameters work for high-contrast marks.
#
# 5. The mark type "correlate" will call the program correlate.py in the current directory.
#    Test the program by moving to one of your ridiculous marks and then execute
#
#    mvm 0,0 --rel correlate
#
#    Modify the parameters and try again, as needed.
#    If it works, then you can use the mark type "correlate" in cjob.
#
#-----
#
# Note that the local ebeam dude has already created the mark type "correlate" 
# by using the command
#
#     pg marker create joy ./correlate.py correlate
#
# where "./" means "use the one here in the current directory."
#
# Note that the maximum number of pixels from "pg image grab" is 1024x1024.
# This puts a severe limit on the accuracy of correlation alignment.
# Here we are using 1000x1000 pixels just to make the image size obvious.
#
#-----
#
# If alignment is successful, the stage will be moved to the mark "center".
# If alignment fails, the stage will not move.
# What should we do if the alignment fails? We could abort the exposure,
# or we could just carry on. We should find a way to assert a marker search error.



print( "coarse alignment..." )
os.system( "pg image grab 0,0 %d,%d 1000,1000 coarse_image --sample=%d --frame=%d" % (cbss, cbss, coarse_samples, coarse_frames) )

stuff = os.popen( "export PG_IMAGE_THRESHOLD=%d ; unset PG_IMAGE_CORRELATION ; pg image correlate coarse_image %s" % (threshold, coarse_model_name) ).read()
lines = stuff.split('\n')

offset = "not found"

for line in lines :
    if "_um," in line : 
        offset = line
    else:
        print( line )

if offset == "not found" :
    print( "coarse alignment failed" )
    if abort_on_failure : os.system( "killjob" )
    sys.exit()
else:
    print( "mvrl %s\n" % offset )
    os.system( "pg mov pos --rel %s" % offset )

print( "fine alignment..." )

os.system( "pg image grab 0,0 %d,%d 1000,1000 fine_image --sample=%d --frame=%d" % (fbss, fbss, fine_samples, fine_frames) )

stuff = os.popen( "export PG_IMAGE_THRESHOLD=%d ; unset PG_IMAGE_CORRELATION ; pg image correlate fine_image %s" % (threshold, fine_model_name) ).read()
lines = stuff.split('\n')

offset = "not found"

for line in lines :
    if "_um," in line : 
        offset = line
    else:
        print( line )

if offset == "not found" :
    print( "fine alignment failed" )
    if abort_on_failure : os.system( "killjob" )
    sys.exit()
else:
    print( "mvrl %s\n" % offset )
    os.system( "pg mov pos --rel %s" % offset )

