#!/usr/bin/env python3

"""
tweakcb.py

version 3.0     

Much like tweakc2, but now uses "conjugate" to measure the beam
shift when blanking. Tweakc2 tries to minimize ffdeviation, which
more properly should be done by changing FL, not C2. That's a 
project for later.

Here we adjust C2 so that the conjugate blanking shift is closer to zero.
Look at n C2 settings, look for the minimum shift, then set C2.

M. Rooks, Yale University
michael.rooks@yale.edu

"""

import os
import sys
import math
import string
import select
import numpy

LOWC2     = 4000   # smallest lens 2 value, binary 
HIGHC2    = 15000  # largest  lens 2 value, binary
STEP      = 100    # increment C2 by this much
GOOD      = 0.2    # no need to adjust C2 if FF shift is less than this
N         = 7      # this number of readings

#---------------------------------------------------------------------------

def KeyPressed():
    return select.select([sys.stdin], [], [], 0) == ([sys.stdin], [], [])


#---------------------------------------------------------------------------

def set_c2( c2 ) :
    #
    # Set the C2 lens

    if c2 >= LOWC2 and c2 <= HIGHC2  :
        #print( "pg set cc2 --bin %d" % c2 )
        os.system( "pg set cc2 --bin %d" % c2 )
    else:
        print()
        print("ERROR: C2 lens value is out of range.")
        print("       C2 = %d" % c2)
        print()

    return


#---------------------------------------------------------------------------

def get_c2() :
    c2 = int( os.popen( "pg get cc2 --bin" ).read() )
    return c2

#---------------------------------------------------------------------------

def get_shift() :
    if KeyPressed() :
        print()
        ch = sys.stdin.read(1)
        if ch == '\033' :
            print()
            print("I used to be a scientist like you, but then I took an arrow in the knee.")
            print()
            sys.exit()
            print()

    result = os.popen( "conjugate" ).read()
    word = result.split()
    if len( word ) < 7 :
        print("\nERROR: results of 'conjugate' are confusing.\n")
        sys.exit()
    try:
        dx = float( word[4] )
        dy = float( word[6][1:] )
    except:
        print("\nERROR: results of conjugate shift measurement are confusing.\n")
        n = 0
        for item in word:
            print("%d [%s]" % (n,item))
            n += 1
        sys.exit()

    d =  math.sqrt( dx * dx + dy * dy )

    return d

#---------------------------------------------------------------------------

def linfit( x, y ) :
    n = len( x )
    if len(y) != len(x) :
        print("\nArrays sent to linfit do not match.\n")
        sys.exit()
        
    sx  = 0.0
    sy  = 0.0
    st2 = 0.0
    b   = 0.0
    
    for xx in x : sx += xx
    for yy in y : sy += yy
    sxn = sx / n
    
    for i in range(n) :
        t = x[i] - sxn
        st2 += t * t
        b += t * y[i]
        
    b = b / st2              # slope
    a = (sy - sx * b) / n    # intercept

    return (a, b)
    
#------------------------------------------------------------------------------

def minimum_point( shift, c2 ):

    # Fit a parabola and calculate C2 for minimum shift.
    # If that value is nuts then use one from the list.

    global LOWC2, HIGHC2

    min = shift[0]
    bestc2 = c2[0]

    for i in range( len( shift ) ) :
        if shift[i] < min :
            min = shift[i]
            bestc2 = c2[i]

    p = numpy.polyfit( c2, shift, 2 )  # fit a parabola
    fitc2 = -p[1] / (2.0 * p[0])       # calculus!

    if fitc2 < LOWC2 or fitc2 > HIGHC2 :
        print("C2 from parabolic fit (%d) is out of range." % fitc2)
        print("We will use %d instead." % bestc2)
        fitc2 = bestc2

    return fitc2

#--------------------------------------------------------------------------------

# MAIN ============================================================================

print()
print("Adjust C2 for optimal conjugate blanking...")
print()
print("Press [Esc] [Enter] to abort.")
print()


c2_arr  = []    # c2
ff_arr  = []    # measured ff deviations

c2 = get_c2()
ffdev = get_shift()

if abs(ffdev) > GOOD :

    lowc2 = c2 - N * STEP / 2

    for i in range(N) :
        nc2 = lowc2 + i * STEP
        set_c2( nc2 )
        nffdev = get_shift()
        print(( "C2: %d  deviation: %1.3f um" % (nc2, nffdev) ))
        c2_arr.append( nc2 )
        ff_arr.append( nffdev )

    better_c2 = minimum_point( ff_arr, c2_arr )

    print(( "Better C2: %d" % better_c2 ))

    set_c2( better_c2 )
    nffdev = get_shift()
    print(( "C2: %d  deviation: %1.3f um" % (better_c2, nffdev) ))
else:
    print( "Good enough." )
    print(( "C2: %d  deviation: %1.3f um" % (c2, ffdev) ))


print()

