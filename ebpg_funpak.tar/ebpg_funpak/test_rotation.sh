#/bin/bash

mnemonics_error_handler ()
{
    exit $1
}

trap 'error=$? ; mnemonics_error_handler $error' ERR
trap 'trap - ERR' EXIT

function key
    {
    something=""
    while [ "$something" != "done" ]; do 
        read -p "Enter a command, or 'done' > " something
        if [ "$something" != "done" ]; then
            $something
        fi
    done
    echo "..."
    }


echo
echo "Substrate rotation test"
echo "                        using two alignment marks"
echo "                        that are nearly on-axis"
echo

read -p "Enter the mark type, something like 'p20', 'n5', or 'joy' > " mtype

if [ "$mtype" == "" ]; then 
    mtype="p20"
    echo "Well ok, I will use p20."
    echo
fi

if [ "$mtype" == "joy" ] || [ "$mtype" == "JOY" ] ; then 
    mtype="JOY" 
    echo "Ok, we will use manual alignment."
    echo
fi

echo
echo "Move to a mark using commands like mvrl and mvm,"
echo "or by using the SEM window. Type 'done' when you"
echo "are there."
echo

key

mvm 0,0 --rel $mtype

first=`pg get tab`

if [[ `pg get error` =~ "NOMARK" ]]; then
    # the error is trapped separately, so this
    # will never happen. But it's nice as an
    # example of how to respond to an alignment error.
    echo
    echo "Cannot find the first mark. Abort."
    echo
    exit
else
    echo "ok"
fi

echo
echo "Move horiontally or vertically to a different mark position."
echo "Move the stage mostly in X or mostly in Y. Type 'done' when"
echo "you are there."
echo

key

mvm 0,0 --rel $mtype

if [[ `pg get error` =~ "NOMARK" ]]; then
    # this will never happen because
    # the error is trapped above
    echo
    echo "Cannot find the second mark. Abort."
    echo
    exit
else
    echo "ok"
fi

second=`pg get tab`

echo $first   > temp_rot.txt
echo $second >> temp_rot.txt

# now we need a python program to do the rest

calc_rot.py


