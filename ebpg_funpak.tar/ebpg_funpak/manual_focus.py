#!/usr/bin/python3

# Manual focus by using the arrow keys to change the height.
# Requires the 'blessed' package. Install blessed with
# pip install blessed
# M. Rooks, Yale University
# see below for usage hints


import sys
import os
from blessed import Terminal
term = Terminal()

print( "\nUse the arrow keys to focus." )
print( "Use PgUp and PgDn to change the step." )
print( "Press 'q' to stop.\n\n" )

step = 2.0 # um

sheight = os.popen( "pg get height" ).read()
height = float( sheight[:-4] )
if "nm" in sheight : height = height / 1000.0
if "pm" in sheight : height = 0.0

print( "height: %7.2f um    step: %5.2f um            " % (height, step), end='' )
sys.stdout.flush()

right = chr(27) + chr(91) + chr(67)
left  = chr(27) + chr(91) + chr(68)
up    = chr(27) + chr(91) + chr(65)
down  = chr(27) + chr(91) + chr(66)
pgup  = chr(27) + chr(91) + chr(53) + chr(126)
pgdn  = chr(27) + chr(91) + chr(54) + chr(126)

increase = False

initial = ''
stop = False

while not stop :
    increase = True
    decrease = False
    stepup   = False
    stepdown = False
    unknown  = False

    with term.cbreak() :
        st = term.inkey()
        stop = st[0] == 'q'
        
        increase = (st == right) or (st == up)
        decrease = (st == down)  or (st == left)
        stepup   = (st == pgup)
        stepdown = (st == pgdn)

        unknown = not increase and not decrease and not stepup and not stepdown

    if not unknown and not stop :
        if stepdown :
            step = step / 1.5
        elif stepup :
            step = step * 1.5
        elif increase :
            height = height + step
        else :
            height = height - step
            
    if height > 100.0 :
        height = 100.0
        print( "\015height: %7.2f um    step: %5.1f um    maximum " % (height, step), end='' )
    elif height < -100.0 :
        height = -100.0
        print( "\015height: %7.2f um    step: %5.1f um    minimum " % (height, step), end='' )
    else:
        print( "\015height: %7.2f um    step: %5.1f um            " % (height, step), end='' )

    sys.stdout.flush()
    os.system( "pg adj height comp %1.2f_um" % height )
 
print("\n")


# USAGE HINTS


# MANUAL FOCUS JOB
#
# To use a manual focus value in a cjob job, create an ini file
# with the name yourjobfile.ini, containing
#
#     pg set hgtinv 1
#     pg set calrealign 0
#     pg set calinv 0
#     export CJ_NOMARKERHEIGHT=1
#     export PG_USER_HEIGHT=/home/pg/users/your.name/whatever/myfocus.sh
#
# Or, make a copy of /public/ini/manual_focus.ini 
# The script myfocus.sh would contain something like
#
#     height="-12.3um"
#     pg adj height comp $height
#     echo "********************* height set to fixed value $height"
#
# You can find this in /public/ini.
# If not, be sure to make your script executable with
#
#     chmod a+x myfocus.sh



# HOW TO ADJUST THE HEIGHT/FOCUS
#
# A simple way to set the focus (height) is to use this program
# to focus on a small particle or on the corner of a mark. 
# Another way to set the height is to correct
# the deflection manually. For example, find a mark with
#
#      mvm 0,0 --rel p20
#
# then move over to the corner*
#
#      mvrl 10,10
#
# Zoom to 50kx and put the crosshair on the corner.
# Deflect the beam 500 um with
#
#      pg set md 500,500
#
# and move the stage 500 um with
#
#      mvrl -500,-500
#
# The corner should now be in the SEM view.
# Use this program to move the corner back to the crosshair.
# Hopefully, this gives a height value close to the one
# you get when adjusting the focus.


# * mvrl is an alias for 
#   pg move pos --rel <dx>,<dy>



 
