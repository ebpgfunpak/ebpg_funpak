#!/usr/bin/env python3

"""
extractpath.py

use: extractpath file.gds cell layer

requires gdsdump

Pull a gds path out of file.gds from the given cell and layer. Dump the coordinates into 
a simple path.txt file for use with ybrsort or gpfsort. If more than one path is 
encoutered, then we will insert a "jump" between them.

"""
import os
import sys

version = 1.1

def delete_dump():
    try:
        f = open( "gdsdump.txt", "r" )
        f.close()
        os.system( "rm -f gdsdump.txt" )
    except:
        return


def print_use():
    global version
    print("\nextract path %1.1f" % version)
    print("\nUse: extractpath file.gds cell layer")
    print("     Output will be in extracted_path.txt")
    print("     The path must exist in the given cell, not in")
    print("     a cell reference inside the given cell.\n\n")
    delete_dump()
    sys.exit()


def read_until( txtfile, string, terminator ):
    line = txtfile.readline()
    found = False
    terminate = terminator in line
    while not terminate and not found and line != "" :
        while not string in line and not terminate and line != "" : 
            line = txtfile.readline()
            terminate = terminator in line
        if line != "" and not terminate : found = True

    if not found and not terminate:
        print("\nUnable to find [%s] in gds file\n" % string)
        delete_dump()
        sys.exit()    

    return terminate



#-----------------------------------------------------------------------------------------------
# MAIN


print()
print("Extract a path from a GDS file, for use with ybrsort or gpfsort.")
print()

if len( sys.argv ) <  4 : print_use()

filein = sys.argv[1]
cell   = sys.argv[2]
slayer = sys.argv[3]

if not ".gds" in filein and not ".GDS" in filein :
    print_use()

try:
    layer = int( slayer )
except:
    print_use()

try:
    open( filein, "r" )
except:
    print("\nCannot open %s" % filein)
    print_use()

print("Input file:       %s" % filein)
print("Path is in cell:  %s" % cell)
print("Path is on layer: %d" % layer)
print("Output gpf file:  extracted_path.txt")

os.system( "gdsdump %s > gdsdump.txt" % filein )

txtfile = open( "gdsdump.txt", "r" )

# look for the cell name

read_until( txtfile, "STRNAME", '\0' )
read_until( txtfile, cell, '\0' )

print("\nFound the cell %s" % cell)

# look for the path

eof = False
first = True
endstr = False
never_found = True

outfile = open( "extracted_path.txt", "w" )

while not endstr and not eof:
    found = False
    while not found and not eof :
        endstr = read_until( txtfile, "PATH", "ENDSTR" )
        if endstr : break
        endstr = read_until( txtfile, "LAYER", "ENDSTR" )
        if endstr : break

        try:
            thislayer = int( txtfile.readline() )
            if thislayer == layer : 
                found = True
                never_found = False
        except:
            eof = True

    if endstr : break

    if eof :
        print("\nUnable to find a path on layer %d in cell [%s]\n" % (layer, cell))
        delete_dump()
        sys.exit()

    read_until( txtfile, "XY", '\0' )

    if first:
        first = False
    else:
        outfile.write( "jump\n" )

    line = txtfile.readline()
    while line != "" and not "ENDEL" in line and not "ENDSTR" in line :
        try:
            right = line.split( '=' )[1][2:-6]
        except:
            print("bad line: [%s]\n" % line[:-1])
            delete_dump()
            sys.exit()
        vertex = right.split( ',' )
        x = float( vertex[0] )
        y = float( vertex[1] )
        outfile.write( "%f %f\n" % (x, y) )
        line = txtfile.readline()

    eof = (line == "")


outfile.close()

delete_dump()

if never_found :
    print("\nUnable to find a path in cell [%s] on layer [%d]\n" % (cell, layer))
    print("If the path exists in a cell reference inside the given cell, ")
    print("try flattening the cell. In Layout CAD, select the cell then use")
    print("the menu for Cell -> Flat \n\n")
else:
    print("\nDone.\n\nBe sure to edit extracted_path.txt to insert lines containing\n")
    print("        lower-left x y")
    print("        upper-right x y\n")
    print("as well as any extra\n")
    print("        jump\n")
    print("lines that you need. The path might be in the wrong order,") 
    print("so fire up your favorite editor and get to work.\n")
