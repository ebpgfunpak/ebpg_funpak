#!/usr/bin/bash

rsync --delete --links --archive --verbose --update --perms --recursive --rsh=ssh --whole-file pg@ebpg.eng.yale.edu:bin         /home/pg/
rsync --delete --links --archive --verbose --update --perms --recursive --rsh=ssh --whole-file pg@ebpg.eng.yale.edu:archive     /home/pg/
rsync --delete --links --archive --verbose --update --perms --recursive --rsh=ssh --whole-file pg@ebpg.eng.yale.edu:data        /home/pg/
rsync --delete --links --archive --verbose --update --perms --recursive --rsh=ssh --whole-file pg@ebpg.eng.yale.edu:log         /home/pg/
rsync --delete --links --archive --verbose --update --perms --recursive --rsh=ssh --whole-file pg@ebpg.eng.yale.edu:/home/beams /home/pg/

chmod a+wr /tmp/beamer_*
chmod a+rw /home/pg/archive/*

